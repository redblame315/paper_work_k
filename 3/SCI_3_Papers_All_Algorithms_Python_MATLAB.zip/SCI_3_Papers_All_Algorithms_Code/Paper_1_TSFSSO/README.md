# Paper 1 — T-SFSSO

Algorithms 1–13 are mapped one-to-one to Python and MATLAB files. Algorithm 3 reproduces the manuscript appendix implementation. Algorithms 5–12 are based on the comparator pseudocode in Appendix C; where the manuscript itself leaves cited-source implementation details open, the code parameterizes those choices rather than pretending an unstated formula is known.

Run Python files from the `Python` directory (so `common.py` is importable). MATLAB files are function files and should be placed on the MATLAB path together.
