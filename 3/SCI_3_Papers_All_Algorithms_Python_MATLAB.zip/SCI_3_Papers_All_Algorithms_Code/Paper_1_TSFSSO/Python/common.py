from __future__ import annotations
import numpy as np

EPS=1e-12

def bounds(lo,hi,nd):
    lo=np.broadcast_to(np.asarray(lo,float),(nd,)).copy(); hi=np.broadcast_to(np.asarray(hi,float),(nd,)).copy()
    if np.any(hi<=lo): raise ValueError('every upper bound must exceed lower bound')
    return lo,hi

def central_gradient(f,x,lo,hi):
    x=np.asarray(x,float); lo=np.asarray(lo,float); hi=np.asarray(hi,float)
    h=1e-6*np.maximum(1.0,np.abs(x)); g=np.zeros_like(x)
    for j in range(x.size):
        xp=x.copy(); xm=x.copy(); xp[j]=min(hi[j],x[j]+h[j]); xm[j]=max(lo[j],x[j]-h[j])
        w=xp[j]-xm[j]; g[j]=0.0 if w==0 else (f(xp)-f(xm))/w
    return g

def f1_table1(x):
    x=np.asarray(x,float); i=np.arange(1,x.size+1,dtype=float); s=np.sum(0.5*i*x)
    return float(np.sum(x*x)+s*s+s)

def f2_matyas(x):
    x=np.asarray(x,float); return float(0.26*(x[0]**2+x[1]**2)-0.48*x[0]*x[1])

def F1_step(x): return float(np.sum(np.floor(np.asarray(x,float)+0.5)**2))
def F2_rastrigin(x):
    x=np.asarray(x,float); return float(np.sum(x*x-10*np.cos(2*np.pi*x)+10))
def F3_ackley(x):
    x=np.asarray(x,float); n=x.size
    return float(-20*np.exp(-0.2*np.sqrt(np.sum(x*x)/n))-np.exp(np.sum(np.cos(2*np.pi*x))/n)+20+np.e)
def F4_zakharov(x):
    x=np.asarray(x,float); i=np.arange(1,x.size+1,dtype=float); s=np.sum(0.5*i*x)
    return float(np.sum(x*x)+s*s+s**4)

def triangular_membership(x,a,b,c):
    x=float(x)
    if x<=a or x>=c: return 0.0
    if x==b: return 1.0
    if x<b: return (x-a)/max(b-a,EPS)
    return (c-x)/max(c-b,EPS)

def firing_weights(x, rules):
    x=np.asarray(x,float); raw=[]
    for rule in rules:
        v=1.0
        for val,(a,b,c) in zip(x,rule): v*=triangular_membership(val,a,b,c)
        raw.append(v)
    raw=np.asarray(raw,float); s=raw.sum()
    return raw/(s+EPS) if s>EPS else np.full(len(raw),1.0/len(raw))

def ts_regression_row(x,rules):
    w=firing_weights(x,rules); base=np.r_[1.0,np.asarray(x,float)]
    return np.concatenate([wi*base for wi in w]), w

def ts_predict(x,rules,theta):
    H,w=ts_regression_row(x,rules); return float(H@np.asarray(theta,float)),w

def rmse(y,yh):
    y=np.asarray(y,float); yh=np.asarray(yh,float); return float(np.sqrt(np.mean((y-yh)**2)))
def mape(y,yh):
    y=np.asarray(y,float); yh=np.asarray(yh,float); mask=np.abs(y)>EPS
    return float(100*np.mean(np.abs((y[mask]-yh[mask])/y[mask]))) if np.any(mask) else np.nan
def smape(y,yh):
    y=np.asarray(y,float); yh=np.asarray(yh,float); den=np.abs(y)+np.abs(yh); mask=den>EPS
    return float(200*np.mean(np.abs(y[mask]-yh[mask])/den[mask])) if np.any(mask) else np.nan
