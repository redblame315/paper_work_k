"""Paper 1, Algorithm 11: ISOA comparator.
The manuscript intentionally summarizes ISOA rather than reproducing the source paper's full equations.
`improvement_operator` is therefore exposed for source-exact replication; the default is identity.
"""
from __future__ import annotations
import numpy as np
from common import bounds

def isoa_minimize(f,nd,lo,hi,NP=30,M=100,exploration=2.0,attack=1.0,improvement_operator=None,seed=None):
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd); X=lo+(hi-lo)*rng.random((NP,nd)); fx=np.array([f(x) for x in X]); j=int(np.argmin(fx)); best=X[j].copy(); bestf=float(fx[j]); hist=[bestf]
    if improvement_operator is None: improvement_operator=lambda x,b,rng,lo,hi: x
    for m in range(M):
        A=exploration*(1-(m+1)/M)
        for i in range(NP):
            # migration toward promising region while retaining separation
            mig=X[i] + A*rng.uniform(-1,1,nd)*(best-X[i])
            # spiral/attack exploitation around current best
            theta=2*np.pi*rng.random(); radius=np.linalg.norm(mig-best)/(np.sqrt(nd)+1e-12); spiral=best + attack*radius*np.exp(-0.1*theta)*np.cos(theta)*rng.uniform(-1,1,nd)
            cand=np.clip(improvement_operator(np.clip(spiral,lo,hi),best,rng,lo,hi),lo,hi); fc=float(f(cand))
            if fc<=fx[i]: X[i]=cand; fx[i]=fc
            if fx[i]<bestf: bestf=float(fx[i]); best=X[i].copy()
        hist.append(bestf)
    return best,bestf,np.asarray(hist)
