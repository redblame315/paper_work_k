"""Paper 1, Algorithm 12: FTSOAX workflow (fuzzy representation + ISOA optimization + XGBoost)."""
from __future__ import annotations
import numpy as np

def lag_matrix(series,lags=3):
    s=np.asarray(series,float).reshape(-1); X=[]; y=[]
    for k in range(lags,len(s)): X.append(s[k-lags:k]); y.append(s[k])
    return np.asarray(X),np.asarray(y)

def quantile_fuzzy_features(X,n_partitions=5):
    X=np.asarray(X,float); feats=[]
    for j in range(X.shape[1]):
        q=np.quantile(X[:,j],np.linspace(0,1,n_partitions+1)); q=np.unique(q)
        if q.size<2: q=np.array([X[:,j].min()-1e-9,X[:,j].max()+1e-9])
        # one-hot fuzzy interval representation (transparent baseline transform)
        idx=np.clip(np.digitize(X[:,j],q[1:-1]),0,len(q)-2); O=np.eye(len(q)-1)[idx]; feats.append(O)
    return np.concatenate(feats,axis=1)

def ftsoax_forecast(series,forecast_horizon=1,lags=3,n_partitions=5,xgb_params=None,partition_optimizer=None):
    """Executes Algorithm 12. `partition_optimizer` can be Algorithm 11 or a source-exact ISOA callable.
    For source-exact replication, supply the cited paper's partition objective/operator and XGBoost hyperparameters.
    """
    X,y=lag_matrix(series,lags); cut=max(1,len(y)-int(forecast_horizon)); Xtr,Xte=X[:cut],X[cut:]; ytr,yte=y[:cut],y[cut:]
    if partition_optimizer is not None: n_partitions=int(partition_optimizer(Xtr,ytr,n_partitions))
    Ftr=quantile_fuzzy_features(Xtr,n_partitions); Fte=quantile_fuzzy_features(np.vstack([Xtr,Xte]),n_partitions)[-len(Xte):]
    try:
        from xgboost import XGBRegressor
    except Exception as e:
        raise ImportError('Algorithm 12 requires xgboost for the XGBoost stage.') from e
    pars={'n_estimators':200,'max_depth':4,'learning_rate':0.05,'subsample':0.9,'colsample_bytree':0.9,'objective':'reg:squarederror','random_state':7}
    pars.update(xgb_params or {}); model=XGBRegressor(**pars); model.fit(Ftr,ytr); pred=model.predict(Fte)
    return {'forecast':pred,'truth':yte,'model':model,'n_partitions':n_partitions}
