"""Paper 1, Algorithm 7: particle swarm optimization."""
from __future__ import annotations
import numpy as np
from common import bounds

def pso_minimize(f,nd,lo,hi,NP=30,M=100,omega=0.7,c1=1.5,c2=1.5,seed=None):
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd); X=lo+(hi-lo)*rng.random((NP,nd)); V=np.zeros_like(X)
    fx=np.array([f(x) for x in X]); P=X.copy(); fp=fx.copy(); j=int(np.argmin(fp)); G=P[j].copy(); fg=float(fp[j]); hist=[fg]
    for _ in range(M):
        for i in range(NP):
            r1=rng.random(nd); r2=rng.random(nd); V[i]=omega*V[i]+c1*r1*(P[i]-X[i])+c2*r2*(G-X[i]); X[i]=np.clip(X[i]+V[i],lo,hi)
            v=float(f(X[i]));
            if v<fp[i]: P[i]=X[i].copy(); fp[i]=v
            if v<fg: G=X[i].copy(); fg=v
        hist.append(fg)
    return G,fg,np.asarray(hist)
