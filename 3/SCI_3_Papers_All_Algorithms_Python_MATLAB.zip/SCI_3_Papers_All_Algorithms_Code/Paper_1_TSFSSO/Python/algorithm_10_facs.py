"""Paper 1, Algorithm 10: fuzzy ant colony system over discrete admissible parameter states."""
from __future__ import annotations
import numpy as np

def facs_minimize(f,choices,n_ants=20,M=50,evaporation=0.2,reinforcement=1.0,alpha=1.0,beta=1.0,heuristic=None,seed=None):
    rng=np.random.default_rng(seed); choices=[np.asarray(c) for c in choices]; d=len(choices); tau=[np.ones(len(c)) for c in choices]
    if heuristic is None: eta=[np.ones(len(c)) for c in choices]
    else: eta=[np.asarray(h,float) for h in heuristic]
    best=None; bestf=np.inf; hist=[]
    for _ in range(M):
        sols=[]
        for _a in range(n_ants):
            idx=[]; x=[]
            for j in range(d):
                p=(tau[j]**alpha)*(eta[j]**beta); p=p/p.sum(); q=int(rng.choice(len(choices[j]),p=p)); idx.append(q); x.append(choices[j][q])
            val=float(f(np.asarray(x,float))); sols.append((val,idx,x))
            if val<bestf: bestf=val; best=np.asarray(x,float)
        for j in range(d): tau[j]*=(1-evaporation)
        for val,idx,_x in sorted(sols,key=lambda s:s[0])[:max(1,n_ants//4)]:
            amount=reinforcement/(abs(val)+1e-12)
            for j,q in enumerate(idx): tau[j][q]+=amount
        hist.append(bestf)
    return best,bestf,np.asarray(hist)
