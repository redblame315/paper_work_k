"""Paper 1, Algorithm 5: CSSO comparator pseudocode made executable.
The manuscript does not specify the source paper's exact chaotic map. The default logistic map is explicit and replaceable.
"""
from __future__ import annotations
import numpy as np
from common import bounds,central_gradient

def csso_minimize(f,nd,lo,hi,NP=10,M=50,L=5,mu=0.9,alpha=0.5,gamma=0.9,chaos_seed=0.314159,chaos_map=None,seed=None):
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd)
    if chaos_map is None: chaos_map=lambda z: 4.0*z*(1.0-z)
    c=float(chaos_seed%1.0); X=lo+(hi-lo)*rng.random((NP,nd)); V=0.1*(hi-lo)*(2*rng.random((NP,nd))-1)
    fx=np.array([f(x) for x in X]); bi=int(np.argmin(fx)); bx=X[bi].copy(); bf=float(fx[bi]); hist=[bf]
    for _m in range(M):
        c=float(chaos_map(c)); c=min(max(c,1e-12),1-1e-12)
        for i in range(NP):
            g=central_gradient(f,X[i],lo,hi); trial=-mu*c*g+alpha*(1-c)*V[i]
            former=np.maximum(np.abs(V[i]),1e-12); V[i]=np.sign(trial)*np.minimum(np.abs(trial),gamma*former)
            z=np.clip(X[i]+V[i],lo,hi); C=[z]
            for ell in range(L):
                c=float(chaos_map(c)); R3=np.full(nd,c); C.append(np.clip(z+R3*z,lo,hi))
            cv=np.array([f(q) for q in C]); w=int(np.argmin(cv)); X[i]=C[w]; fx[i]=cv[w]
            if fx[i]<bf: bf=float(fx[i]); bx=X[i].copy()
        hist.append(bf)
    return bx,bf,np.asarray(hist)
