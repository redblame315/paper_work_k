"""Paper 1, Algorithm 13: unified fair-comparison and reporting protocol."""
from __future__ import annotations
import time, numpy as np

def fair_compare(algorithms,benchmarks,seeds,common_kwargs=None):
    records=[]; common_kwargs=common_kwargs or {}
    for bname,bfun in benchmarks.items():
        for aname,alg in algorithms.items():
            for run,seed in enumerate(seeds,1):
                t0=time.perf_counter(); out=alg(bfun,seed=seed,**common_kwargs); elapsed=time.perf_counter()-t0
                if isinstance(out,dict): final=out.get('best_f',out.get('value',np.nan)); trace=out.get('history')
                else: final=float(out[1]); trace=out[2] if len(out)>2 else None
                records.append({'benchmark':bname,'algorithm':aname,'run':run,'seed':seed,'final_error':float(final),'runtime_s':elapsed,'trace':trace})
    summary=[]
    for b in benchmarks:
        for a in algorithms:
            v=np.array([r['final_error'] for r in records if r['benchmark']==b and r['algorithm']==a]); rt=np.array([r['runtime_s'] for r in records if r['benchmark']==b and r['algorithm']==a])
            summary.append({'benchmark':b,'algorithm':a,'minimum':float(v.min()),'mean':float(v.mean()),'std':float(v.std(ddof=1)) if len(v)>1 else 0.0,'runtime_mean_s':float(rt.mean())})
    return records,summary
