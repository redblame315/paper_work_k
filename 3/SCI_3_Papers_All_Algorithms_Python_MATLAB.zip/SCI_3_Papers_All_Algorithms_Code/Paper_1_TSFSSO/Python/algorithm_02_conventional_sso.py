"""Paper 1, Algorithm 2: conventional shark smell optimization (SSO), Eqs. (19)-(25)."""
from __future__ import annotations
import numpy as np
from common import bounds,central_gradient

def sso(OF,nd,lo,hi,NP=10,M=50,L=5,mu=0.9,alpha=0.5,gamma=0.9,seed=None):
    """Maximize OF exactly as the manuscript writes Eq. (25). For minimization pass OF=lambda x:-f(x)."""
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd)
    X=lo+(hi-lo)*rng.random((NP,nd)); V=0.1*(hi-lo)*(2*rng.random((NP,nd))-1)
    val=np.array([OF(x) for x in X],float); ib=int(np.argmax(val)); best_x=X[ib].copy(); best=float(val[ib]); hist=[best]
    mus=np.broadcast_to(np.asarray(mu,float),(M,)); alphas=np.broadcast_to(np.asarray(alpha,float),(M,)); gammas=np.broadcast_to(np.asarray(gamma,float),(M,))
    # gradient of OF is needed; central_gradient computes gradient of supplied function directly.
    for m in range(M):
        for i in range(NP):
            g=central_gradient(OF,X[i],lo,hi)
            trial=mus[m]*rng.random(nd)*g + alphas[m]*rng.random(nd)*V[i]  # Eq. (21)
            former=np.maximum(np.abs(V[i]),1e-12)
            V[i]=np.sign(trial)*np.minimum(np.abs(trial),gammas[m]*former) # Eq. (22)
            z=np.clip(X[i]+V[i],lo,hi)                                   # Eq. (23), dt=1
            C=[z]
            for _ in range(L):
                R3=rng.uniform(0.0,1.0,size=nd)
                C.append(np.clip(z+R3*z,lo,hi))                           # Eq. (24)
            cv=np.array([OF(c) for c in C]); w=int(np.argmax(cv))        # Eq. (25)
            X[i]=C[w]; val[i]=cv[w]
            if val[i]>best: best=float(val[i]); best_x=X[i].copy()
        hist.append(best)
    return best_x,best,np.asarray(hist)

def sso_minimize(f,*args,**kwargs):
    x,neg,h=sso(lambda z:-f(z),*args,**kwargs); return x,-neg,-h
