"""Paper 1, Algorithm 3: FSSO. This is the manuscript Appendix-A implementation."""
from __future__ import annotations
import numpy as np
from common import bounds,central_gradient

def fsso(f,nd,lo,hi,*,NP=10,M=50,L=5,mu=0.9,alpha=0.5,Cg=1.0,Ct=2.0,Q=0.7,epsJ=1e-6,Tjump=10,seed=None,initial_elite=None):
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd)
    X=lo+(hi-lo)*rng.random((NP,nd))
    if initial_elite is not None: X[0]=np.clip(np.asarray(initial_elite,float),lo,hi)
    V=0.1*(hi-lo)*(2*rng.random((NP,nd))-1); vmax=0.5*(hi-lo)
    fx=np.array([f(x) for x in X],float); bi=int(np.argmin(fx)); best_x=X[bi].copy(); best_f=float(fx[bi]); history=np.empty(M+1); history[0]=best_f
    for stage in range(1,M+1):
        gamma=rng.uniform(0.0,2.0)                                      # Eq. (31)
        for p in range(NP):
            g=central_gradient(f,X[p],lo,hi); G=float(np.linalg.norm(g))
            trial=-mu*rng.random(nd)*g + alpha*rng.random(nd)*V[p]
            former=np.maximum(np.abs(V[p]),1e-12)
            V[p]=np.sign(trial)*np.minimum(np.abs(trial),gamma*former)
            V[p]=np.clip(V[p],-vmax,vmax)
            if G<Cg or rng.random()<Q: dt=1.0
            else: dt=(G/Cg)*Ct*rng.random()                              # Eqs. (26)-(28)
            z=np.clip(X[p]+V[p]*dt,lo,hi)
            if stage%Tjump==0 and G<epsJ: z=lo+(hi-lo)*rng.random(nd)   # Eqs. (29)-(30)
            C=[z]
            for _ in range(L):
                R3=rng.uniform(-1.3,1.3,size=nd); C.append(np.clip(z+R3*z,lo,hi)) # Eq. (32)
            cv=np.array([f(c) for c in C],float); w=int(np.argmin(cv))
            if cv[w]<=fx[p]: X[p]=C[w]; fx[p]=cv[w]
            if fx[p]<best_f: best_f=float(fx[p]); best_x=X[p].copy()
        history[stage]=best_f
    return best_x,best_f,history
