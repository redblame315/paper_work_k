"""Paper 1, Algorithm 6: normal-distribution SSO-style comparator."""
from __future__ import annotations
import numpy as np
from common import bounds,central_gradient

def nsso_minimize(f,nd,lo,hi,NP=10,M=50,L=5,mu=0.9,alpha=0.5,gamma=0.9,normal_mean=0.0,normal_std=1.0,seed=None,selection_rule=None):
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd)
    X=lo+(hi-lo)*rng.random((NP,nd)); V=0.1*(hi-lo)*(2*rng.random((NP,nd))-1)
    fx=np.array([f(x) for x in X]); bi=int(np.argmin(fx)); bx=X[bi].copy(); bf=float(fx[bi]); hist=[bf]
    for _m in range(M):
        for i in range(NP):
            r1=rng.normal(normal_mean,normal_std,nd); r2=rng.normal(normal_mean,normal_std,nd)
            g=central_gradient(f,X[i],lo,hi); trial=-mu*r1*g+alpha*r2*V[i]
            former=np.maximum(np.abs(V[i]),1e-12); V[i]=np.sign(trial)*np.minimum(np.abs(trial),gamma*former)
            z=np.clip(X[i]+V[i],lo,hi); C=[z]
            for _ in range(L): C.append(np.clip(z+rng.normal(normal_mean,normal_std,nd)*z,lo,hi))
            cv=np.array([f(q) for q in C]); w=int(np.argmin(cv)) if selection_rule is None else int(selection_rule(C,cv,X[i],fx[i]))
            if cv[w]<=fx[i]: X[i]=C[w]; fx[i]=cv[w]
            if fx[i]<bf: bf=float(fx[i]); bx=X[i].copy()
        hist.append(bf)
    return bx,bf,np.asarray(hist)
