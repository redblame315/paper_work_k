"""Paper 1, Algorithm 4: complete T-SFSSO prediction pipeline."""
from __future__ import annotations
import numpy as np
from common import ts_regression_row,ts_predict,rmse,mape,smape
from algorithm_01_rls_identification import rls_identification
from algorithm_03_fsso import fsso

def design_matrix(X,rules):
    rows=[]
    for x in np.asarray(X,float): rows.append(ts_regression_row(x,rules)[0])
    return np.asarray(rows)

def fit_tsf_sso(X,y,rules,*,split=0.8,fsso_options=None,stopping_tolerance=None,seed=7):
    X=np.asarray(X,float); y=np.asarray(y,float).reshape(-1); n=len(y); cut=max(1,min(n-1,int(np.floor(split*n))))
    Xtr,Xte=X[:cut],X[cut:]; ytr,yte=y[:cut],y[cut:]
    Htr=design_matrix(Xtr,rules); theta_rls,_,_=rls_identification(Htr,ytr)
    span=np.maximum(1.0,np.abs(theta_rls)); lo=theta_rls-2*span; hi=theta_rls+2*span
    obj=lambda th: rmse(ytr,Htr@th)
    opts=dict(NP=10,M=50,L=5,seed=seed); opts.update(fsso_options or {})
    theta,best_rmse,hist=fsso(obj,theta_rls.size,lo,hi,initial_elite=theta_rls,**opts)
    yhtr=Htr@theta; Hte=design_matrix(Xte,rules); yhte=Hte@theta
    metrics={
      'train':{'RMSE':rmse(ytr,yhtr),'MAPE':mape(ytr,yhtr),'SMAPE':smape(ytr,yhtr)},
      'test': {'RMSE':rmse(yte,yhte),'MAPE':mape(yte,yhte),'SMAPE':smape(yte,yhte)},
      'optimizer_best_RMSE':best_rmse,
      'stopping_met': None if stopping_tolerance is None else bool(best_rmse<=stopping_tolerance)}
    return {'theta_RLS':theta_rls,'theta':theta,'train_prediction':yhtr,'test_prediction':yhte,'metrics':metrics,'history':hist,'cut':cut}
