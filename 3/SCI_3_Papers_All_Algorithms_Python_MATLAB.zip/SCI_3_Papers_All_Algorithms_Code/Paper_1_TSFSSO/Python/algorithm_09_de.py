"""Paper 1, Algorithm 9: DE/rand/1/bin differential evolution."""
from __future__ import annotations
import numpy as np
from common import bounds

def de_minimize(f,nd,lo,hi,NP=30,M=100,F=0.5,CR=0.9,seed=None):
    if NP<4: raise ValueError('NP must be at least 4')
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd); X=lo+(hi-lo)*rng.random((NP,nd)); fx=np.array([f(x) for x in X]); hist=[float(fx.min())]
    for _ in range(M):
        for i in range(NP):
            pool=np.delete(np.arange(NP),i); r1,r2,r3=rng.choice(pool,3,replace=False); v=X[r1]+F*(X[r2]-X[r3]); v=np.clip(v,lo,hi)
            mask=rng.random(nd)<CR; mask[rng.integers(nd)]=True; u=np.where(mask,v,X[i]); fu=float(f(u))
            if fu<=fx[i]: X[i]=u; fx[i]=fu
        hist.append(float(fx.min()))
    j=int(np.argmin(fx)); return X[j].copy(),float(fx[j]),np.asarray(hist)
