"""Paper 1, Algorithm 8: genetic algorithm. Operators are parameters; defaults are explicit."""
from __future__ import annotations
import numpy as np
from common import bounds

def ga_minimize(f,nd,lo,hi,NP=30,M=100,crossover_rate=0.9,mutation_rate=0.1,mutation_scale=0.05,elite=1,seed=None):
    rng=np.random.default_rng(seed); lo,hi=bounds(lo,hi,nd); pop=lo+(hi-lo)*rng.random((NP,nd)); fit=np.array([f(x) for x in pop]); hist=[]
    def tournament():
        a,b=rng.integers(0,NP,2); return pop[a] if fit[a]<=fit[b] else pop[b]
    for _ in range(M):
        order=np.argsort(fit); nxt=[pop[j].copy() for j in order[:elite]]
        while len(nxt)<NP:
            p1=tournament().copy(); p2=tournament().copy(); c1=p1.copy(); c2=p2.copy()
            if rng.random()<crossover_rate:
                a=rng.random(nd); c1=a*p1+(1-a)*p2; c2=a*p2+(1-a)*p1
            for c in (c1,c2):
                mask=rng.random(nd)<mutation_rate; c[mask]+=rng.normal(0,mutation_scale,mask.sum())*(hi[mask]-lo[mask]); c[:]=np.clip(c,lo,hi); nxt.append(c.copy())
                if len(nxt)>=NP: break
        pop=np.asarray(nxt[:NP]); fit=np.array([f(x) for x in pop]); hist.append(float(fit.min()))
    j=int(np.argmin(fit)); return pop[j],float(fit[j]),np.asarray(hist)
