"""Paper 1, Algorithm 1: RLS identification of dynamic T-S consequent parameters."""
from __future__ import annotations
import numpy as np

def rls_identification(H, y, alpha=1e5):
    H=np.asarray(H,float); y=np.asarray(y,float).reshape(-1)
    if H.ndim!=2 or H.shape[0]!=y.size: raise ValueError('H must be LxP and y length L')
    p=H.shape[1]; theta=np.zeros(p); S=alpha*np.eye(p)
    history=[]
    for k in range(H.shape[0]):
        hk=H[k:k+1,:]
        d=1.0+float(hk@S@hk.T)
        F=(S@hk.T)/d
        e=float(y[k]-hk@theta)
        theta=theta+F[:,0]*e
        S=S-F@hk@S
        history.append((theta.copy(),S.copy(),e))
    return theta,S,history

if __name__=='__main__':
    H=np.c_[np.ones(20),np.linspace(-1,1,20)]; y=2+3*H[:,1]
    th,_,_=rls_identification(H,y); print(th)
