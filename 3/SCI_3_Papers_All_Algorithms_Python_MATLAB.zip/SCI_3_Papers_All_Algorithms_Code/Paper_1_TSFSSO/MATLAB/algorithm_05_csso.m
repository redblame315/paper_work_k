function [best,bestf,hist]=algorithm_05_csso(f,ND,lo,hi,o)
% Algorithm 5. Default logistic chaotic map because manuscript leaves exact map source-specific.
if nargin<5,o=struct;end;if ~isfield(o,'NP'),o.NP=10;end;if ~isfield(o,'M'),o.M=50;end;if ~isfield(o,'L'),o.L=5;end;if ~isfield(o,'mu'),o.mu=.9;end;if ~isfield(o,'alpha'),o.alpha=.5;end;if ~isfield(o,'gamma'),o.gamma=.9;end;if ~isfield(o,'chaosSeed'),o.chaosSeed=.314159;end
lo=lo*ones(1,ND);hi=hi*ones(1,ND);X=lo+(hi-lo).*rand(o.NP,ND);V=.1*(hi-lo).*(2*rand(o.NP,ND)-1);fx=arrayfun(@(i)f(X(i,:)),(1:o.NP)');[bestf,j]=min(fx);best=X(j,:);c=o.chaosSeed;hist=zeros(o.M+1,1);hist(1)=bestf;
for m=1:o.M,c=4*c*(1-c);for i=1:o.NP,g=grad(f,X(i,:),lo,hi);trial=-o.mu*c*g+o.alpha*(1-c)*V(i,:);V(i,:)=sign(trial).*min(abs(trial),o.gamma*max(abs(V(i,:)),1e-12));z=max(lo,min(hi,X(i,:)+V(i,:)));C=z;for l=1:o.L,c=4*c*(1-c);C(end+1,:)=max(lo,min(hi,z+c*z));end;cv=arrayfun(@(q)f(C(q,:)),(1:size(C,1))');[v,w]=min(cv);X(i,:)=C(w,:);fx(i)=v;if v<bestf,bestf=v;best=X(i,:);end,end;hist(m+1)=bestf;end
end
function g=grad(f,x,lo,hi),h=1e-6*max(1,abs(x));g=zeros(size(x));for j=1:numel(x),xp=x;xm=x;xp(j)=min(hi(j),x(j)+h(j));xm(j)=max(lo(j),x(j)-h(j));g(j)=(f(xp)-f(xm))/max(xp(j)-xm(j),eps);end,end
