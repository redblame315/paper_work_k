function [best,bestf,hist]=algorithm_08_ga(f,ND,lo,hi,o)
if nargin<5,o=struct;end;D=struct('NP',30,'M',100,'crossoverRate',.9,'mutationRate',.1,'mutationScale',.05,'elite',1);fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
lo=lo*ones(1,ND);hi=hi*ones(1,ND);pop=lo+(hi-lo).*rand(o.NP,ND);fit=arrayfun(@(i)f(pop(i,:)),(1:o.NP)');hist=zeros(o.M,1);
for m=1:o.M,[~,ord]=sort(fit);nxt=pop(ord(1:o.elite),:);while size(nxt,1)<o.NP,p1=tourn(pop,fit);p2=tourn(pop,fit);c1=p1;c2=p2;if rand<o.crossoverRate,a=rand(1,ND);c1=a.*p1+(1-a).*p2;c2=a.*p2+(1-a).*p1;end;for c={c1,c2},z=c{1};mask=rand(1,ND)<o.mutationRate;z(mask)=z(mask)+o.mutationScale*randn(1,sum(mask)).*(hi(mask)-lo(mask));z=max(lo,min(hi,z));nxt(end+1,:)=z;if size(nxt,1)>=o.NP,break;end,end,end;pop=nxt(1:o.NP,:);fit=arrayfun(@(i)f(pop(i,:)),(1:o.NP)');hist(m)=min(fit);end;[bestf,j]=min(fit);best=pop(j,:);
end
function p=tourn(pop,fit),n=size(pop,1);q=randi(n,1,2);if fit(q(1))<=fit(q(2)),p=pop(q(1),:);else,p=pop(q(2),:);end,end
