function [best,bestf,hist]=algorithm_09_de(f,ND,lo,hi,o)
if nargin<5,o=struct;end;D=struct('NP',30,'M',100,'F',.5,'CR',.9);fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
if o.NP<4,error('NP>=4 required');end;lo=lo*ones(1,ND);hi=hi*ones(1,ND);X=lo+(hi-lo).*rand(o.NP,ND);fx=arrayfun(@(i)f(X(i,:)),(1:o.NP)');hist=zeros(o.M+1,1);hist(1)=min(fx);
for m=1:o.M,for i=1:o.NP,p=setdiff(1:o.NP,i);r=p(randperm(numel(p),3));v=X(r(1),:)+o.F*(X(r(2),:)-X(r(3),:));v=max(lo,min(hi,v));mask=rand(1,ND)<o.CR;mask(randi(ND))=true;u=X(i,:);u(mask)=v(mask);fu=f(u);if fu<=fx(i),X(i,:)=u;fx(i)=fu;end,end;hist(m+1)=min(fx);end;[bestf,j]=min(fx);best=X(j,:);
end
