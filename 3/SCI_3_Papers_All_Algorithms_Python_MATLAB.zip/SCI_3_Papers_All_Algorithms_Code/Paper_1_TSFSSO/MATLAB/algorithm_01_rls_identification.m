function [theta,S,err] = algorithm_01_rls_identification(H,y,alpha)
% Paper 1 Algorithm 1: RLS identification.
if nargin<3, alpha=1e5; end
[L,p]=size(H); theta=zeros(p,1); S=alpha*eye(p); err=zeros(L,1);
for k=1:L
    hk=H(k,:); d=1+hk*S*hk'; F=S*hk'/d; err(k)=y(k)-hk*theta;
    theta=theta+F*err(k); S=S-F*hk*S;
end
end
