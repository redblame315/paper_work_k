function [records,summary]=algorithm_13_fair_comparison(algorithms,benchmarks,seeds,commonArgs)
% algorithms/benchmarks are structs of function handles. Each algorithm must return [x,best,history].
if nargin<4,commonArgs={};end;an=fieldnames(algorithms);bn=fieldnames(benchmarks);records={};row=0;
for b=1:numel(bn),for a=1:numel(an),for r=1:numel(seeds),rng(seeds(r));t=tic;[~,v,h]=algorithms.(an{a})(benchmarks.(bn{b}),commonArgs{:});elapsed=toc(t);row=row+1;records(row,:)={bn{b},an{a},r,seeds(r),v,elapsed,h};end,end,end
summary={};row=0;for b=1:numel(bn),for a=1:numel(an),mask=strcmp(records(:,1),bn{b})&strcmp(records(:,2),an{a});v=cell2mat(records(mask,5));rt=cell2mat(records(mask,6));row=row+1;summary(row,:)={bn{b},an{a},min(v),mean(v),std(v),mean(rt)};end,end
end
