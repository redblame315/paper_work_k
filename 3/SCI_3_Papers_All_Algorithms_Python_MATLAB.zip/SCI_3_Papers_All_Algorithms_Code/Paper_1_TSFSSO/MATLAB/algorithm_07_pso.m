function [G,fg,hist]=algorithm_07_pso(f,ND,lo,hi,o)
if nargin<5,o=struct;end;D=struct('NP',30,'M',100,'omega',.7,'c1',1.5,'c2',1.5);fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
lo=lo*ones(1,ND);hi=hi*ones(1,ND);X=lo+(hi-lo).*rand(o.NP,ND);V=zeros(size(X));fp=arrayfun(@(i)f(X(i,:)),(1:o.NP)');P=X;[fg,j]=min(fp);G=P(j,:);hist=zeros(o.M+1,1);hist(1)=fg;
for m=1:o.M,for i=1:o.NP,V(i,:)=o.omega*V(i,:)+o.c1*rand(1,ND).*(P(i,:)-X(i,:))+o.c2*rand(1,ND).*(G-X(i,:));X(i,:)=max(lo,min(hi,X(i,:)+V(i,:)));v=f(X(i,:));if v<fp(i),P(i,:)=X(i,:);fp(i)=v;end;if v<fg,G=X(i,:);fg=v;end,end;hist(m+1)=fg;end
end
