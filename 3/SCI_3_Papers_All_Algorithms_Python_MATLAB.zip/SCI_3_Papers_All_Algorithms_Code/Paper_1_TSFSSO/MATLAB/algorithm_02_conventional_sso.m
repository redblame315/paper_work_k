function [best_x,best_OF,hist] = algorithm_02_conventional_sso(OF,ND,lo,hi,o)
% Paper 1 Algorithm 2. Maximizes OF; pass @(x)-f(x) for minimization.
if nargin<5, o=struct; end
if ~isfield(o,'NP'),o.NP=10;end;if ~isfield(o,'M'),o.M=50;end;if ~isfield(o,'L'),o.L=5;end
if ~isfield(o,'mu'),o.mu=.9;end;if ~isfield(o,'alpha'),o.alpha=.5;end;if ~isfield(o,'gamma'),o.gamma=.9;end
lo=lo*ones(1,ND); hi=hi*ones(1,ND); X=lo+(hi-lo).*rand(o.NP,ND); V=.1*(hi-lo).*(2*rand(o.NP,ND)-1);
val=arrayfun(@(i)OF(X(i,:)),(1:o.NP)'); [best_OF,j]=max(val);best_x=X(j,:);hist=zeros(o.M+1,1);hist(1)=best_OF;
for m=1:o.M
 for i=1:o.NP
  g=gradCentral(OF,X(i,:),lo,hi); trial=o.mu*rand(1,ND).*g+o.alpha*rand(1,ND).*V(i,:); former=max(abs(V(i,:)),1e-12);
  V(i,:)=sign(trial).*min(abs(trial),o.gamma*former); z=max(lo,min(hi,X(i,:)+V(i,:))); C=zeros(o.L+1,ND);C(1,:)=z;
  for l=1:o.L,C(l+1,:)=max(lo,min(hi,z+rand(1,ND).*z));end
  cv=arrayfun(@(q)OF(C(q,:)),(1:o.L+1)');[v,w]=max(cv);X(i,:)=C(w,:);val(i)=v;if v>best_OF,best_OF=v;best_x=X(i,:);end
 end;hist(m+1)=best_OF;
end
end
function g=gradCentral(f,x,lo,hi)
h=1e-6*max(1,abs(x));g=zeros(size(x));for j=1:numel(x),xp=x;xm=x;xp(j)=min(hi(j),x(j)+h(j));xm(j)=max(lo(j),x(j)-h(j));w=xp(j)-xm(j);if w~=0,g(j)=(f(xp)-f(xm))/w;end,end
end
