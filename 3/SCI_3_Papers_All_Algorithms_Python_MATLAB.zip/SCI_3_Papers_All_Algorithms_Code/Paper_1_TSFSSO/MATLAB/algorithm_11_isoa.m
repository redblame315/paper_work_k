function [best,bestf,hist]=algorithm_11_isoa(f,ND,lo,hi,o,improvementFcn)
% Algorithm 11 executable summary. Pass source-exact improvementFcn if available.
if nargin<5,o=struct;end;if nargin<6,improvementFcn=@(x,b,lo,hi)x;end;D=struct('NP',30,'M',100,'exploration',2,'attack',1);fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
lo=lo*ones(1,ND);hi=hi*ones(1,ND);X=lo+(hi-lo).*rand(o.NP,ND);fx=arrayfun(@(i)f(X(i,:)),(1:o.NP)');[bestf,j]=min(fx);best=X(j,:);hist=zeros(o.M+1,1);hist(1)=bestf;
for m=1:o.M,A=o.exploration*(1-m/o.M);for i=1:o.NP,mig=X(i,:)+A*(2*rand(1,ND)-1).*(best-X(i,:));theta=2*pi*rand;rad=norm(mig-best)/(sqrt(ND)+eps);cand=best+o.attack*rad*exp(-.1*theta)*cos(theta)*(2*rand(1,ND)-1);cand=max(lo,min(hi,improvementFcn(cand,best,lo,hi)));v=f(cand);if v<=fx(i),X(i,:)=cand;fx(i)=v;end;if fx(i)<bestf,bestf=fx(i);best=X(i,:);end,end;hist(m+1)=bestf;end
end
