function [best,bestf,hist]=algorithm_10_facs(f,choices,o)
% `choices` is cell array, one vector of admissible states per parameter.
if nargin<3,o=struct;end;D=struct('nAnts',20,'M',50,'evaporation',.2,'reinforcement',1,'alpha',1,'beta',1);fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
d=numel(choices);tau=cellfun(@(c)ones(size(c)),choices,'UniformOutput',false);eta=cellfun(@(c)ones(size(c)),choices,'UniformOutput',false);best=[];bestf=inf;hist=zeros(o.M,1);
for m=1:o.M,sol=cell(o.nAnts,3);for a=1:o.nAnts,idx=zeros(1,d);x=zeros(1,d);for j=1:d,p=(tau{j}.^o.alpha).*(eta{j}.^o.beta);p=p/sum(p);q=find(rand<=cumsum(p),1);idx(j)=q;x(j)=choices{j}(q);end;v=f(x);sol(a,:)={v,idx,x};if v<bestf,bestf=v;best=x;end,end;for j=1:d,tau{j}=tau{j}*(1-o.evaporation);end;vals=cell2mat(sol(:,1));[~,ord]=sort(vals);for a=ord(1:max(1,floor(o.nAnts/4)))',idx=sol{a,2};amt=o.reinforcement/(abs(sol{a,1})+eps);for j=1:d,tau{j}(idx(j))=tau{j}(idx(j))+amt;end,end;hist(m)=bestf;end
end
