function out=algorithm_12_ftsoax(series,forecastHorizon,lags,nPartitions,trainXGBoostFcn,predictXGBoostFcn,partitionOptimizerFcn)
% Algorithm 12 workflow. MATLAB has no built-in XGBoost; caller supplies train/predict function handles.
if nargin<2,forecastHorizon=1;end;if nargin<3,lags=3;end;if nargin<4,nPartitions=5;end;if nargin<7,partitionOptimizerFcn=[];end
[X,y]=lagMatrix(series,lags);cut=max(1,numel(y)-forecastHorizon);Xtr=X(1:cut,:);Xte=X(cut+1:end,:);ytr=y(1:cut);yte=y(cut+1:end);
if ~isempty(partitionOptimizerFcn),nPartitions=partitionOptimizerFcn(Xtr,ytr,nPartitions);end
Ftr=fuzzyFeatures(Xtr,nPartitions);Fall=fuzzyFeatures([Xtr;Xte],nPartitions);Fte=Fall(end-size(Xte,1)+1:end,:);model=trainXGBoostFcn(Ftr,ytr);pred=predictXGBoostFcn(model,Fte);out=struct('forecast',pred,'truth',yte,'model',model,'nPartitions',nPartitions);
end
function [X,y]=lagMatrix(s,l),s=s(:);N=numel(s)-l;X=zeros(N,l);y=zeros(N,1);for k=1:N,X(k,:)=s(k:k+l-1);y(k)=s(k+l);end,end
function F=fuzzyFeatures(X,n),F=[];for j=1:size(X,2),q=quantile(X(:,j),linspace(0,1,n+1));q=unique(q);if numel(q)<2,q=[min(X(:,j))-eps,max(X(:,j))+eps];end;idx=discretize(X(:,j),[-inf q(2:end-1) inf]);O=zeros(size(X,1),numel(q)-1);for k=1:size(X,1),O(k,idx(k))=1;end;F=[F O];end,end
