function [best_x,best_f,hist] = algorithm_03_fsso(f,ND,lo,hi,o,initialElite)
% Paper 1 Algorithm 3, matching manuscript Appendix B.
if nargin<5,o=struct;end;if nargin<6,initialElite=[];end
D=struct('NP',10,'M',50,'L',5,'mu',.9,'alpha',.5,'Cg',1,'Ct',2,'Q',.7,'epsJ',1e-6,'Tjump',10);
fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
lo=lo*ones(1,ND);hi=hi*ones(1,ND);X=lo+(hi-lo).*rand(o.NP,ND);if ~isempty(initialElite),X(1,:)=max(lo,min(hi,initialElite));end
V=.1*(hi-lo).*(2*rand(o.NP,ND)-1);vmax=.5*(hi-lo);fx=arrayfun(@(p)f(X(p,:)),(1:o.NP)');[best_f,j]=min(fx);best_x=X(j,:);hist=zeros(o.M+1,1);hist(1)=best_f;
for stage=1:o.M
 gamma=2*rand;
 for p=1:o.NP
  g=gradCentral(f,X(p,:),lo,hi);G=norm(g);trial=-o.mu*rand(1,ND).*g+o.alpha*rand(1,ND).*V(p,:);former=max(abs(V(p,:)),1e-12);
  V(p,:)=sign(trial).*min(abs(trial),gamma*former);V(p,:)=max(-vmax,min(vmax,V(p,:)));
  if G<o.Cg || rand<o.Q,dt=1;else,dt=(G/o.Cg)*o.Ct*rand;end
  z=max(lo,min(hi,X(p,:)+V(p,:)*dt));if mod(stage,o.Tjump)==0 && G<o.epsJ,z=lo+(hi-lo).*rand(1,ND);end
  C=zeros(o.L+1,ND);C(1,:)=z;for ell=1:o.L,R3=-1.3+2.6*rand(1,ND);C(ell+1,:)=max(lo,min(hi,z+R3.*z));end
  cv=arrayfun(@(q)f(C(q,:)),(1:o.L+1)');[cf,w]=min(cv);if cf<=fx(p),X(p,:)=C(w,:);fx(p)=cf;end;if fx(p)<best_f,best_f=fx(p);best_x=X(p,:);end
 end;hist(stage+1)=best_f;
end
end
function g=gradCentral(f,x,lo,hi)
h=1e-6*max(1,abs(x));g=zeros(size(x));for j=1:numel(x),xp=x;xm=x;xp(j)=min(hi(j),x(j)+h(j));xm(j)=max(lo(j),x(j)-h(j));w=xp(j)-xm(j);if w~=0,g(j)=(f(xp)-f(xm))/w;end,end
end
