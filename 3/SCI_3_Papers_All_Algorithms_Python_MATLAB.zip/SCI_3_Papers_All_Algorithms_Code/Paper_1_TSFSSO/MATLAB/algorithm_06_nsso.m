function [best,bestf,hist]=algorithm_06_nsso(f,ND,lo,hi,o)
% Algorithm 6. Source-specific normal parameters can be set in o.muN/o.sigN.
if nargin<5,o=struct;end;D=struct('NP',10,'M',50,'L',5,'mu',.9,'alpha',.5,'gamma',.9,'muN',0,'sigN',1);fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
lo=lo*ones(1,ND);hi=hi*ones(1,ND);X=lo+(hi-lo).*rand(o.NP,ND);V=.1*(hi-lo).*(2*rand(o.NP,ND)-1);fx=arrayfun(@(i)f(X(i,:)),(1:o.NP)');[bestf,j]=min(fx);best=X(j,:);hist=zeros(o.M+1,1);hist(1)=bestf;
for m=1:o.M,for i=1:o.NP,g=grad(f,X(i,:),lo,hi);trial=-o.mu*(o.muN+o.sigN*randn(1,ND)).*g+o.alpha*(o.muN+o.sigN*randn(1,ND)).*V(i,:);V(i,:)=sign(trial).*min(abs(trial),o.gamma*max(abs(V(i,:)),1e-12));z=max(lo,min(hi,X(i,:)+V(i,:)));C=z;for l=1:o.L,C(end+1,:)=max(lo,min(hi,z+(o.muN+o.sigN*randn(1,ND)).*z));end;cv=arrayfun(@(q)f(C(q,:)),(1:size(C,1))');[v,w]=min(cv);if v<=fx(i),X(i,:)=C(w,:);fx(i)=v;end;if fx(i)<bestf,bestf=fx(i);best=X(i,:);end,end;hist(m+1)=bestf;end
end
function g=grad(f,x,lo,hi),h=1e-6*max(1,abs(x));g=zeros(size(x));for j=1:numel(x),xp=x;xm=x;xp(j)=min(hi(j),x(j)+h(j));xm(j)=max(lo(j),x(j)-h(j));g(j)=(f(xp)-f(xm))/max(xp(j)-xm(j),eps);end,end
