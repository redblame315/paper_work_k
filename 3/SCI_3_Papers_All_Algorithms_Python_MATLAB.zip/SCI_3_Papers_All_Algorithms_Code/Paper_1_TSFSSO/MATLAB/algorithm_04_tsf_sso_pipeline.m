function out = algorithm_04_tsf_sso_pipeline(X,y,rules,fssoOpts)
% Paper 1 Algorithm 4. `rules` is a cell array: rules{r}{j}=[a b c].
if nargin<4,fssoOpts=struct;end;n=numel(y);cut=max(1,min(n-1,floor(.8*n)));Htr=design(X(1:cut,:),rules);[th0,~,~]=algorithm_01_rls_identification(Htr,y(1:cut),1e5);
span=max(1,abs(th0'));lo=th0'-2*span;hi=th0'+2*span;obj=@(th)sqrt(mean((y(1:cut)-Htr*th(:)).^2));
[th,bf,hist]=algorithm_03_fsso(obj,numel(th0),0,1,fssoOpts,th0'); % bounds replaced next line by scaled wrapper
% Re-run with direct bounds through normalized variable to preserve per-parameter bounds.
f=@(q)obj(lo+(hi-lo).*q);[q,~,hist]=algorithm_03_fsso(f,numel(th0),0,1,fssoOpts,(th0'-lo)./(hi-lo));th=lo+(hi-lo).*q;
Hte=design(X(cut+1:end,:),rules);yhtr=Htr*th(:);yhte=Hte*th(:);out=struct('thetaRLS',th0,'theta',th(:),'trainPrediction',yhtr,'testPrediction',yhte,'history',hist,'bestRMSE',bf);
end
function H=design(X,rules)
H=zeros(size(X,1),numel(rules)*(size(X,2)+1));for k=1:size(X,1),w=weights(X(k,:),rules);base=[1 X(k,:)];row=[];for r=1:numel(rules),row=[row w(r)*base];end;H(k,:)=row;end
end
function w=weights(x,rules)
raw=zeros(1,numel(rules));for r=1:numel(rules),v=1;for j=1:numel(x),abc=rules{r}{j};v=v*tri(x(j),abc);end;raw(r)=v;end;s=sum(raw);if s<=eps,w=ones(size(raw))/numel(raw);else,w=raw/s;end
end
function v=tri(x,a),if x<=a(1)||x>=a(3),v=0;elseif x==a(2),v=1;elseif x<a(2),v=(x-a(1))/(a(2)-a(1));else,v=(a(3)-x)/(a(3)-a(2));end,end
