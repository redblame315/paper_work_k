function [y,moved,CMA]=algorithm_01_ksi_moving_cloud_reasoning(inputs,premise,conseq,nDrops,J)
% premise rows [Ex En He]; conseq [Ex En He]. Eq.(29) J is symbolic.
if nargin<4,nDrops=200;end;if nargin<5,J=@normalRandomOperator;end;m=numel(inputs);CMA=zeros(1,m);
for j=1:m,a=premise(j,:);obs=inputCloud(inputs(j),a);nrn=zeros(nDrops,1);for k=1:nDrops,nrn(k)=J(a(2),obs(2),a(3),obs(3));end;cmf=(inputs(j)-a(1))-a(1)*nrn;CMA(j)=mean(cmf);end
ACMA=mean(CMA);moved=[conseq(1)+ACMA,conseq(2),conseq(3)];y=moved(1);
end
function z=normalRandomOperator(enRule,enInput,heRule,heInput),sc=max([abs(enRule),abs(enInput),1e-12]);z=(enInput-enRule)/sc+hypot(heRule,heInput)/sc*randn;end
function obs=inputCloud(x,p),obs=[x,max(1e-12,.5*(abs(p(2))+abs(x-p(1)))),p(3)];end
