%% KSI-principle moving-cloud reasoning and inverted-pendulum control
% Reference implementation for the manuscript. The paper defines J(.) in
% Eq. (29) symbolically; normalRandomOperator below is a reproducible
% Gaussian realization. Replace only that function if another J generator
% is used by the authors.
clear; clc; rng(7);

% Demonstration of Algorithm 1
premise = [-0.5 0.25 0.04; 0.0 0.25 0.04]; % [Ex En He]
conseq  = [0.0 0.30 0.04];
[y, moved, CMA] = ksiMovingCloudReasoning([-0.2 0.1], premise, conseq, 200);
fprintf('KSI moving-cloud output = %.6f, ACMA = %.6f\n', y, mean(CMA));

% Demonstration of Algorithms 3-4
[t,X,U] = simulateClosedLoop(10,0.002,[0;0.12;0;0],0.12);
fprintf('Final state: '); fprintf(' %.5f',X(end,:)); fprintf('\n');
figure; subplot(2,1,1); plot(t,X(:,1),t,X(:,2)); grid on; legend('r','theta');
subplot(2,1,2); plot(t,U); grid on; ylabel('u'); xlabel('time (s)');

function mu = expectedCurve(x,c)
    en=max(abs(c(2)),1e-12); mu=exp(-0.5*((x-c(1))/en).^2);
end

function z = normalRandomOperator(enRule,enInput,heRule,heInput)
    sc=max([abs(enRule),abs(enInput),1e-12]);
    mu=(enInput-enRule)/sc; sig=hypot(heRule,heInput)/sc;
    z=mu+sig*randn;
end

function obs = inputCloud(x,premise)
    obs=[x, max(1e-12,0.5*(abs(premise(2))+abs(x-premise(1)))), premise(3)];
end

function [y,moved,CMA] = ksiMovingCloudReasoning(inputs,premise,conseq,nDrops)
    % Algorithm 1: O(m*nDrops) time, O(nDrops) working memory.
    m=numel(inputs); CMA=zeros(1,m);
    for j=1:m
        a=premise(j,:); obs=inputCloud(inputs(j),a); nrn=zeros(nDrops,1);
        for k=1:nDrops
            nrn(k)=normalRandomOperator(a(2),obs(2),a(3),obs(3));
        end
        cmf=(inputs(j)-a(1))-a(1)*nrn;
        CMA(j)=mean(cmf);
    end
    ACMA=mean(CMA); moved=[conseq(1)+ACMA,conseq(2),conseq(3)]; y=moved(1);
end

function u = stabilizationPriority(theta,thetaDot,r,rDot,k)
    % Algorithm 2: pendulum-first qualitative stabilization law.
    if nargin<5, k=[25 7 1.5 2.5]; end
    u=k(1)*theta+k(2)*thetaDot+k(3)*r+k(4)*rDot;
end

function [As,Bs] = localModels()
    A1=[0 0 1 0;0 0 0 1;0 .861 -7.929 -.0348;0 48.72 -34.81 -1.971];
    A2=[0 0 1 0;0 0 0 1;0 .9466 -8.019 -.03705;0 50.79 -32.51 -1.993];
    As=cat(3,A1,A2,A1);
    B1=[0;0;.793;3.487]; B2=[0;0;.800;3.775]; Bs=cat(3,B1,B2,B1);
end

function w = cloudRuleWeights(theta)
    c=[-.5 0 .5]; width=.35; w=exp(-.5*((theta-c)/width).^2); w=w/sum(w);
end

function u = ksiCloudController(x,he)
    % Algorithm 3: local LQR controllers blended by cloud rule weights.
    [As,Bs]=localModels(); Q=diag([12 45 2 4]); R=1;
    w=cloudRuleWeights(x(2)); w=max(0,w+he*.02*randn(1,3)); w=w/sum(w);
    u=0;
    for i=1:3
        K=lqr(As(:,:,i),Bs(:,:,i),Q,R); u=u+w(i)*(-K*x);
    end
end

function dx = blendedDynamics(x,u)
    [As,Bs]=localModels(); w=cloudRuleWeights(x(2)); A=zeros(4); B=zeros(4,1);
    for i=1:3, A=A+w(i)*As(:,:,i); B=B+w(i)*Bs(:,:,i); end
    dx=A*x+B*u;
end

function [t,X,U] = simulateClosedLoop(tEnd,dt,x0,he)
    % Algorithm 4: RK4 closed-loop simulation and data collection.
    t=(0:dt:tEnd)'; X=zeros(numel(t),4); U=zeros(numel(t),1); X(1,:)=x0(:)';
    for k=1:numel(t)-1
        x=X(k,:)'; u=ksiCloudController(x,he); U(k)=u;
        f=@(z) blendedDynamics(z,u); h=dt;
        k1=f(x); k2=f(x+.5*h*k1); k3=f(x+.5*h*k2); k4=f(x+h*k3);
        X(k+1,:)=(x+h*(k1+2*k2+2*k3+k4)/6)';
    end
    U(end)=ksiCloudController(X(end,:)',he);
end
