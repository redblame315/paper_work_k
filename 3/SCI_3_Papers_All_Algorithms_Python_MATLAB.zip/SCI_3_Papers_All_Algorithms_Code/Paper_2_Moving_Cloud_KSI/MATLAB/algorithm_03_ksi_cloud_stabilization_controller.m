function [u,w,local]=algorithm_03_ksi_cloud_stabilization_controller(x,he,uMax)
if nargin<2,he=.12;end;if nargin<3,uMax=40;end
[A,B]=localModels();Q=diag([12 45 2 4]);R=1;w=cloudWeights(x(2));w=max(0,w+he*.02*randn(1,3));w=w/sum(w);local=zeros(1,3);for i=1:3,K=lqr(A(:,:,i),B(:,:,i),Q,R);local(i)=-K*x;end;u=w*local';upr=algorithm_02_pendulum_first_stabilization(x);if sign(u)~=sign(upr)&&abs(x(2))>.02,u=upr;end;u=max(-uMax,min(uMax,u));
end
function w=cloudWeights(th),c=[-.5 0 .5];wd=.35;w=exp(-.5*((th-c)/wd).^2);w=w/sum(w);end
function [A,B]=localModels(),A1=[0 0 1 0;0 0 0 1;0 .861 -7.929 -.0348;0 48.72 -34.81 -1.971];A2=[0 0 1 0;0 0 0 1;0 .9466 -8.019 -.03705;0 50.79 -32.51 -1.993];A=cat(3,A1,A2,A1);B1=[0;0;.793;3.487];B2=[0;0;.800;3.775];B=cat(3,B1,B2,B1);end
