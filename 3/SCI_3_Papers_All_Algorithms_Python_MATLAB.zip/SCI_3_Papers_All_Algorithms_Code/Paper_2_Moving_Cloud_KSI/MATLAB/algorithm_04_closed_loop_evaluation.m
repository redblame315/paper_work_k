function out=algorithm_04_closed_loop_evaluation(x0,dt,tEnd,he)
if nargin<1,x0=[0;.12;0;0];end;if nargin<2,dt=.002;end;if nargin<3,tEnd=10;end;if nargin<4,he=.12;end
t=(0:dt:tEnd)';X=zeros(numel(t),4);U=zeros(numel(t),1);tim=zeros(numel(t),1);X(1,:)=x0(:)';for k=1:numel(t)-1,x=X(k,:)';tic;u=algorithm_03_ksi_cloud_stabilization_controller(x,he);tim(k)=toc;U(k)=u;f=@(z)dyn(z,u);h=dt;k1=f(x);k2=f(x+.5*h*k1);k3=f(x+.5*h*k2);k4=f(x+h*k3);X(k+1,:)=(x+h*(k1+2*k2+2*k3+k4)/6)';end;U(end)=algorithm_03_ksi_cloud_stabilization_controller(X(end,:)',he);out=struct('t',t,'X',X,'U',U,'cartOvershoot',max(abs(X(:,1))),'pendulumOvershoot',max(abs(X(:,2))),'meanReasoningTime',mean(tim(1:end-1)));
end
function dx=dyn(x,u),[A,B]=models();w=weights(x(2));Ab=zeros(4);Bb=zeros(4,1);for i=1:3,Ab=Ab+w(i)*A(:,:,i);Bb=Bb+w(i)*B(:,:,i);end;dx=Ab*x+Bb*u;end
function w=weights(th),c=[-.5 0 .5];wd=.35;w=exp(-.5*((th-c)/wd).^2);w=w/sum(w);end
function [A,B]=models(),A1=[0 0 1 0;0 0 0 1;0 .861 -7.929 -.0348;0 48.72 -34.81 -1.971];A2=[0 0 1 0;0 0 0 1;0 .9466 -8.019 -.03705;0 50.79 -32.51 -1.993];A=cat(3,A1,A2,A1);B1=[0;0;.793;3.487];B2=[0;0;.800;3.775];B=cat(3,B1,B2,B1);end
