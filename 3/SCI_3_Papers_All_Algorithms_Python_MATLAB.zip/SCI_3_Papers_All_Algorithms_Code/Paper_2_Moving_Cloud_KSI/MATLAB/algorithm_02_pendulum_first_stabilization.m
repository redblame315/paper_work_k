function u=algorithm_02_pendulum_first_stabilization(x,o)
if nargin<2,o=struct;end;D=struct('thetaTol',.02,'thetaDotTol',.05,'kTheta',25,'kThetaDot',7,'kR',1.5,'kRDot',2.5,'uMax',40);fn=fieldnames(D);for k=1:numel(fn),if ~isfield(o,fn{k}),o.(fn{k})=D.(fn{k});end,end
r=x(1);th=x(2);rd=x(3);td=x(4);pole=o.kTheta*th+o.kThetaDot*td;if abs(th)<=o.thetaTol && abs(td)<=o.thetaDotTol,cart=o.kR*r+o.kRDot*rd;else,cart=0;end;u=max(-o.uMax,min(o.uMax,pole+cart));
end
