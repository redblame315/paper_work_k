# Paper 2 — KSI Moving Cloud Reasoning / Inverted Pendulum

Four numbered algorithms are supplied as separate Python and MATLAB files. The consolidated Python/MATLAB programs already included in the upgraded manuscript supplement are also copied here verbatim as `supplement_consolidated_reference.*`.

Important: the paper itself defines `J(En_rule, En_input, He_rule, He_input)` symbolically. The code retains the manuscript's transparent Gaussian reference realization and isolates it so the authors can replace it without changing the rest of Algorithm 1.
