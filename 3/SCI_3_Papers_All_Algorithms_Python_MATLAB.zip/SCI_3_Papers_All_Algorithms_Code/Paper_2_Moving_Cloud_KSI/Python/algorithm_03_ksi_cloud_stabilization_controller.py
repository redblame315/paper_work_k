"""Paper 2, Algorithm 3: KSI moving-cloud stabilization controller."""
from __future__ import annotations
import numpy as np
from common import A1,A2,A3,B1,B2,B3,lqr_gain,cloud_rule_weights
from algorithm_02_pendulum_first_stabilization import pendulum_first_stabilization

def ksi_cloud_controller(state,he=0.12,u_max=40.0,seed=7):
    x=np.asarray(state,float).reshape(4); As=(A1,A2,A3); Bs=(B1,B2,B3); Ks=[lqr_gain(A,B) for A,B in zip(As,Bs)]
    # N/Z/P cloud-rule weights; hyper-entropy perturbation is the same transparent executable realization used in the manuscript supplement.
    w=cloud_rule_weights(x[1]); rng=np.random.default_rng(seed); w=np.maximum(0.0,w+rng.normal(0.0,he*0.02,size=3)); w=w/max(w.sum(),1e-12)
    local=np.array([float(-(K@x.reshape(-1,1))[0,0]) for K in Ks]); u=float(w@local)
    # Enforce Algorithm-2 priority without overriding a stronger stabilizing local-control command.
    upr=pendulum_first_stabilization(x,u_max=u_max)
    if np.sign(u)!=np.sign(upr) and abs(x[1])>0.02: u=upr
    return float(np.clip(u,-u_max,u_max)),w,local
