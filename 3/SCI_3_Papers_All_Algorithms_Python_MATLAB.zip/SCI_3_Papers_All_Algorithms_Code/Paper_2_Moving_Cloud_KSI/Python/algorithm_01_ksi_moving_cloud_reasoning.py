"""Paper 2, Algorithm 1: KSI-principle moving-cloud reasoning.
Eq. (29) leaves J(.) symbolic; Gaussian J is the manuscript's transparent reproducibility realization.
"""
from __future__ import annotations
import numpy as np
from common import Cloud,input_cloud,normal_random_operator

def ksi_moving_cloud_reasoning(inputs,premise_clouds,consequent:Cloud,n_drops=200,seed=7,J=None):
    x=np.asarray(inputs,float); rng=np.random.default_rng(seed); J=J or normal_random_operator
    if len(x)!=len(premise_clouds): raise ValueError('one premise cloud per input required')
    cma=[]
    for xj,aj in zip(x,premise_clouds):
        obs=input_cloud(float(xj),aj); nrn=np.array([J(aj.en,obs.en,aj.he,obs.he,rng) for _ in range(n_drops)])
        cmf=(xj-aj.ex)-aj.ex*nrn                              # Eq. (30)-style reference realization
        cma.append(float(np.mean(cmf)))
    acma=float(np.mean(cma)); moved=Cloud(consequent.ex+acma,consequent.en,consequent.he); y=moved.ex
    return y,moved,{'CMA':np.asarray(cma),'ACMA':acma}
