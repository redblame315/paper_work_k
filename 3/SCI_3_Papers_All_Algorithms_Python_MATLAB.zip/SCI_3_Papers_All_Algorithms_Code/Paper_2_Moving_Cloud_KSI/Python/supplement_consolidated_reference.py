"""Reference implementation for KSI-principle moving-cloud reasoning and inverted-pendulum control.

The manuscript defines the normal-random operator J(En_rule, En_input, He_rule, He_input)
symbolically. `normal_random_operator` below provides a reproducible Gaussian realization;
if the authors use a different J generator, replace only that function.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from scipy.linalg import solve_continuous_are

EPS = 1e-12

@dataclass
class Cloud:
    ex: float
    en: float
    he: float


def expected_curve(x: np.ndarray | float, c: Cloud) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return np.exp(-0.5 * ((x - c.ex) / max(abs(c.en), EPS)) ** 2)


def sign_gate(z: float) -> float:
    """Left/right selector used by the piecewise cloud-width equations."""
    return float(min(1.0 - np.sign(z), 1.0))


def normal_random_operator(en_rule: float, en_input: float,
                           he_rule: float, he_input: float,
                           rng: np.random.Generator) -> float:
    """Explicit reproducible realization of the symbolic J(.) in Eq. (29)."""
    scale = max(abs(en_rule), abs(en_input), EPS)
    mu = (en_input - en_rule) / scale
    sigma = np.hypot(he_rule, he_input) / scale
    return float(rng.normal(mu, sigma))


def input_cloud(x: float, premise: Cloud, he_input: float | None = None) -> Cloud:
    """Cloudify a crisp input: its expectation is x; entropy follows the premise scale."""
    if he_input is None:
        he_input = premise.he
    distance = abs(x - premise.ex)
    en = max(EPS, 0.5 * (abs(premise.en) + distance))
    return Cloud(float(x), float(en), float(he_input))


def ksi_moving_cloud_reasoning(inputs, premise_clouds, consequent: Cloud,
                               n_drops: int = 200, seed: int = 7):
    """Algorithm 1: m-input/single-output KSI moving-cloud reasoning.

    Returns crisp output, moved output cloud, and diagnostic moving amounts.
    Complexity: O(m*n_drops) time and O(n_drops) working memory.
    """
    x = np.asarray(inputs, dtype=float)
    if len(x) != len(premise_clouds):
        raise ValueError("one premise cloud is required for each input")
    rng = np.random.default_rng(seed)
    cma = []
    for xj, aj in zip(x, premise_clouds):
        obs = input_cloud(float(xj), aj)
        nrn = np.array([
            normal_random_operator(aj.en, obs.en, aj.he, obs.he, rng)
            for _ in range(n_drops)
        ])
        # Eq. (30)-style moving function; Ex is the rule-cloud expectation.
        cmf = (xj - aj.ex) - aj.ex * nrn
        cma.append(float(np.mean(cmf)))
    acma = float(np.mean(cma))
    moved = Cloud(consequent.ex + acma, consequent.en, consequent.he)
    y = moved.ex  # de-cloudification, Eq. (42)
    return y, moved, {"CMA": np.asarray(cma), "ACMA": acma}


def stabilization_priority(theta: float, theta_dot: float,
                           r: float, r_dot: float,
                           k=(25.0, 7.0, 1.5, 2.5)) -> float:
    """Algorithm 2: pendulum-first qualitative stabilization law."""
    k1, k2, k3, k4 = k
    return float(k1*theta + k2*theta_dot + k3*r + k4*r_dot)

# Local models reported in Section 4.2
A1 = np.array([[0,0,1,0],[0,0,0,1],[0,0.861,-7.929,-0.0348],[0,48.72,-34.81,-1.971]],float)
A2 = np.array([[0,0,1,0],[0,0,0,1],[0,0.9466,-8.019,-0.03705],[0,50.79,-32.51,-1.993]],float)
A3 = A1.copy()
B1 = np.array([[0],[0],[0.793],[3.487]],float)
B2 = np.array([[0],[0],[0.800],[3.775]],float)
B3 = B1.copy()


def lqr_gain(A, B, Q=None, R=None):
    if Q is None: Q = np.diag([12., 45., 2., 4.])
    if R is None: R = np.array([[1.]])
    P = solve_continuous_are(A, B, Q, R)
    return np.linalg.solve(R, B.T @ P)


def cloud_rule_weights(theta: float, centers=(-0.5,0.0,0.5), width=0.35):
    w = np.exp(-0.5*((theta-np.asarray(centers))/width)**2)
    return w / max(w.sum(), EPS)


def ksi_cloud_controller(state: np.ndarray, he: float = 0.12,
                         seed: int = 7) -> float:
    """Algorithm 3: three-rule local-controller blending with KSI/cloud uncertainty."""
    x = np.asarray(state, dtype=float).reshape(4)
    As, Bs = (A1,A2,A3), (B1,B2,B3)
    Ks = [lqr_gain(A,B) for A,B in zip(As,Bs)]
    w = cloud_rule_weights(x[1])
    # Hyper-entropy perturbs the normalized firing strengths reproducibly.
    rng = np.random.default_rng(seed)
    pert = np.maximum(0.0, w + rng.normal(0.0, he*0.02, size=3))
    w = pert / max(pert.sum(), EPS)
    u = 0.0
    for wi, Ki in zip(w, Ks):
        u += wi * float(-(Ki @ x.reshape(-1,1))[0,0])
    return float(u)


def blended_dynamics(state: np.ndarray, u: float):
    x=np.asarray(state,float).reshape(4,1)
    w=cloud_rule_weights(float(x[1,0]))
    A=sum(wi*A for wi,A in zip(w,(A1,A2,A3)))
    B=sum(wi*B for wi,B in zip(w,(B1,B2,B3)))
    return (A@x+B*u).ravel()


def simulate(t_end=10.0, dt=0.002, x0=(0.0,0.12,0.0,0.0), he=0.12):
    """Algorithm 4: closed-loop RK4 simulation and performance data collection."""
    t=np.arange(0.0,t_end+dt,dt); X=np.zeros((t.size,4)); U=np.zeros(t.size)
    X[0]=x0
    for k in range(t.size-1):
        u=ksi_cloud_controller(X[k],he=he,seed=7+k); U[k]=u
        f=lambda z: blended_dynamics(z,u)
        h=dt; k1=f(X[k]); k2=f(X[k]+0.5*h*k1); k3=f(X[k]+0.5*h*k2); k4=f(X[k]+h*k3)
        X[k+1]=X[k]+h*(k1+2*k2+2*k3+k4)/6
    U[-1]=ksi_cloud_controller(X[-1],he=he,seed=7+t.size)
    return t,X,U

if __name__ == "__main__":
    premise=[Cloud(-0.5,0.25,0.04),Cloud(0.0,0.25,0.04)]
    y,cloud,diag=ksi_moving_cloud_reasoning([-.2,.1],premise,Cloud(0,0.3,0.04))
    print("KSI moving-cloud output:",y,"ACMA:",diag["ACMA"])
    t,X,U=simulate()
    print("final state:",X[-1],"peak |u|:",np.max(np.abs(U)))
