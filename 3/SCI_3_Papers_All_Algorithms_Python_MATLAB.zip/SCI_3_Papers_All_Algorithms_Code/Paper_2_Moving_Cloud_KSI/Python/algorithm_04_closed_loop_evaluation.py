"""Paper 2, Algorithm 4: closed-loop simulation / experimental evaluation."""
from __future__ import annotations
import time,numpy as np
from common import blended_dynamics
from algorithm_03_ksi_cloud_stabilization_controller import ksi_cloud_controller

def closed_loop_evaluation(x0=(0,.12,0,0),dt=.002,t_end=10.0,he=.12,settle_tol=(.02,.02)):
    t=np.arange(0,t_end+dt,dt); X=np.zeros((len(t),4)); U=np.zeros(len(t)); elapsed=np.zeros(len(t)); X[0]=x0
    for k in range(len(t)-1):
        tic=time.perf_counter(); u,_,_=ksi_cloud_controller(X[k],he=he,seed=7+k); elapsed[k]=time.perf_counter()-tic; U[k]=u
        f=lambda z: blended_dynamics(z,u); h=dt; k1=f(X[k]);k2=f(X[k]+.5*h*k1);k3=f(X[k]+.5*h*k2);k4=f(X[k]+h*k3);X[k+1]=X[k]+h*(k1+2*k2+2*k3+k4)/6
    U[-1]=ksi_cloud_controller(X[-1],he=he,seed=7+len(t))[0]
    overshoot={'cart':float(np.max(np.abs(X[:,0]))),'pendulum':float(np.max(np.abs(X[:,1])))}
    ok=(np.abs(X[:,0])<=settle_tol[0])&(np.abs(X[:,1])<=settle_tol[1]); settling=np.nan
    for k in range(len(t)):
        if np.all(ok[k:]): settling=float(t[k]);break
    return {'t':t,'state':X,'u':U,'overshoot':overshoot,'settling_time':settling,'mean_reasoning_time_s':float(np.mean(elapsed[:-1])),'converged':bool(ok[-1])}
