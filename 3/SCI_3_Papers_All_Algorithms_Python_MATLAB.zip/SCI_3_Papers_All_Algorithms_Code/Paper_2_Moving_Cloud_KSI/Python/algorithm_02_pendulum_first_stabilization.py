"""Paper 2, Algorithm 2: pendulum-first stabilization logic."""
from __future__ import annotations
import numpy as np

def pendulum_first_stabilization(state,theta_tol=0.02,theta_dot_tol=0.05,k_theta=25.0,k_theta_dot=7.0,k_r=1.5,k_r_dot=2.5,u_max=40.0):
    r,theta,r_dot,theta_dot=map(float,state)
    # Pendulum gets priority. The sign follows the manuscript qualitative right/left corrective rule.
    pole=k_theta*theta+k_theta_dot*theta_dot
    if abs(theta)<=theta_tol and abs(theta_dot)<=theta_dot_tol:
        cart=k_r*r+k_r_dot*r_dot
    else:
        cart=0.0
    u=pole+cart
    return float(np.clip(u,-u_max,u_max))
