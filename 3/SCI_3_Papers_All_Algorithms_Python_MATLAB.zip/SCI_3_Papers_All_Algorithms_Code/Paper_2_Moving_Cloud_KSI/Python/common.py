from __future__ import annotations
from dataclasses import dataclass
import numpy as np
EPS=1e-12
@dataclass
class Cloud: ex: float; en: float; he: float

def expected_curve(x,c): x=np.asarray(x,float); return np.exp(-0.5*((x-c.ex)/max(abs(c.en),EPS))**2)
def normal_random_operator(en_rule,en_input,he_rule,he_input,rng):
    scale=max(abs(en_rule),abs(en_input),EPS); mu=(en_input-en_rule)/scale; sigma=np.hypot(he_rule,he_input)/scale; return float(rng.normal(mu,sigma))
def input_cloud(x,premise,he_input=None):
    if he_input is None: he_input=premise.he
    en=max(EPS,0.5*(abs(premise.en)+abs(x-premise.ex))); return Cloud(float(x),float(en),float(he_input))
def cloud_rule_weights(theta,centers=(-.5,0,.5),width=.35):
    w=np.exp(-0.5*((theta-np.asarray(centers))/width)**2); return w/max(w.sum(),EPS)
A1=np.array([[0,0,1,0],[0,0,0,1],[0,.861,-7.929,-.0348],[0,48.72,-34.81,-1.971]],float)
A2=np.array([[0,0,1,0],[0,0,0,1],[0,.9466,-8.019,-.03705],[0,50.79,-32.51,-1.993]],float)
A3=A1.copy(); B1=np.array([[0],[0],[.793],[3.487]],float); B2=np.array([[0],[0],[.800],[3.775]],float); B3=B1.copy()
def lqr_gain(A,B,Q=None,R=None):
    from scipy.linalg import solve_continuous_are
    if Q is None: Q=np.diag([12.,45.,2.,4.])
    if R is None: R=np.array([[1.]])
    P=solve_continuous_are(A,B,Q,R); return np.linalg.solve(R,B.T@P)
def blended_dynamics(state,u):
    x=np.asarray(state,float).reshape(4,1); w=cloud_rule_weights(float(x[1,0])); A=sum(wi*A for wi,A in zip(w,(A1,A2,A3))); B=sum(wi*B for wi,B in zip(w,(B1,B2,B3))); return (A@x+B*u).ravel()
