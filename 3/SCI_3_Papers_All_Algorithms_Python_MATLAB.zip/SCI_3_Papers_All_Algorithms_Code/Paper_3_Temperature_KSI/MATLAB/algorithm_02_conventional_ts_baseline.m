function [yhat,w,phi,theta,P,e]=algorithm_02_conventional_ts_baseline(x,membershipRules,theta,P,y,lambda)
if nargin<6,lambda=1;end;R=numel(membershipRules);raw=zeros(1,R);for r=1:R,v=1;for j=1:numel(x),v=v*membershipRules{r}{j}(x(j));end;raw(r)=v;end;s=sum(raw);if s<=eps,w=ones(1,R)/R;else,w=raw/s;end;base=[1 x(:)'];phi=[];for r=1:R,phi=[phi w(r)*base];end;yhat=phi*theta;e=[];if nargin>=5&&~isempty(y),den=lambda+phi*P*phi';K=P*phi'/den;e=y-yhat;theta=theta+K*e;P=(P-K*phi*P)/lambda;end
end
