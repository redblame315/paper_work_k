function report=algorithm_03_three_stage_modeling(cells,rules,lags,lambda,activationMode)
% `cells` struct fields each contain voltage/current/temperature vectors.
if nargin<3,lags=1;end;if nargin<4,lambda=1;end;if nargin<5,activationMode='equation4';end;names=fieldnames(cells);report=struct;
for c=1:numel(names),d=cells.(names{c});[Z,y]=syncReg(d.voltage,d.current,d.temperature,lags);valid=all(isfinite(Z),2);Z=Z(valid,:);y=y(valid);fit=algorithm_01_ksi_ts_identification(Z,y,rules,lambda,[],[],isfinite(y),activationMode);m=isfinite(y);e=abs(y(m)-fit.prediction(m));v=struct('maxDeviation',max(e),'minDeviation',min(e),'meanDeviation',mean(e),'nMeasured',numel(e));report.(names{c})=struct('model',fit,'verification',v);end
end
function [Z,y]=syncReg(V,I,T,l),N=min([numel(V),numel(I),numel(T)]);V=V(1:N);I=I(1:N);T=T(1:N);Z=[];y=[];for k=l+1:N,Z(end+1,:)=[V(k-l:k)' I(k-l:k)'];y(end+1,1)=T(k);end,end
