function [state,out]=algorithm_04_realtime_deployment(state,z,measuredT)
% state fields: rules, theta, P, lambda, activationMode. One call = one online cycle.
if nargin<3,measuredT=[];end;if any(~isfinite(z)),out=struct('prediction',NaN,'residual',NaN,'flag','invalid_input');return;end
[phi,w]=regrow(z,state.rules,state.activationMode);pred=phi*state.theta;res=NaN;if ~isempty(measuredT)&&isfinite(measuredT),den=state.lambda+phi*state.P*phi';K=state.P*phi'/den;res=measuredT-pred;state.theta=state.theta+K*res;state.P=(state.P-K*phi*state.P)/state.lambda;end;out=struct('prediction',pred,'residual',res,'weights',w,'flag','ok');
end
function [phi,w]=regrow(z,rules,mode),R=numel(rules);raw=zeros(1,R);for r=1:R,d=zeros(1,numel(z));for j=1:numel(z),d(j)=mr(z(j),rules{r}{j});end;if strcmp(mode,'equation4'),raw(r)=1-min(d);else,raw(r)=prod(d);end,end;s=sum(raw);if s<=eps,w=ones(1,R)/R;else,w=raw/s;end;base=[1 z(:)'];phi=[];for r=1:R,phi=[phi w(r)*base];end,end
function d=mr(x,A),k=lower(A.kind);p=A.points;if strcmp(k,'s'),if x<p(1),d=1;elseif x>=p(2),d=0;else,d=(p(2)-x)/(p(2)-p(1));end;elseif strcmp(k,'z'),if x<=p(1),d=0;elseif x>p(2),d=1;else,d=(x-p(1))/(p(2)-p(1));end;else,if x<p(1)||x>=p(4),d=1;elseif x<=p(2),d=(p(2)-x)/(p(2)-p(1));elseif x<=p(3),d=0;else,d=(x-p(3))/(p(4)-p(3));end;end,end
