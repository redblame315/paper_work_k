function out=algorithm_01_ksi_ts_identification(Z,y,rules,lambda,theta,P,measured,activationMode)
% rules{r}{j}=struct('kind','s|z|trap','points',[...]). Default follows numbered Eq.(4).
if nargin<4,lambda=1;end;p=numel(rules)*(size(Z,2)+1);if nargin<5||isempty(theta),theta=zeros(p,1);end;if nargin<6||isempty(P),P=1e5*eye(p);end;if nargin<7||isempty(measured),measured=isfinite(y);end;if nargin<8,activationMode='equation4';end
pred=zeros(size(Z,1),1);err=nan(size(pred));W=zeros(size(Z,1),numel(rules));
for k=1:size(Z,1),[phi,w]=regrow(Z(k,:),rules,activationMode);pred(k)=phi*theta;W(k,:)=w;if measured(k)&&isfinite(y(k)),den=lambda+phi*P*phi';K=P*phi'/den;err(k)=y(k)-pred(k);theta=theta+K*err(k);P=(P-K*phi*P)/lambda;end,end
out=struct('theta',theta,'P',P,'prediction',pred,'error',err,'weights',W);
end
function [phi,w]=regrow(z,rules,mode),R=numel(rules);raw=zeros(1,R);for r=1:R,d=zeros(1,numel(z));for j=1:numel(z),d(j)=mr(z(j),rules{r}{j});end;if strcmp(mode,'equation4'),raw(r)=1-min(d);elseif strcmp(mode,'pseudocode_product'),raw(r)=prod(d);else,error('bad mode');end,end;s=sum(raw);if s<=eps,w=ones(1,R)/R;else,w=raw/s;end;base=[1 z];phi=[];for r=1:R,phi=[phi w(r)*base];end,end
function d=mr(x,A),k=lower(A.kind);p=A.points;if strcmp(k,'s'),xa=p(1);xc=p(2);if x<xa,d=1;elseif x>=xc,d=0;else,d=(xc-x)/(xc-xa);end;elseif strcmp(k,'z'),xa=p(1);xc=p(2);if x<=xa,d=0;elseif x>xc,d=1;else,d=(x-xa)/(xc-xa);end;else,x1=p(1);x2=p(2);x3=p(3);x4=p(4);if x<x1||x>=x4,d=1;elseif x<=x2,d=(x2-x)/(x2-x1);elseif x<=x3,d=0;else,d=(x-x3)/(x4-x3);end;end,end
