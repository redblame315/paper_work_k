# Paper 3 — KSI Aluminium-Electrolysis Temperature Prediction

Algorithms 1–4 are supplied in both languages.

## Important equation/pseudocode discrepancy retained transparently

The manuscript's numbered Eq. (4) states `d_i = 1 - min_j(d_ij)`, while the later upgraded pseudocode calls the rule activation a product of moving rates. The code therefore supports both:

* `activation_mode='equation4'` (default): reproduce the numbered mathematical equation.
* `activation_mode='pseudocode_product'`: reproduce the later pseudocode wording.

This package does not silently choose one and pretend the other does not exist.
