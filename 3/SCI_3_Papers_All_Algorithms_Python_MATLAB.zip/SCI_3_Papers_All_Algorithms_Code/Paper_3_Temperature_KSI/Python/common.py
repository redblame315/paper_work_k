from __future__ import annotations
from dataclasses import dataclass
import numpy as np
EPS=1e-12
@dataclass(frozen=True)
class Antecedent:
    kind: str                 # 's', 'z', or 'trap'
    points: tuple             # (xa,xc) or (x1,x2,x3,x4)

def moving_rate(x,A:Antecedent):
    """Exact piecewise d_ij from manuscript Eqs. (1)-(3)."""
    x=float(x); k=A.kind.lower(); p=A.points
    if k=='s':
        xa,xc=map(float,p)
        if x<xa: return 1.0
        if x>=xc: return 0.0
        return (xc-x)/max(xc-xa,EPS)
    if k=='z':
        xa,xc=map(float,p)
        if x<=xa: return 0.0
        if x>xc: return 1.0
        return (x-xa)/max(xc-xa,EPS)
    if k in ('trap','trapezoid','trapezoidal'):
        x1,x2,x3,x4=map(float,p)
        if x<x1 or x>=x4: return 1.0
        if x<=x2: return (x2-x)/max(x2-x1,EPS)
        if x<=x3: return 0.0
        return (x-x3)/max(x4-x3,EPS)
    raise ValueError('kind must be s, z, or trap')

def rule_weights(z,rules,activation_mode='equation4'):
    """Rule normalization. `equation4` exactly implements d_i=1-min_j d_ij.
    `pseudocode_product` implements the later upgraded pseudocode beta_i=prod_j moving_rate.
    """
    z=np.asarray(z,float); raw=[]
    for rule in rules:
        d=np.array([moving_rate(v,A) for v,A in zip(z,rule)],float)
        if activation_mode=='equation4': a=1.0-float(np.min(d))
        elif activation_mode=='pseudocode_product': a=float(np.prod(d))
        else: raise ValueError('unknown activation_mode')
        raw.append(max(0.0,a))
    raw=np.asarray(raw,float); s=raw.sum(); return raw/(s+EPS) if s>EPS else np.full(len(raw),1/len(raw))

def regression_row(z,rules,activation_mode='equation4'):
    w=rule_weights(z,rules,activation_mode); base=np.r_[1.0,np.asarray(z,float)]; return np.concatenate([wi*base for wi in w]),w

def rls_step(theta,P,phi,y,lam=1.0):
    theta=np.asarray(theta,float);P=np.asarray(P,float);phi=np.asarray(phi,float);den=lam+float(phi@P@phi);K=(P@phi)/den;e=float(y-phi@theta);theta=theta+K*e;P=(P-np.outer(K,phi)@P)/lam;return theta,P,e,K
