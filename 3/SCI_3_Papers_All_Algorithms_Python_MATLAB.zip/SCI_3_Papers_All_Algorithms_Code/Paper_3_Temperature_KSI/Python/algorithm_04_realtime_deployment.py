"""Paper 3, Algorithm 4: real-time deployment and event-driven parameter update."""
from __future__ import annotations
import numpy as np
from common import regression_row,rls_step

class RealtimeKSITSPredictor:
    def __init__(self,rules,theta,P,lam=1.0,activation_mode='equation4'):
        self.rules=rules;self.theta=np.asarray(theta,float).copy();self.P=np.asarray(P,float).copy();self.lam=lam;self.activation_mode=activation_mode;self.log=[]
    def step(self,z,measured_temperature=None):
        z=np.asarray(z,float)
        if not np.all(np.isfinite(z)): return {'prediction':np.nan,'flag':'invalid_input'}
        phi,w=regression_row(z,self.rules,self.activation_mode);pred=float(phi@self.theta);res=np.nan
        if measured_temperature is not None and np.isfinite(measured_temperature):
            self.theta,self.P,res,_=rls_step(self.theta,self.P,phi,float(measured_temperature),self.lam)
        rec={'prediction':pred,'residual':res,'weights':w.copy(),'flag':'ok'};self.log.append(rec);return rec
