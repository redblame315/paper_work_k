"""Paper 3, Algorithm 3: three-stage aluminium-cell temperature modeling procedure."""
from __future__ import annotations
import numpy as np
from algorithm_01_ksi_ts_identification import ksi_ts_identification

def synchronize_and_regress(voltage,current,temperature,lags=1):
    V=np.asarray(voltage,float);I=np.asarray(current,float);T=np.asarray(temperature,float);N=min(len(V),len(I),len(T));V=V[:N];I=I[:N];T=T[:N];Z=[];Y=[]
    for k in range(lags,N): Z.append(np.r_[V[k-lags:k+1],I[k-lags:k+1]]);Y.append(T[k])
    return np.asarray(Z),np.asarray(Y)

def three_stage_modeling(cells,rules,lags=1,lam=1.0,activation_mode='equation4'):
    report={}
    for cid,data in cells.items():
        Z,y=synchronize_and_regress(data['voltage'],data['current'],data['temperature'],lags); valid=np.all(np.isfinite(Z),axis=1);Z=Z[valid];y=y[valid]; measured=np.isfinite(y)
        fit=ksi_ts_identification(Z,y,rules,lam=lam,measured_mask=measured,activation_mode=activation_mode)
        e=y[measured]-fit['prediction'][measured]; ae=np.abs(e)
        report[cid]={'model':fit,'verification':{'max_deviation':float(ae.max()) if ae.size else np.nan,'min_deviation':float(ae.min()) if ae.size else np.nan,'mean_deviation':float(ae.mean()) if ae.size else np.nan,'n_measured':int(ae.size)}}
    return report
