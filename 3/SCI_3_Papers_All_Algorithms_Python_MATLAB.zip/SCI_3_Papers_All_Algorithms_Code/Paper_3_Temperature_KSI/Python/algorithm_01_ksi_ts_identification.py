"""Paper 3, Algorithm 1: online KSI-based dynamic T-S identification."""
from __future__ import annotations
import numpy as np
from common import regression_row,rls_step

def ksi_ts_identification(Z,y,rules,lam=1.0,theta0=None,P0=None,measured_mask=None,activation_mode='equation4'):
    Z=np.asarray(Z,float); y=np.asarray(y,float).reshape(-1); p=len(rules)*(Z.shape[1]+1)
    theta=np.zeros(p) if theta0 is None else np.asarray(theta0,float).copy(); P=1e5*np.eye(p) if P0 is None else np.asarray(P0,float).copy()
    if measured_mask is None: measured_mask=np.isfinite(y)
    preds=[];errs=[];weights=[]
    for k,z in enumerate(Z):
        phi,w=regression_row(z,rules,activation_mode); yh=float(phi@theta); preds.append(yh);weights.append(w)
        if measured_mask[k] and np.isfinite(y[k]): theta,P,e,_=rls_step(theta,P,phi,y[k],lam);errs.append(e)
        else: errs.append(np.nan)
    return {'theta':theta,'P':P,'prediction':np.asarray(preds),'error':np.asarray(errs),'weights':np.asarray(weights)}
