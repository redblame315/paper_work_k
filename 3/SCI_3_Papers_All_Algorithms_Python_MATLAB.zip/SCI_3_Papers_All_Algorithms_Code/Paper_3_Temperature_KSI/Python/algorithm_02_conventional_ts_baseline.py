"""Paper 3, Algorithm 2: conventional T-S product-reasoning baseline."""
from __future__ import annotations
import numpy as np

def conventional_ts_predict(x,membership_rules,theta):
    x=np.asarray(x,float); raw=[]
    for rule in membership_rules: raw.append(np.prod([mu(v) for v,mu in zip(x,rule)]))
    raw=np.asarray(raw,float); w=raw/(raw.sum()+1e-12) if raw.sum()>1e-12 else np.full(len(raw),1/len(raw)); base=np.r_[1.0,x];phi=np.concatenate([wi*base for wi in w]);return float(phi@np.asarray(theta,float)),w,phi

def rls_update(theta,P,phi,y,lam=1.0):
    den=lam+float(phi@P@phi);K=(P@phi)/den;e=float(y-phi@theta);theta=theta+K*e;P=(P-np.outer(K,phi)@P)/lam;return theta,P,e
