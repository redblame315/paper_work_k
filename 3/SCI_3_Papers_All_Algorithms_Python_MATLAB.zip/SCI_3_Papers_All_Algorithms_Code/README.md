# Supplementary Algorithm Code for Three SCI Manuscripts

This package contains one Python file and one MATLAB file for every numbered algorithm in the three upgraded manuscripts.

## Papers and algorithm counts

1. **T-SFSSO prediction paper** — Algorithms 1–13 (26 language-specific algorithm files).
2. **KSI moving-cloud / inverted-pendulum paper** — Algorithms 1–4 (8 language-specific algorithm files).
3. **KSI aluminium-electrolysis temperature-prediction paper** — Algorithms 1–4 (8 language-specific algorithm files).

Total: **21 numbered algorithms, 42 Python/MATLAB algorithm files**, plus shared helper modules, demos, and a fidelity manifest.

## Scientific fidelity notes

The code is written against the algorithms and equations actually present in the upgraded manuscripts, not against unstated assumptions.

* Paper 1 Algorithms 1–4 are direct executable implementations of the manuscript algorithms; Algorithm 3 is copied from the paper's Python/MATLAB reference appendix. Algorithms 5–13 are executable transcriptions of the publication-level pseudocode added to the paper. Where that pseudocode deliberately leaves a source-paper-specific operator unspecified (e.g. the precise chaotic map, GA crossover, FACS construction details, ISOA improvement operator, or MATLAB XGBoost bridge), the code exposes that choice as a parameter/callback and documents the default. It does **not** claim line-for-line identity with the cited authors' external source code.
* Paper 2 follows Algorithms 1–4 and includes the manuscript's explicit reproducibility caveat: Eq. (29) defines the random operator `J(.)` symbolically. A Gaussian realization is supplied as the same transparent reference realization used in the manuscript supplement; replace only `normal_random_operator` / `normalRandomOperator` if the authors use another generator.
* Paper 3 contains a textual inconsistency between numbered Eq. (4), which defines the rule quantity as `1 - min(d_ij)`, and the later upgraded pseudocode, which says "product" activation. The code therefore supports **both** modes. The default is `activation_mode='equation4'` so the numbered equation is reproduced exactly; `activation_mode='pseudocode_product'` reproduces the later pseudocode wording. This is explicitly surfaced rather than silently reconciled.

## Python requirements

Core code uses Python 3.10+ and NumPy. Paper 2's LQR reference controller additionally uses SciPy. Paper 1 Algorithm 12 uses `xgboost` when an actual XGBoost model is requested.

## MATLAB requirements

Core MATLAB files target MATLAB R2016b+ syntax. The Paper 2 LQR controller uses `lqr`, requiring Control System Toolbox. Paper 1 Algorithm 12 accepts caller-supplied XGBoost train/predict function handles because MATLAB has no built-in XGBoost equivalent.

See `MANIFEST.csv` for one-to-one mapping between manuscript algorithm numbers and files.
