function model=algorithm_02_moving_rate_fnn_learning(X,y,centers,lefts,rights,consequents,eta,epochs)
T=consequents; trace=zeros(epochs,2); for ep=1:epochs, for k=1:size(X,1), o=algorithm_01_moving_rate_inference(X(k,:),centers,lefts,rights,T); e=y(k)-o.yhat; phi=[1 X(k,:)]; T=T+eta*e*(o.weights*phi); end; pred=zeros(size(y)); for k=1:numel(y), o=algorithm_01_moving_rate_inference(X(k,:),centers,lefts,rights,T); pred(k)=o.yhat; end; trace(ep,:)=[ep mean((y(:)-pred(:)).^2)]; end; model.centers=centers; model.lefts=lefts; model.rights=rights; model.consequents=T; model.trace=trace;
end
