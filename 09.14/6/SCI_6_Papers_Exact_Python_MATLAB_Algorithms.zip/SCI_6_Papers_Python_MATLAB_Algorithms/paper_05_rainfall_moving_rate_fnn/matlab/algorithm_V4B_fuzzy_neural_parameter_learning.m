function out=algorithm_V4B_fuzzy_neural_parameter_learning(varargin)
out=algorithm_02_moving_rate_fnn_learning(varargin{:});
end
