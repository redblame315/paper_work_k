function out=algorithm_01_moving_rate_inference(x,centers,lefts,rights,consequents)
x=x(:)'; nr=size(centers,1); d=zeros(nr,1); local=zeros(nr,1);
for i=1:nr, comp=zeros(1,numel(x)); for j=1:numel(x), if x(j)>=centers(i,j), m=(x(j)-centers(i,j))/max(rights(i,j)-centers(i,j),eps); else, m=(centers(i,j)-x(j))/max(centers(i,j)-lefts(i,j),eps); end; comp(j)=max(0,1-m); end; d(i)=prod(comp); local(i)=consequents(i,1)+consequents(i,2:end)*x'; end
if sum(d)<eps, [~,k]=min(vecnorm(centers-x,2,2)); w=zeros(nr,1); w(k)=1; else, w=d/sum(d); end; out.yhat=w'*local; out.weights=w;
end
