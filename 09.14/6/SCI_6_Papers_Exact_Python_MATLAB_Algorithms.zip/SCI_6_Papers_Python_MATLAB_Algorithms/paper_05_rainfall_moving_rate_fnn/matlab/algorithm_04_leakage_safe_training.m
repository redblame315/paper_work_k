function out=algorithm_04_leakage_safe_training(X,y,trainIdx,valIdx,testIdx,modelBuilder)
mu=mean(X(trainIdx,:),1); sd=max(std(X(trainIdx,:),0,1),eps); Xn=(X-mu)./sd; model=modelBuilder(Xn(trainIdx,:),y(trainIdx),Xn(valIdx,:),y(valIdx)); pred=zeros(numel(testIdx),1); for i=1:numel(testIdx), pred(i)=model.predict(Xn(testIdx(i),:)); end; out.predictions=pred; out.mean=mu; out.std=sd;
end
