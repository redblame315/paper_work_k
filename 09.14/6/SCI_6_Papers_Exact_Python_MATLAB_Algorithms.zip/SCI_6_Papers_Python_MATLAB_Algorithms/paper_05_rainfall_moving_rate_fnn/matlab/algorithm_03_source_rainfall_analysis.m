function out=algorithm_03_source_rainfall_analysis()
y=[283 647 731 561 467 399 315 521 472 536 385 259 657 348 644 431 179 615 433 401 206 639 418 570 415 796]';
p=[291.31 616.85 729.76 565.47 451.93 410.60 306.19 545.71 456.89 574.64 380.06 260.43 653.98 351.02 612.39 421.49 180.92 601.79 441.16 447.03 204.36 641.14 419.74 568.97 401.82 766.80]';
w=[363.80 637.69 730.35 556.26 435.77 398.22 315.57 540.36 419.00 662.29 386.23 266.00 659.34 358.06 647.19 393.21 183.13 615.56 434.16 414.5 209.92 660.43 419.19 584.51 391.09 699.53]';
out.proposed=localMetrics(y,p); out.wang=localMetrics(y,w); out.proposed_better_years=sum(abs(y-p)<abs(y-w)); out.wang_better_years=sum(abs(y-w)<abs(y-p)); out.training_time_ms=[24333 12219]; out.reported_accuracy_percent=[95.38 97.32];
end
function m=localMetrics(y,p), e=y-p; m.MAE=mean(abs(e)); m.RMSE=sqrt(mean(e.^2)); m.MAPE_percent=mean(abs(e)./max(abs(y),eps))*100; m.R2=1-sum(e.^2)/sum((y-mean(y)).^2); m.Pearson_r=corr(y,p); end
