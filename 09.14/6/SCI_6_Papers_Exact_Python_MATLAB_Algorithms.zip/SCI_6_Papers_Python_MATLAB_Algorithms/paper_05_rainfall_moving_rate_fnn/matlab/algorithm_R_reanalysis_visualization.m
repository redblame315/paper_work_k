function out=algorithm_R_reanalysis_visualization()
out=algorithm_03_source_rainfall_analysis(); out.descriptive_only=true;
end
