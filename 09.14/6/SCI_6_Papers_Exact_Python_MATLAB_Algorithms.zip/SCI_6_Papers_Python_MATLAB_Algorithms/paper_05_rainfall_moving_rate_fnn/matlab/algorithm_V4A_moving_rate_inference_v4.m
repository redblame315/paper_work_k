function out=algorithm_V4A_moving_rate_inference_v4(varargin)
out=algorithm_01_moving_rate_inference(varargin{:});
end
