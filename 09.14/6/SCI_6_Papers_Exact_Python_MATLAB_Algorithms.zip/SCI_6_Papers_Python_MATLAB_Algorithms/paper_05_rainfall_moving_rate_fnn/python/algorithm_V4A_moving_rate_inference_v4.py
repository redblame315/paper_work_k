"""Moving-Rate Fuzzy-Neural Rainfall Prediction
V4A: Moving-rate fuzzy inference
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import moving_rate_inference_v4

__all__ = ["moving_rate_inference_v4"]
