"""Moving-Rate Fuzzy-Neural Rainfall Prediction
03: Reproducible source-data evaluation and integrity check
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import source_rainfall_analysis

__all__ = ["source_rainfall_analysis"]
