"""Moving-Rate Fuzzy-Neural Rainfall Prediction
01: Moving-rate Takagi-Sugeno fuzzy inference
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import moving_rate_inference

__all__ = ["moving_rate_inference"]
