"""Moving-Rate Fuzzy-Neural Rainfall Prediction
04: Moving-rate fuzzy-neural training and leakage-safe evaluation
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import leakage_safe_training

__all__ = ["leakage_safe_training"]
