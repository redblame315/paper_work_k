"""Moving-Rate Fuzzy-Neural Rainfall Prediction
02: Moving-rate fuzzy-neural parameter learning
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import moving_rate_fnn_learning

__all__ = ["moving_rate_fnn_learning"]
