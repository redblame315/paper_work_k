
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence
import numpy as np

EPS = 1e-12

def clip(x, lo, hi):
    return np.minimum(np.maximum(x, lo), hi)

def as1d(x):
    return np.asarray(x, dtype=float).reshape(-1)

def finite_or_penalty(v, penalty=1e12):
    v=float(v)
    return v if math.isfinite(v) else float(penalty)

def metrics(y, yhat):
    y=as1d(y); yhat=as1d(yhat)
    if len(y)!=len(yhat): raise ValueError('length mismatch')
    e=y-yhat
    mae=float(np.mean(np.abs(e)))
    rmse=float(np.sqrt(np.mean(e*e)))
    denom=np.maximum(np.abs(y), EPS)
    mape=float(np.mean(np.abs(e)/denom)*100.0)
    ss_res=float(np.sum(e*e)); ss_tot=float(np.sum((y-np.mean(y))**2))
    r2=float(1-ss_res/ss_tot) if ss_tot>EPS else float('nan')
    corr=float(np.corrcoef(y,yhat)[0,1]) if len(y)>1 else float('nan')
    return {'n':len(y),'MAE':mae,'RMSE':rmse,'MAPE_percent':mape,'R2':r2,'Pearson_r':corr}

def source_hash(obj: Any) -> str:
    b=json.dumps(obj,sort_keys=True,default=lambda z: np.asarray(z).tolist()).encode('utf-8')
    return hashlib.sha256(b).hexdigest()

def pareto_mask(Y):
    Y=np.asarray(Y,float)
    n=len(Y); keep=np.ones(n,dtype=bool)
    for i in range(n):
        if not keep[i]: continue
        dominated=np.all(Y<=Y[i],axis=1)&np.any(Y<Y[i],axis=1)
        if np.any(dominated): keep[i]=False
    return keep

def normalized_weighted_score(Y, weights=None):
    Y=np.asarray(Y,float)
    lo=np.nanmin(Y,axis=0); hi=np.nanmax(Y,axis=0)
    Yn=(Y-lo)/np.maximum(hi-lo,EPS)
    w=np.ones(Y.shape[1])/Y.shape[1] if weights is None else as1d(weights)/np.sum(weights)
    return Yn@w

YEARS=np.arange(1952,1978)
TARGET=np.array([283,647,731,561,467,399,315,521,472,536,385,259,657,348,644,431,179,615,433,401,206,639,418,570,415,796],float)
PROPOSED=np.array([291.31,616.85,729.76,565.47,451.93,410.60,306.19,545.71,456.89,574.64,380.06,260.43,653.98,351.02,612.39,421.49,180.92,601.79,441.16,447.03,204.36,641.14,419.74,568.97,401.82,766.80],float)
WANG=np.array([363.80,637.69,730.35,556.26,435.77,398.22,315.57,540.36,419.00,662.29,386.23,266.00,659.34,358.06,647.19,393.21,183.13,615.56,434.16,414.5,209.92,660.43,419.19,584.51,391.09,699.53],float)

def symmetric_support_moving_rate(x,center,left,right):
    # Isolated author-verification point. Uses source-described center and left/right support endpoints.
    if not left<=center<=right: raise ValueError('support requires left<=center<=right')
    if x>=center: return (x-center)/max(right-center,EPS)
    return (center-x)/max(center-left,EPS)

def moving_rate_inference(x,centers,lefts,rights,consequents,moving_rate_fn=symmetric_support_moving_rate):
    x=as1d(x); C=np.asarray(centers,float); L=np.asarray(lefts,float); R=np.asarray(rights,float); T=np.asarray(consequents,float)
    nr,nd=C.shape
    if L.shape!=C.shape or R.shape!=C.shape or T.shape!=(nr,nd+1): raise ValueError('shape mismatch')
    d=np.zeros(nr); local=np.zeros(nr)
    for i in range(nr):
        compat=[]
        for j in range(nd):
            m=float(moving_rate_fn(float(x[j]),float(C[i,j]),float(L[i,j]),float(R[i,j])))
            compat.append(max(0.0,1.0-m))
        # V4/source product term; partial participation remains possible because zero is not forced by membership intersection.
        d[i]=float(np.prod(compat)); local[i]=float(T[i,0]+T[i,1:]@x)
    s=float(d.sum())
    if s<EPS:
        i=int(np.argmin(np.linalg.norm(C-x,axis=1))); return local[i],np.eye(1,nr,i).reshape(-1)
    w=d/s; return float(w@local),w

def moving_rate_fnn_learning(X,y,centers,lefts,rights,consequents,eta=1e-4,epochs=100,patience=10,Xv=None,yv=None):
    # Consequents are updated analytically by gradient; antecedent support is kept valid and can be externally updated if exact derivatives are supplied.
    X=np.asarray(X,float); y=as1d(y); C=np.asarray(centers,float).copy(); L=np.asarray(lefts,float).copy(); R=np.asarray(rights,float).copy(); T=np.asarray(consequents,float).copy()
    best=(np.inf,T.copy()); wait=0; trace=[]
    for ep in range(epochs):
        for x,yt in zip(X,y):
            pred,w=moving_rate_inference(x,C,L,R,T); e=yt-pred; phi=np.r_[1.0,x]
            T += eta*e*w[:,None]*phi[None,:]
        if Xv is None: val=float(np.mean([(yt-moving_rate_inference(x,C,L,R,T)[0])**2 for x,yt in zip(X,y)]))
        else: val=float(np.mean([(yt-moving_rate_inference(x,C,L,R,T)[0])**2 for x,yt in zip(np.asarray(Xv,float),as1d(yv))]))
        trace.append({'epoch':ep+1,'validation_mse':val})
        if val<best[0]-1e-12: best=(val,T.copy()); wait=0
        else: wait+=1
        if wait>=patience: break
    T=best[1]; return {'centers':C,'lefts':L,'rights':R,'consequents':T,'trace':trace}

def source_rainfall_analysis(target=TARGET,proposed=PROPOSED,wang=WANG):
    from scipy import stats
    t=as1d(target); p=as1d(proposed); w=as1d(wang); ap=np.abs(t-p); aw=np.abs(t-w)
    try: wil=stats.wilcoxon(aw,ap,alternative='greater',method='auto')
    except Exception: wil=stats.wilcoxon(aw,ap,alternative='greater')
    return {'proposed':metrics(t,p),'wang':metrics(t,w),'proposed_better_years':int(np.sum(ap<aw)),'wang_better_years':int(np.sum(aw<ap)),'ties':int(np.sum(ap==aw)),'paired_wilcoxon_p':float(wil.pvalue),'source_training_time_ms':{'Wang':24333,'Proposed':12219},'source_reported_accuracy_percent':{'Wang':95.38,'Proposed':97.32}}

def leakage_safe_training(X,y,train_idx,val_idx,test_idx,model_builder):
    X=np.asarray(X,float); y=as1d(y); tr=np.asarray(train_idx,int); va=np.asarray(val_idx,int); te=np.asarray(test_idx,int)
    mu=X[tr].mean(axis=0); sd=np.maximum(X[tr].std(axis=0),EPS); Xn=(X-mu)/sd
    model=model_builder(Xn[tr],y[tr],Xn[va],y[va]); predict=model['predict'] if isinstance(model,dict) else model.predict
    pred=np.asarray([predict(x) for x in Xn[te]],float)
    return {'predictions':pred,'metrics':metrics(y[te],pred),'normalization':{'mean':mu,'std':sd},'test_indices':te}

def moving_rate_inference_v4(*args,**kwargs): return moving_rate_inference(*args,**kwargs)

def fuzzy_neural_parameter_learning(*args,**kwargs): return moving_rate_fnn_learning(*args,**kwargs)

def leakage_safe_evaluation(target=TARGET,proposed=PROPOSED,wang=WANG): return source_rainfall_analysis(target,proposed,wang)

def reanalysis_visualization(D0=None,target=TARGET,predictions=None):
    if predictions is None: predictions={'Proposed':PROPOSED,'Wang':WANG}
    return {'source_hash':source_hash(D0 if D0 is not None else {'year':YEARS.tolist(),'target':TARGET.tolist(),'proposed':PROPOSED.tolist(),'wang':WANG.tolist()}),'metrics':{k:metrics(target,v) for k,v in predictions.items()},'descriptive_only':True}
