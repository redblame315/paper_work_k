"""Moving-Rate Fuzzy-Neural Rainfall Prediction
V4B: Fuzzy-neural parameter learning
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import fuzzy_neural_parameter_learning

__all__ = ["fuzzy_neural_parameter_learning"]
