"""Moving-Rate Fuzzy-Neural Rainfall Prediction
V4C: Leakage-safe rainfall evaluation
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import leakage_safe_evaluation

__all__ = ["leakage_safe_evaluation"]
