# Executable Python + MATLAB Algorithm Package for the Six SCI Manuscripts

This package maps **every pseudocode block in the latest V4 manuscripts** to a dedicated Python (`.py`) and MATLAB (`.m`) file.

## Exactness policy

The code follows the algorithmic control flow and equations explicitly stated in the V4 manuscripts and the underlying source material available in this conversation. **No missing scientific equation, controller rule table, physical plant model, or unpublished parameter value has been invented and presented as source truth.** Where a manuscript specifies a procedure but not a unique numeric formula/parameter, the implementation exposes that item as a required function/configuration argument. A runnable `demo` uses clearly labeled demonstration values only.

This distinction matters for publication reproducibility: an executable program cannot be mathematically “exact” beyond what the manuscript actually specifies. Each paper folder includes `SOURCE_LIMITATIONS.md` identifying such inputs.

## Folder layout

Each paper contains:
- `python/`: one Python file per manuscript pseudocode algorithm, plus a core implementation and smoke test.
- `matlab/`: one MATLAB file per manuscript pseudocode algorithm, plus a smoke-test driver.
- `ALGORITHM_MAP.csv`: manuscript algorithm label -> Python/MATLAB file.
- `SOURCE_LIMITATIONS.md`: source-defined items vs required author-supplied items.

## Python

Python 3.10+ is recommended. Core algorithms use NumPy. Statistical/plotting examples may use SciPy and Matplotlib.

```bash
python -m pip install -r paper_05_rainfall_moving_rate_fnn/python/requirements.txt
python paper_05_rainfall_moving_rate_fnn/python/run_smoke_tests.py
```

## MATLAB

Add the selected paper's `matlab` folder to the MATLAB path, then run:

```matlab
run_smoke_tests
```

## Manuscript version

Generated from the latest V4 manuscript set under `/mnt/data/upgraded_sci_v4`, dated September 2026 in the documents.
