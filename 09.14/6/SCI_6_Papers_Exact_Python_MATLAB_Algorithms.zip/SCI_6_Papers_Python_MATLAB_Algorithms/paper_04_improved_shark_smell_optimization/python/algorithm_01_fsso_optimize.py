"""Improved Shark-Smell Optimization for Inverted-Pendulum Control
01: Improved shark-smell optimization (FSSO-style update)
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import fsso_optimize

__all__ = ["fsso_optimize"]
