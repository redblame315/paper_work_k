
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence
import numpy as np

EPS = 1e-12

def clip(x, lo, hi):
    return np.minimum(np.maximum(x, lo), hi)

def as1d(x):
    return np.asarray(x, dtype=float).reshape(-1)

def finite_or_penalty(v, penalty=1e12):
    v=float(v)
    return v if math.isfinite(v) else float(penalty)

def metrics(y, yhat):
    y=as1d(y); yhat=as1d(yhat)
    if len(y)!=len(yhat): raise ValueError('length mismatch')
    e=y-yhat
    mae=float(np.mean(np.abs(e)))
    rmse=float(np.sqrt(np.mean(e*e)))
    denom=np.maximum(np.abs(y), EPS)
    mape=float(np.mean(np.abs(e)/denom)*100.0)
    ss_res=float(np.sum(e*e)); ss_tot=float(np.sum((y-np.mean(y))**2))
    r2=float(1-ss_res/ss_tot) if ss_tot>EPS else float('nan')
    corr=float(np.corrcoef(y,yhat)[0,1]) if len(y)>1 else float('nan')
    return {'n':len(y),'MAE':mae,'RMSE':rmse,'MAPE_percent':mape,'R2':r2,'Pearson_r':corr}

def source_hash(obj: Any) -> str:
    b=json.dumps(obj,sort_keys=True,default=lambda z: np.asarray(z).tolist()).encode('utf-8')
    return hashlib.sha256(b).hexdigest()

def pareto_mask(Y):
    Y=np.asarray(Y,float)
    n=len(Y); keep=np.ones(n,dtype=bool)
    for i in range(n):
        if not keep[i]: continue
        dominated=np.all(Y<=Y[i],axis=1)&np.any(Y<Y[i],axis=1)
        if np.any(dominated): keep[i]=False
    return keep

def normalized_weighted_score(Y, weights=None):
    Y=np.asarray(Y,float)
    lo=np.nanmin(Y,axis=0); hi=np.nanmax(Y,axis=0)
    Yn=(Y-lo)/np.maximum(hi-lo,EPS)
    w=np.ones(Y.shape[1])/Y.shape[1] if weights is None else as1d(weights)/np.sum(weights)
    return Yn@w

SOURCE_SSO_6=np.array([[13.149,7.550,0.443,3.690],[13.113,7.501,0.421,5.080],[13.208,7.540,0.413,4.850],[13.128,7.527,0.425,3.700],[13.231,7.560,0.416,4.810],[13.114,7.504,0.419,5.020]])
SOURCE_FSSO_6=np.array([[10.433,5.611,0.284,3.960],[11.790,5.731,0.169,3.410],[10.887,5.999,0.415,4.870],[10.518,5.667,0.341,3.990],[10.372,5.718,0.261,3.490],[10.353,5.438,0.433,3.710]])

def finite_difference_gradient(objective,x,bounds,h=1e-5):
    x=as1d(x); b=np.asarray(bounds,float); g=np.zeros_like(x)
    for j in range(len(x)):
        step=h*max(1.0,b[j,1]-b[j,0]); xp=x.copy(); xm=x.copy(); xp[j]=min(b[j,1],x[j]+step); xm[j]=max(b[j,0],x[j]-step)
        g[j]=(objective(xp)-objective(xm))/max(xp[j]-xm[j],EPS)
    return g

def fsso_population_init(bounds,population,objective,seed=0,penalty=1e12):
    rng=np.random.default_rng(seed); b=np.asarray(bounds,float); X=rng.uniform(b[:,0],b[:,1],size=(population,len(b)))
    J=np.array([finite_or_penalty(objective(x),penalty) for x in X]); idx=int(np.argmin(J))
    return X,J,X[idx].copy(),float(J[idx])

def adaptive_forward_rotational_search(X,J,objective,bounds,velocities=None,iteration=0,max_iterations=100,
                                       grad_coeff=None,inertia_coeff=None,speed_limit=None,local_points=5,seed=0):
    rng=np.random.default_rng(seed+iteration); X=np.asarray(X,float).copy(); J=np.asarray(J,float).copy(); b=np.asarray(bounds,float)
    V=np.zeros_like(X) if velocities is None else np.asarray(velocities,float).copy()
    progress=iteration/max(max_iterations-1,1)
    gc=(1-progress) if grad_coeff is None else float(grad_coeff(iteration,max_iterations))
    ic=progress if inertia_coeff is None else float(inertia_coeff(iteration,max_iterations))
    sl=(1-progress) if speed_limit is None else float(speed_limit(iteration,max_iterations))
    span=b[:,1]-b[:,0]
    for i,x in enumerate(X):
        g=finite_difference_gradient(objective,x,b)
        ng=np.linalg.norm(g); direction=(-g/ng) if ng>EPS else rng.normal(size=len(x))
        V[i]=ic*V[i]+gc*direction*span*0.1
        vmax=np.maximum(span*max(sl,0.01)*0.25,EPS); V[i]=np.clip(V[i],-vmax,vmax)
        xf=np.clip(x+V[i],b[:,0],b[:,1]); candidates=[xf]
        radius=span*max(sl,0.01)*0.05
        for _ in range(local_points): candidates.append(np.clip(xf+rng.uniform(-1,1,size=len(x))*radius,b[:,0],b[:,1]))
        vals=[finite_or_penalty(objective(c)) for c in candidates]; k=int(np.argmin(vals))
        if vals[k]<J[i]: X[i]=candidates[k]; J[i]=vals[k]
    return X,J,V

def fsso_optimize(objective,bounds,population=20,max_evaluations=500,local_points=5,seed=0,stagnation=30):
    X,J,best,bestJ=fsso_population_init(bounds,population,objective,seed); V=np.zeros_like(X); evals=population; trace=[]; noimp=0; it=0
    while evals<max_evaluations and noimp<stagnation:
        it+=1; prev=bestJ
        X,J,V=adaptive_forward_rotational_search(X,J,objective,bounds,V,it,max(2,max_evaluations//population),local_points=local_points,seed=seed)
        evals+=population*(1+local_points)*2 # includes finite-difference objective calls approximately; budget is conservative
        idx=int(np.argmin(J))
        if J[idx]<bestJ: bestJ=float(J[idx]); best=X[idx].copy()
        noimp=0 if bestJ<prev-1e-12 else noimp+1
        # diversity escape for non-elite points
        div=float(np.mean(np.std(X,axis=0)))
        if div<1e-6:
            rng=np.random.default_rng(seed+it+999); b=np.asarray(bounds,float); ids=np.argsort(J)[len(J)//2:]
            X[ids]=rng.uniform(b[:,0],b[:,1],size=(len(ids),b.shape[0])); J[ids]=[objective(x) for x in X[ids]]
        trace.append({'iteration':it,'best_objective':bestJ,'diversity':div,'evaluations_approx':evals})
    return {'x_best':best,'best_objective':bestJ,'trace':trace,'population':X,'objectives':J}

def tune_fuzzy_controller(simulate,bounds,scenarios,weights=(1,1,1,1),**optkw):
    w=as1d(weights)
    def objective(theta):
        vals=[]
        for s in scenarios:
            r=simulate(theta,s)
            if r.get('diverged',False): return 1e12
            vals.append(np.array([r['TE'],r['AE'],r['DE'],r['ST']],float))
        return float(np.mean(np.vstack(vals)@w))
    out=fsso_optimize(objective,bounds,**optkw); out['robustness']=robust_controller_evaluation(out['x_best'],simulate,scenarios); return out

def source_paired_analysis(sso=SOURCE_SSO_6,fsso=SOURCE_FSSO_6):
    from scipy import stats
    A=np.asarray(sso,float); B=np.asarray(fsso,float); names=['TE','AE','DE','ST']; out={}
    for j,n in enumerate(names):
        try: res=stats.wilcoxon(A[:,j],B[:,j],alternative='greater',method='exact')
        except Exception: res=stats.wilcoxon(A[:,j],B[:,j],alternative='greater')
        out[n]={'SSO_mean':float(A[:,j].mean()),'FSSO_mean':float(B[:,j].mean()),'relative_reduction_percent':float(100*(A[:,j].mean()-B[:,j].mean())/A[:,j].mean()),'one_sided_wilcoxon_p':float(res.pvalue)}
    out['warning']='n=6 paired source trials; interpret as limited post-hoc evidence'
    return out

def robust_controller_evaluation(theta,simulate,scenarios):
    rows=[]
    for s in scenarios:
        r=simulate(theta,s); rows.append({**r,'scenario':s})
    valid=[r for r in rows if not r.get('diverged',False)]
    summary={}
    for key in ['TE','AE','DE','ST']:
        vals=[float(r[key]) for r in valid if key in r]
        if vals: summary[key]={'mean':float(np.mean(vals)),'sd':float(np.std(vals,ddof=1)) if len(vals)>1 else 0.0,'worst':float(np.max(vals))}
    return {'runs':rows,'summary':summary,'failure_count':len(rows)-len(valid)}

def robust_fsso_controller_optimization(simulate,bounds,initial_conditions,seeds=(0,1,2),weights=(1,1,1,1),**kw):
    runs=[]
    for seed in seeds:
        out=tune_fuzzy_controller(simulate,bounds,initial_conditions,weights=weights,seed=int(seed),**kw); runs.append(out)
    scores=np.array([r['best_objective'] for r in runs]); k=int(np.argmin(np.abs(scores-np.median(scores))))
    return {'theta_star':runs[k]['x_best'],'seed_runs':runs,'selection':'median-best objective run'}

def reanalysis_visualization(D0=None,target=None,predictions=None):
    out={'source_hash':source_hash(D0 if D0 is not None else {'SSO':SOURCE_SSO_6.tolist(),'FSSO':SOURCE_FSSO_6.tolist()}),'descriptive_only':True}
    if target is not None and predictions: out['metrics']={k:metrics(target,v) for k,v in predictions.items()}
    return out
