"""Improved Shark-Smell Optimization for Inverted-Pendulum Control
V4C: Robust controller-tuning evaluation
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import robust_controller_evaluation

__all__ = ["robust_controller_evaluation"]
