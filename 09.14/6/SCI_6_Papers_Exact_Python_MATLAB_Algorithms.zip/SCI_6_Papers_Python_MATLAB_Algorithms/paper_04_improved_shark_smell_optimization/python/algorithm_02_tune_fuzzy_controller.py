"""Improved Shark-Smell Optimization for Inverted-Pendulum Control
02: Fuzzy-controller tuning with the optimizer
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import tune_fuzzy_controller

__all__ = ["tune_fuzzy_controller"]
