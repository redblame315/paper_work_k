"""Improved Shark-Smell Optimization for Inverted-Pendulum Control
05: FSSO-based robust controller-parameter optimization
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import robust_fsso_controller_optimization

__all__ = ["robust_fsso_controller_optimization"]
