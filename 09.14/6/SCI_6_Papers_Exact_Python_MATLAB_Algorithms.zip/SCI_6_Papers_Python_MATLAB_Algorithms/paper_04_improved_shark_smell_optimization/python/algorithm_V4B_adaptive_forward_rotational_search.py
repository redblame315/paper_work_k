"""Improved Shark-Smell Optimization for Inverted-Pendulum Control
V4B: Adaptive forward and rotational search
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import adaptive_forward_rotational_search

__all__ = ["adaptive_forward_rotational_search"]
