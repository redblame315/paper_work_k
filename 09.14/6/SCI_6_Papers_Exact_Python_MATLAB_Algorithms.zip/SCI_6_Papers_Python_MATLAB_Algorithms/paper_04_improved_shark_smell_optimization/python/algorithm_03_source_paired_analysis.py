"""Improved Shark-Smell Optimization for Inverted-Pendulum Control
03: Reproducible source-data evaluation and integrity check
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import source_paired_analysis

__all__ = ["source_paired_analysis"]
