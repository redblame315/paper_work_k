"""Improved Shark-Smell Optimization for Inverted-Pendulum Control
V4A: FSSO population initialization and constraint handling
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import fsso_population_init

__all__ = ["fsso_population_init"]
