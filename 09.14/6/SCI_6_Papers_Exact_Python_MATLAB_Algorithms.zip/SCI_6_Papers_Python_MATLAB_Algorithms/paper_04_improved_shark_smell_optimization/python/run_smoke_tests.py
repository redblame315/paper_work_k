from pathlib import Path
import importlib.util, sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import paper_core as c

for f in sorted(HERE.glob("algorithm_*.py")):
    spec=importlib.util.spec_from_file_location(f.stem,f); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
print("Imported", len(list(HERE.glob("algorithm_*.py"))), "algorithm files successfully")
print(c.source_paired_analysis())
