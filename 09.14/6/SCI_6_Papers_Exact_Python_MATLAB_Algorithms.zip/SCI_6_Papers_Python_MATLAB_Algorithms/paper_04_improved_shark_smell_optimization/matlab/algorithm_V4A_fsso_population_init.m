function out=algorithm_V4A_fsso_population_init(bounds,N,objective,seed)
rng(seed); lo=bounds(:,1)'; hi=bounds(:,2)'; X=lo+rand(N,size(bounds,1)).*(hi-lo); J=zeros(N,1); for i=1:N, J(i)=objective(X(i,:)); if ~isfinite(J(i)), J(i)=1e12; end, end; [bestJ,k]=min(J); out.X=X; out.J=J; out.best=X(k,:); out.bestJ=bestJ;
end
