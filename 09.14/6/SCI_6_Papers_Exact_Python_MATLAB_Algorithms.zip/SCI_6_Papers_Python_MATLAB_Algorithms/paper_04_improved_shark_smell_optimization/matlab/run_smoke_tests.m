disp('MATLAB algorithm files present:');
d=dir('algorithm_*.m'); disp(numel(d));
disp(algorithm_03_source_paired_analysis());
