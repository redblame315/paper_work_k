function out=algorithm_V4B_adaptive_forward_rotational_search(X,J,objective,bounds,V,iteration,maxIterations,M)
lo=bounds(:,1)'; hi=bounds(:,2)'; span=hi-lo; p=iteration/max(maxIterations-1,1); gc=1-p; ic=p; sl=max(1-p,0.01);
for i=1:size(X,1), x=X(i,:); g=zeros(size(x)); for d=1:numel(x), h=1e-5*max(span(d),1); xp=x; xm=x; xp(d)=min(hi(d),x(d)+h); xm(d)=max(lo(d),x(d)-h); g(d)=(objective(xp)-objective(xm))/max(xp(d)-xm(d),eps); end; if norm(g)>eps, dir=-g/norm(g); else, dir=randn(size(g)); end; V(i,:)=ic*V(i,:)+gc*dir.*span*0.1; vmax=span*sl*0.25; V(i,:)=min(max(V(i,:),-vmax),vmax); xf=min(max(x+V(i,:),lo),hi); cand=xf; for q=1:M, cand=[cand;min(max(xf+(2*rand(size(x))-1).*span*sl*0.05,lo),hi)]; end; vals=zeros(size(cand,1),1); for q=1:size(cand,1), vals(q)=objective(cand(q,:)); end; [v,k]=min(vals); if v<J(i), X(i,:)=cand(k,:); J(i)=v; end; end
out.X=X; out.J=J; out.V=V;
end
