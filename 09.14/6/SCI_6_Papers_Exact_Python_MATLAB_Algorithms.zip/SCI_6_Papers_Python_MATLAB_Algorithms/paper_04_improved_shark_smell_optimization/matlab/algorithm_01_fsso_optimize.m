function out=algorithm_01_fsso_optimize(objective,bounds,N,maxIter,M,seed)
a=algorithm_V4A_fsso_population_init(bounds,N,objective,seed); X=a.X; J=a.J; V=zeros(size(X)); best=a.best; bestJ=a.bestJ; trace=zeros(maxIter,2);
for it=1:maxIter, b=algorithm_V4B_adaptive_forward_rotational_search(X,J,objective,bounds,V,it,maxIter,M); X=b.X; J=b.J; V=b.V; [v,k]=min(J); if v<bestJ, bestJ=v; best=X(k,:); end; trace(it,:)=[it bestJ]; end
out.x_best=best; out.best_objective=bestJ; out.trace=trace;
end
