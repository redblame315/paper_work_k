function out=algorithm_05_robust_fsso_controller_optimization(simulate,bounds,scenarios,weights,seeds,N,maxIter,M)
runs=cell(numel(seeds),1); scores=zeros(numel(seeds),1); for i=1:numel(seeds), runs{i}=algorithm_02_tune_fuzzy_controller(simulate,bounds,scenarios,weights,N,maxIter,M,seeds(i)); scores(i)=runs{i}.best_objective; end; med=median(scores); [~,k]=min(abs(scores-med)); out.theta_star=runs{k}.x_best; out.seed_runs=runs; out.selection='median-best objective run';
end
