function out=algorithm_02_tune_fuzzy_controller(simulate,bounds,scenarios,weights,N,maxIter,M,seed)
obj=@(theta)localObj(theta,simulate,scenarios,weights); out=algorithm_01_fsso_optimize(obj,bounds,N,maxIter,M,seed); out.robustness=algorithm_V4C_robust_controller_evaluation(out.x_best,simulate,scenarios);
end
function J=localObj(theta,simulate,scenarios,w)
vals=[]; for i=1:numel(scenarios), r=simulate(theta,scenarios{i}); if isfield(r,'diverged') && r.diverged, J=1e12; return; end; vals=[vals; r.TE r.AE r.DE r.ST]; end; J=mean(vals*w(:));
end
