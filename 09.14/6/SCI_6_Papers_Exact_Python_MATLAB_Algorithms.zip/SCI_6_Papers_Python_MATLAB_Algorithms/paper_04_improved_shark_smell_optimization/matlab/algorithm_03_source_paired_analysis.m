function out=algorithm_03_source_paired_analysis()
A=[13.149 7.550 .443 3.690;13.113 7.501 .421 5.080;13.208 7.540 .413 4.850;13.128 7.527 .425 3.700;13.231 7.560 .416 4.810;13.114 7.504 .419 5.020];
B=[10.433 5.611 .284 3.960;11.790 5.731 .169 3.410;10.887 5.999 .415 4.870;10.518 5.667 .341 3.990;10.372 5.718 .261 3.490;10.353 5.438 .433 3.710];
out.SSO_mean=mean(A); out.FSSO_mean=mean(B); out.relative_reduction_percent=100*(mean(A)-mean(B))./mean(A); out.warning='n=6 paired source trials; exact Wilcoxon p-values require Statistics Toolbox or external implementation';
end
