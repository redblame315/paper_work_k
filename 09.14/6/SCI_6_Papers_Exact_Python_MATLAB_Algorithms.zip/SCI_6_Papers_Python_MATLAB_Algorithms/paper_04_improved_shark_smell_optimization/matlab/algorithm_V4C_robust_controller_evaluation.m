function out=algorithm_V4C_robust_controller_evaluation(theta,simulate,scenarios)
runs=cell(numel(scenarios),1); fail=0; for i=1:numel(scenarios), r=simulate(theta,scenarios{i}); runs{i}=r; if isfield(r,'diverged') && r.diverged, fail=fail+1; end, end; out.runs=runs; out.failure_count=fail;
end
