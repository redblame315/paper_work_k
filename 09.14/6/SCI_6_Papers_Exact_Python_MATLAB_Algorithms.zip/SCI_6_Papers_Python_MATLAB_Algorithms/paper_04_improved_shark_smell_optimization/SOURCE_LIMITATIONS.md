# Source limitations / author-verification points

The source gives the SSO/FSSO search stages and states that velocity-limit, gradient-term and inertia coefficients are varied linearly, but several displayed equations are embedded as non-machine-readable equation objects in the source. The implementation exposes coefficient schedules and objective weights as arguments rather than guessing them. It preserves the source-reported paired SSO/FSSO trial values and robustness/failure handling.
