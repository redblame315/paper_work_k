# Source limitations / author-verification points

The manuscript specifies competitive/neighborhood learning, external-criterion GMDH selection, and benchmark schedules, but not every antecedent compatibility function and noise-removal estimator is uniquely machine-readable in the upgraded text. The implementation therefore accepts a compatibility function and robust weighting function. The supplied defaults are explicit reproducible realizations, not hidden source claims.
