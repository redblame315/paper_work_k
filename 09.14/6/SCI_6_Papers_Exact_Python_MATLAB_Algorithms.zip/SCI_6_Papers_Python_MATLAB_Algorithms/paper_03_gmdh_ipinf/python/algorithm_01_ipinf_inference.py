"""GMDH-IPINF Nonlinear System Modeling
01: IPINF inference for one sample
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import ipinf_inference

__all__ = ["ipinf_inference"]
