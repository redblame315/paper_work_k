"""GMDH-IPINF Nonlinear System Modeling
02: Local antecedent/consequent learning with shrinking neighborhood
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import local_learning

__all__ = ["local_learning"]
