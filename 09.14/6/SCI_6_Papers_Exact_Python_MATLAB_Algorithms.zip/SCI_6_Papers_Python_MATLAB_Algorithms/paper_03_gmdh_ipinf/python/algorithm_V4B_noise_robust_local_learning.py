"""GMDH-IPINF Nonlinear System Modeling
V4B: Noise-robust local parameter learning
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import noise_robust_local_learning

__all__ = ["noise_robust_local_learning"]
