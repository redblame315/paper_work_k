"""GMDH-IPINF Nonlinear System Modeling
V4C: GMDH-IPINF layer construction with external criterion
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import external_criterion_layering

__all__ = ["external_criterion_layering"]
