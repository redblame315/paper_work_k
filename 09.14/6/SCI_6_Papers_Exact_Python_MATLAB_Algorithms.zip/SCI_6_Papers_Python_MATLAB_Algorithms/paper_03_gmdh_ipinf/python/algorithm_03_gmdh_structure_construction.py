"""GMDH-IPINF Nonlinear System Modeling
03: GMDH-IPINF structure construction
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import gmdh_structure_construction

__all__ = ["gmdh_structure_construction"]
