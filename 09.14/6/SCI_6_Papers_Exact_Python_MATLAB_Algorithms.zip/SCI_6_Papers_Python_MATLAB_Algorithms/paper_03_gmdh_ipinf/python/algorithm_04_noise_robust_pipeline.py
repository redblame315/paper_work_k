"""GMDH-IPINF Nonlinear System Modeling
04: Noise-robust prediction pipeline
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import noise_robust_pipeline

__all__ = ["noise_robust_pipeline"]
