"""GMDH-IPINF Nonlinear System Modeling
05: Reproducible source-data evaluation and integrity check
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import source_benchmark_audit

__all__ = ["source_benchmark_audit"]
