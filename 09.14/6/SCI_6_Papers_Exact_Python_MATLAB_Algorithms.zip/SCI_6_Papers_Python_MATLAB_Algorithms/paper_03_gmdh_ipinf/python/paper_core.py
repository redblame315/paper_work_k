
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence
import numpy as np

EPS = 1e-12

def clip(x, lo, hi):
    return np.minimum(np.maximum(x, lo), hi)

def as1d(x):
    return np.asarray(x, dtype=float).reshape(-1)

def finite_or_penalty(v, penalty=1e12):
    v=float(v)
    return v if math.isfinite(v) else float(penalty)

def metrics(y, yhat):
    y=as1d(y); yhat=as1d(yhat)
    if len(y)!=len(yhat): raise ValueError('length mismatch')
    e=y-yhat
    mae=float(np.mean(np.abs(e)))
    rmse=float(np.sqrt(np.mean(e*e)))
    denom=np.maximum(np.abs(y), EPS)
    mape=float(np.mean(np.abs(e)/denom)*100.0)
    ss_res=float(np.sum(e*e)); ss_tot=float(np.sum((y-np.mean(y))**2))
    r2=float(1-ss_res/ss_tot) if ss_tot>EPS else float('nan')
    corr=float(np.corrcoef(y,yhat)[0,1]) if len(y)>1 else float('nan')
    return {'n':len(y),'MAE':mae,'RMSE':rmse,'MAPE_percent':mape,'R2':r2,'Pearson_r':corr}

def source_hash(obj: Any) -> str:
    b=json.dumps(obj,sort_keys=True,default=lambda z: np.asarray(z).tolist()).encode('utf-8')
    return hashlib.sha256(b).hexdigest()

def pareto_mask(Y):
    Y=np.asarray(Y,float)
    n=len(Y); keep=np.ones(n,dtype=bool)
    for i in range(n):
        if not keep[i]: continue
        dominated=np.all(Y<=Y[i],axis=1)&np.any(Y<Y[i],axis=1)
        if np.any(dominated): keep[i]=False
    return keep

def normalized_weighted_score(Y, weights=None):
    Y=np.asarray(Y,float)
    lo=np.nanmin(Y,axis=0); hi=np.nanmax(Y,axis=0)
    Yn=(Y-lo)/np.maximum(hi-lo,EPS)
    w=np.ones(Y.shape[1])/Y.shape[1] if weights is None else as1d(weights)/np.sum(weights)
    return Yn@w


def gaussian_compatibility(x,center,width):
    x=as1d(x); c=as1d(center); w=np.maximum(as1d(width),EPS)
    return np.exp(-0.5*((x-c)/w)**2)

def ipinf_inference(x,centers,widths,consequents,compatibility_fn=gaussian_compatibility):
    x=as1d(x); C=np.asarray(centers,float); W=np.asarray(widths,float); T=np.asarray(consequents,float)
    if C.shape!=W.shape: raise ValueError('centers/widths shape mismatch')
    if T.shape[0]!=C.shape[0] or T.shape[1]!=C.shape[1]+1: raise ValueError('consequents must be rules x (features+1)')
    acts=[]; locals=[]
    for c,w,t in zip(C,W,T):
        mu=as1d(compatibility_fn(x,c,w)); a=float(np.prod(np.clip(mu,0,1))); acts.append(a)
        locals.append(float(t[0]+t[1:]@x))
    a=np.asarray(acts); s=float(a.sum()); an=np.ones_like(a)/len(a) if s<EPS else a/s
    return float(an@np.asarray(locals)),an

def local_learning(X,y,centers,widths,consequents,epochs=10,eta0=0.1,delta0=1.0,validation_fn=None,compatibility_fn=gaussian_compatibility):
    X=np.asarray(X,float); y=as1d(y); C=np.asarray(centers,float).copy(); W=np.asarray(widths,float).copy(); T=np.asarray(consequents,float).copy()
    trace=[]
    for epoch in range(epochs):
        eta=max(eta0*(1-epoch/max(epochs,1)),eta0*0.05); delta=max(delta0*(1-epoch/max(epochs,1)),0.1)
        for x,yt in zip(X,y):
            dist=np.linalg.norm(C-x,axis=1); q=int(np.argmin(dist)); h=np.exp(-(np.arange(len(C))-q)**2/(2*delta*delta))
            C += eta*h[:,None]*(x-C)
            pred,act=ipinf_inference(x,C,W,T,compatibility_fn)
            e=yt-pred; phi=np.r_[1.0,x]
            T += eta*e*act[:,None]*phi[None,:]
        crit=float(np.mean([(yt-ipinf_inference(x,C,W,T,compatibility_fn)[0])**2 for x,yt in zip(X,y)]))
        if validation_fn is not None: crit=float(validation_fn(C,W,T))
        trace.append({'epoch':epoch+1,'criterion':crit,'eta':eta,'delta':delta})
    return {'centers':C,'widths':W,'consequents':T,'trace':trace}

def gmdh_structure_construction(X,y,Xv,yv,max_layers=3,retain=3,rules=2,epochs=5,seed=0):
    X=np.asarray(X,float); y=as1d(y); Xv=np.asarray(Xv,float); yv=as1d(yv); rng=np.random.default_rng(seed)
    Z=X.copy(); Zv=Xv.copy(); best=None; bestJ=np.inf; trace=[]
    for layer in range(1,max_layers+1):
        cand=[]
        for i in range(Z.shape[1]):
            for j in range(i+1,Z.shape[1]):
                Xi=Z[:,[i,j]]; Xiv=Zv[:,[i,j]]
                idx=rng.choice(len(Xi),size=rules,replace=len(Xi)<rules)
                C=Xi[idx].copy(); W=np.tile(np.maximum(np.std(Xi,axis=0),0.1),(rules,1)); T=np.zeros((rules,3))
                model=local_learning(Xi,y,C,W,T,epochs=epochs)
                pv=np.array([ipinf_inference(x,model['centers'],model['widths'],model['consequents'])[0] for x in Xiv])
                J=float(np.mean((yv-pv)**2)); pt=np.array([ipinf_inference(x,model['centers'],model['widths'],model['consequents'])[0] for x in Xi])
                cand.append((J,(i,j),model,pt,pv))
        cand.sort(key=lambda z:z[0]); kept=cand[:retain]; trace.append({'layer':layer,'best_validation_mse':kept[0][0],'candidates':len(cand)})
        if kept[0][0]>=bestJ-EPS: break
        bestJ=kept[0][0]; best=kept[0]
        Z=np.column_stack([k[3] for k in kept]); Zv=np.column_stack([k[4] for k in kept])
        if Z.shape[1]<2: break
    return {'best':best,'best_validation_mse':bestJ,'trace':trace}

def noise_robust_pipeline(X,y,Xv,yv,**kw): return gmdh_structure_construction(X,y,Xv,yv,**kw)

def source_benchmark_audit(records):
    # records: list of dicts with comparable condition labels and metrics
    return {'source_hash':source_hash(records),'records':records,'warning':'cross-condition comparisons must use compatible settings'}

def robust_gmdh_ipinf_selection(X,y,Xv,yv,max_layers=4,retain=3,rules=2,epochs=5,patience=1,tolerance=1e-6,seed=0):
    # maps V4 Algorithm 6; structural selection is delegated to exact external-criterion layer routine.
    return gmdh_structure_construction(X,y,Xv,yv,max_layers=max_layers,retain=retain,rules=rules,epochs=epochs,seed=seed)

def ipinf_local_inference(x,centers,widths,consequents): return ipinf_inference(x,centers,widths,consequents)

def noise_robust_local_learning(x,y,centers,widths,consequents,eta=0.05,threshold=3.0):
    pred,act=ipinf_inference(x,centers,widths,consequents); residual=float(y-pred)
    scale=max(abs(residual),1.0); weight=min(1.0,threshold*scale/(abs(residual)+EPS))
    T=np.asarray(consequents,float).copy(); phi=np.r_[1.0,as1d(x)]; T += eta*weight*residual*act[:,None]*phi[None,:]
    return {'consequents':T,'residual':residual,'robust_weight':weight}

def external_criterion_layering(X,y,Xv,yv,**kw): return gmdh_structure_construction(X,y,Xv,yv,**kw)

def reanalysis_visualization(D0,target=None,predictions=None):
    out={'source_hash':source_hash(D0),'descriptive_only':True}
    if target is not None and predictions: out['metrics']={k:metrics(target,v) for k,v in predictions.items()}
    return out
