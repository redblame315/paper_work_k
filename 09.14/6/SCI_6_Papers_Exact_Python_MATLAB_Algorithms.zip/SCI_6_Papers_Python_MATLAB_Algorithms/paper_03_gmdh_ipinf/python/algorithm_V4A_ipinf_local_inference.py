"""GMDH-IPINF Nonlinear System Modeling
V4A: IPINF local inference
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import ipinf_local_inference

__all__ = ["ipinf_local_inference"]
