"""GMDH-IPINF Nonlinear System Modeling
06: GMDH-IPINF structure learning, robust fitting and external selection
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import robust_gmdh_ipinf_selection

__all__ = ["robust_gmdh_ipinf_selection"]
