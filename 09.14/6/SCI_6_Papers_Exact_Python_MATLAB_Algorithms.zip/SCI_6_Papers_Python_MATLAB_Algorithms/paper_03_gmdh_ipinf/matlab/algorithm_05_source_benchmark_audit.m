function out=algorithm_05_source_benchmark_audit(records)
out.records=records; out.warning='Reject cross-condition comparisons with incompatible settings; no synthetic observations.';
end
