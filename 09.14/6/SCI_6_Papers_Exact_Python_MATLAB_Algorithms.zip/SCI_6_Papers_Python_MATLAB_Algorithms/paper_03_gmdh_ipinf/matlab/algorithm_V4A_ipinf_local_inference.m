function out=algorithm_V4A_ipinf_local_inference(varargin)
out=algorithm_01_ipinf_inference(varargin{:});
end
