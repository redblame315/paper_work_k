function out=algorithm_V4B_noise_robust_local_learning(x,y,centers,widths,consequents,eta,threshold)
o=algorithm_01_ipinf_inference(x,centers,widths,consequents); residual=y-o.yhat; weight=min(1,threshold*max(abs(residual),1)/(abs(residual)+eps)); phi=[1 x(:)']; T=consequents+eta*weight*residual*(o.activity*phi); out.consequents=T; out.residual=residual; out.robust_weight=weight;
end
