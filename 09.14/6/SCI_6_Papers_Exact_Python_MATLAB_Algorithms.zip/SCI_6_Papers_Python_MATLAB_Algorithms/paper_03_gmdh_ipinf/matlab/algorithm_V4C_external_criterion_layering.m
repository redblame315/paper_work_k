function out=algorithm_V4C_external_criterion_layering(varargin)
out=algorithm_03_gmdh_structure_construction(varargin{:});
end
