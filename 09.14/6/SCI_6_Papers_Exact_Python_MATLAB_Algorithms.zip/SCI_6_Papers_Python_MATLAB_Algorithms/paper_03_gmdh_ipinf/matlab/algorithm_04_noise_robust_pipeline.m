function out=algorithm_04_noise_robust_pipeline(varargin)
out=algorithm_03_gmdh_structure_construction(varargin{:});
end
