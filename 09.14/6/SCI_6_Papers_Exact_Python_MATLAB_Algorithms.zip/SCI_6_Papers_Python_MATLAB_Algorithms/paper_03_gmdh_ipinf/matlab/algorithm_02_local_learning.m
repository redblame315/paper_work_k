function model=algorithm_02_local_learning(X,y,centers,widths,consequents,epochs,eta0,delta0)
C=centers; W=widths; T=consequents; trace=zeros(epochs,2);
for ep=1:epochs, eta=max(eta0*(1-(ep-1)/max(epochs,1)),eta0*0.05); delta=max(delta0*(1-(ep-1)/max(epochs,1)),0.1);
 for k=1:size(X,1), [~,q]=min(vecnorm(C-X(k,:),2,2)); h=exp(-((1:size(C,1))'-q).^2/(2*delta^2)); C=C+eta*h.*(X(k,:)-C); o=algorithm_01_ipinf_inference(X(k,:),C,W,T); e=y(k)-o.yhat; phi=[1 X(k,:)]; T=T+eta*e*(o.activity*phi); end
 pred=zeros(size(y)); for k=1:numel(y), o=algorithm_01_ipinf_inference(X(k,:),C,W,T); pred(k)=o.yhat; end; trace(ep,:)=[ep mean((y(:)-pred(:)).^2)]; end
model.centers=C; model.widths=W; model.consequents=T; model.trace=trace;
end
