function out=algorithm_06_robust_gmdh_ipinf_selection(varargin)
out=algorithm_03_gmdh_structure_construction(varargin{:});
end
