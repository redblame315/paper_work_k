function out=algorithm_03_gmdh_structure_construction(X,y,Xv,yv,maxLayers,retain,rules,epochs)
Z=X; Zv=Xv; bestJ=inf; best=[]; trace=[];
for layer=1:maxLayers, cand={}; n=0; for i=1:size(Z,2), for j=i+1:size(Z,2), n=n+1; Xi=Z(:,[i j]); Xiv=Zv(:,[i j]); C=Xi(round(linspace(1,size(Xi,1),rules)),:); W=repmat(max(std(Xi),0.1),rules,1); T=zeros(rules,3); m=algorithm_02_local_learning(Xi,y,C,W,T,epochs,0.1,1); pv=zeros(numel(yv),1); pt=zeros(numel(y),1); for k=1:numel(yv), q=algorithm_01_ipinf_inference(Xiv(k,:),m.centers,m.widths,m.consequents); pv(k)=q.yhat; end; for k=1:numel(y), q=algorithm_01_ipinf_inference(Xi(k,:),m.centers,m.widths,m.consequents); pt(k)=q.yhat; end; J=mean((yv(:)-pv).^2); cand{n}=struct('J',J,'model',m,'pt',pt,'pv',pv); end, end
 Js=cellfun(@(z)z.J,cand); [~,ord]=sort(Js); kept=cand(ord(1:min(retain,numel(ord)))); if kept{1}.J>=bestJ, break; end; bestJ=kept{1}.J; best=kept{1}; Z=cell2mat(cellfun(@(z)z.pt,kept,'UniformOutput',false)); Zv=cell2mat(cellfun(@(z)z.pv,kept,'UniformOutput',false)); trace=[trace;layer bestJ]; end
out.best=best; out.best_validation_mse=bestJ; out.trace=trace;
end
