function out=algorithm_01_ipinf_inference(x,centers,widths,consequents)
x=x(:)'; nr=size(centers,1); act=zeros(nr,1); local=zeros(nr,1);
for i=1:nr, mu=exp(-0.5*((x-centers(i,:))./max(widths(i,:),eps)).^2); act(i)=prod(mu); local(i)=consequents(i,1)+consequents(i,2:end)*x'; end
if sum(act)<eps, w=ones(nr,1)/nr; else, w=act/sum(act); end; out.yhat=w'*local; out.activity=w;
end
