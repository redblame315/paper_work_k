"""Virtual Design & Virtual Experiment Framework
R: Reproducible experimental re-analysis and visualization
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import reanalysis_visualization

__all__ = ["reanalysis_visualization"]
