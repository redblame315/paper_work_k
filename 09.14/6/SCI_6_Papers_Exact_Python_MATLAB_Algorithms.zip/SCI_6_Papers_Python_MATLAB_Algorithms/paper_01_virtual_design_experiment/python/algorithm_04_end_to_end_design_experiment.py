"""Virtual Design & Virtual Experiment Framework
04: End-to-end intelligent virtual-design/experiment loop
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import end_to_end_design_experiment

__all__ = ["end_to_end_design_experiment"]
