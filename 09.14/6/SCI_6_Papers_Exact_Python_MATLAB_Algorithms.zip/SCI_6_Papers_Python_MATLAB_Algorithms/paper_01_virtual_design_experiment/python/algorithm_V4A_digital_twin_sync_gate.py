"""Virtual Design & Virtual Experiment Framework
V4A: Digital-twin model synchronization and validity gate
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import digital_twin_sync_gate

__all__ = ["digital_twin_sync_gate"]
