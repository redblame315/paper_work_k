"""Virtual Design & Virtual Experiment Framework
03: Reproducible source-data evaluation and integrity check
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import source_data_integrity_check

__all__ = ["source_data_integrity_check"]
