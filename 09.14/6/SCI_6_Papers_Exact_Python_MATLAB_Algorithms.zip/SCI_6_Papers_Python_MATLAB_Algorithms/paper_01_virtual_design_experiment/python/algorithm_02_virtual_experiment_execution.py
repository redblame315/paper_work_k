"""Virtual Design & Virtual Experiment Framework
02: Agent-assisted virtual-experiment execution
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import virtual_experiment_execution

__all__ = ["virtual_experiment_execution"]
