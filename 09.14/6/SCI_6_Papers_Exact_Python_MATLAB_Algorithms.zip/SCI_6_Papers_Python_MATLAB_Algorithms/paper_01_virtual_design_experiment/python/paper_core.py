
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence
import numpy as np

EPS = 1e-12

def clip(x, lo, hi):
    return np.minimum(np.maximum(x, lo), hi)

def as1d(x):
    return np.asarray(x, dtype=float).reshape(-1)

def finite_or_penalty(v, penalty=1e12):
    v=float(v)
    return v if math.isfinite(v) else float(penalty)

def metrics(y, yhat):
    y=as1d(y); yhat=as1d(yhat)
    if len(y)!=len(yhat): raise ValueError('length mismatch')
    e=y-yhat
    mae=float(np.mean(np.abs(e)))
    rmse=float(np.sqrt(np.mean(e*e)))
    denom=np.maximum(np.abs(y), EPS)
    mape=float(np.mean(np.abs(e)/denom)*100.0)
    ss_res=float(np.sum(e*e)); ss_tot=float(np.sum((y-np.mean(y))**2))
    r2=float(1-ss_res/ss_tot) if ss_tot>EPS else float('nan')
    corr=float(np.corrcoef(y,yhat)[0,1]) if len(y)>1 else float('nan')
    return {'n':len(y),'MAE':mae,'RMSE':rmse,'MAPE_percent':mape,'R2':r2,'Pearson_r':corr}

def source_hash(obj: Any) -> str:
    b=json.dumps(obj,sort_keys=True,default=lambda z: np.asarray(z).tolist()).encode('utf-8')
    return hashlib.sha256(b).hexdigest()

def pareto_mask(Y):
    Y=np.asarray(Y,float)
    n=len(Y); keep=np.ones(n,dtype=bool)
    for i in range(n):
        if not keep[i]: continue
        dominated=np.all(Y<=Y[i],axis=1)&np.any(Y<Y[i],axis=1)
        if np.any(dominated): keep[i]=False
    return keep

def normalized_weighted_score(Y, weights=None):
    Y=np.asarray(Y,float)
    lo=np.nanmin(Y,axis=0); hi=np.nanmax(Y,axis=0)
    Yn=(Y-lo)/np.maximum(hi-lo,EPS)
    w=np.ones(Y.shape[1])/Y.shape[1] if weights is None else as1d(weights)/np.sum(weights)
    return Yn@w


def digital_twin_sync_gate(y_p, x_d, model_output, tau, timestamp=None, mapper=None, updater=None):
    y=as1d(y_p); x=as1d(x_d); tau=as1d(tau)
    mapped=y if mapper is None else as1d(mapper(y))
    pred=as1d(model_output(x))
    if len(mapped)!=len(pred) or len(tau)!=len(pred): raise ValueError('dimension mismatch')
    r=mapped-pred
    valid=bool(np.all(np.abs(r)<=tau))
    if valid and updater is not None: x=as1d(updater(x,mapped,r))
    return {'state':x,'residual':r,'valid':valid,'timestamp':timestamp,
            'action':'synchronized' if valid else 'calibration_required'}

def multiobjective_design_search(bounds, simulator, objectives, constraints=(), budget=100, population=20,
                                 weights=None, seed=0, epsilon=1e-6, patience=5):
    rng=np.random.default_rng(seed); bounds=np.asarray(bounds,float)
    lo,hi=bounds[:,0],bounds[:,1]
    X=rng.uniform(lo,hi,size=(min(population,budget),len(lo)))
    trace=[]; evals=0; best_score=np.inf; stagnant=0
    archive=[]
    while evals<budget:
        rec=[]
        for x in X:
            if evals>=budget: break
            response=simulator(x)
            feasible=all(bool(c(x,response)) for c in constraints)
            obj=np.array([float(f(x,response)) for f in objectives]) if feasible else np.full(len(objectives),np.inf)
            rec.append((x.copy(),response,feasible,obj)); evals+=1
        feas=[r for r in rec if r[2] and np.all(np.isfinite(r[3]))]
        archive.extend(feas)
        if not feas: X=rng.uniform(lo,hi,size=(min(population,budget-evals),len(lo))); continue
        Y=np.vstack([r[3] for r in feas]); pm=pareto_mask(Y); pareto=[feas[i] for i in np.where(pm)[0]]
        scores=normalized_weighted_score(Y,weights)
        idx=int(np.argmin(scores)); score=float(scores[idx])
        trace.append({'evaluations':evals,'best_score':score,'pareto_count':int(pm.sum())})
        if best_score-score>epsilon: best_score=score; stagnant=0
        else: stagnant+=1
        if stagnant>=patience or evals>=budget: break
        seeds=np.vstack([p[0] for p in pareto]); n=min(population,budget-evals)
        if n<=0: break
        base=seeds[rng.integers(0,len(seeds),size=n)]
        sigma=(hi-lo)*max(0.02,0.20*(1-evals/max(budget,1)))
        X=np.clip(base+rng.normal(0,sigma,size=base.shape),lo,hi)
    if not archive: return {'selected':None,'pareto':[],'trace':trace,'evaluations':evals}
    Y=np.vstack([r[3] for r in archive]); pm=pareto_mask(Y); par=[archive[i] for i in np.where(pm)[0]]
    P_Y=np.vstack([r[3] for r in par]); ps=normalized_weighted_score(P_Y,weights); sel=par[int(np.argmin(ps))]
    return {'selected':sel[0],'selected_objectives':sel[3],'pareto':[p[0] for p in par],
            'pareto_objectives':P_Y,'trace':trace,'evaluations':evals}

def virtual_design_optimization(bounds, simulator, objectives, constraints=(), expert_modify=None,
                                approve=None, max_rounds=20, **search_kw):
    decision_trace=[]; approved=None
    for round_id in range(max_rounds):
        b=np.asarray(bounds,float)
        result=multiobjective_design_search(b,simulator,objectives,constraints,**search_kw)
        x=result['selected']
        if x is None: return {'approved_design':None,'trace':decision_trace,'reason':'no_feasible_design'}
        if expert_modify is not None: x=as1d(expert_modify(x,result))
        ok=True if approve is None else bool(approve(x,result))
        decision_trace.append({'round':round_id,'candidate':x.tolist(),'approved':ok,'search':result['trace']})
        if ok: approved=x; break
    return {'approved_design':approved,'trace':decision_trace}

def virtual_experiment_execution(model_step, initial_state, actions, validator=None, renderer=None, metric_fn=None):
    state=initial_state; log=[]
    for k,a in enumerate(actions):
        valid,msg=(True,'') if validator is None else validator(state,a)
        if not valid:
            log.append({'k':k,'action':a,'blocked':True,'message':msg}); continue
        state,obs=model_step(state,a)
        if renderer is not None: renderer(state,obs)
        log.append({'k':k,'action':a,'blocked':False,'state':state,'observables':obs})
    return {'final_state':state,'log':log,'metrics':{} if metric_fn is None else metric_fn(log)}

def source_data_integrity_check(source_values, derived_functions=None):
    arr=np.asarray(source_values,float)
    if not np.all(np.isfinite(arr)): raise ValueError('source contains non-finite values; do not silently impute')
    out={'hash':source_hash(arr.tolist()),'shape':arr.shape,'descriptive_only':True}
    for name,fn in (derived_functions or {}).items(): out[name]=fn(arr)
    return out

def end_to_end_design_experiment(scenarios, state_provider, bounds, simulator_factory, objectives,
                                 constraints=(), experiment_runner=None, budget=100, epsilon=1e-6, seed=0):
    best=None; best_score=np.inf; trace=[]
    for sid,s in enumerate(scenarios):
        state=state_provider(s)
        sim=simulator_factory(s,state)
        res=multiobjective_design_search(bounds,sim,objectives,constraints,budget=budget,seed=seed+sid,epsilon=epsilon)
        if res['selected'] is None: trace.append({'scenario':sid,'status':'no_feasible'}); continue
        score=float(np.sum(res['selected_objectives']))
        record={'scenario':sid,'state':state,'design':res['selected'].tolist(),'score':score}
        if experiment_runner is not None: record['experiment']=experiment_runner(s,res['selected'])
        trace.append(record)
        if best_score-score>epsilon: best_score=score; best=res['selected']
    return {'accepted_design':best,'best_score':best_score,'trace':trace}

def pedagogical_virtual_experiment(model_step, initial_state, actions, safety_rule, target_relation=None, feedback_fn=None):
    state=initial_state; log=[]
    for k,a in enumerate(actions):
        ok,reason=safety_rule(state,a)
        if not ok:
            log.append({'k':k,'action':a,'blocked':True,'feedback':reason}); continue
        new_state,obs=model_step(state,a); state=new_state
        relation=None if target_relation is None else target_relation(state,obs)
        feedback=(f'cause-effect relation={relation}' if feedback_fn is None else feedback_fn(state,obs,relation))
        log.append({'k':k,'action':a,'blocked':False,'observables':obs,'feedback':feedback})
    return log

def reanalysis_visualization(D0, target=None, predictions=None):
    out={'source_hash':source_hash(D0),'descriptive_only':True}
    if target is not None and predictions:
        out['metrics']={name:metrics(target,p) for name,p in predictions.items()}
    return out
