"""Virtual Design & Virtual Experiment Framework
V4B: Multi-objective virtual design search
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import multiobjective_design_search

__all__ = ["multiobjective_design_search"]
