"""Virtual Design & Virtual Experiment Framework
V4C: Virtual experiment with pedagogical feedback
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import pedagogical_virtual_experiment

__all__ = ["pedagogical_virtual_experiment"]
