"""Virtual Design & Virtual Experiment Framework
01: Intelligent virtual-design optimization loop
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import virtual_design_optimization

__all__ = ["virtual_design_optimization"]
