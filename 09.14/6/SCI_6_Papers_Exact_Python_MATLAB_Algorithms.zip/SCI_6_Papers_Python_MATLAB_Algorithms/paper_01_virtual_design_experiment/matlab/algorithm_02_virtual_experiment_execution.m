function out = algorithm_02_virtual_experiment_execution(modelStep, initialState, actions, validator)
state=initialState; log=cell(numel(actions),1);
for k=1:numel(actions)
  a=actions{k}; [ok,msg]=validator(state,a);
  if ~ok, log{k}=struct('k',k,'blocked',true,'message',msg); continue; end
  [state,obs]=modelStep(state,a); log{k}=struct('k',k,'blocked',false,'state',state,'observables',obs);
end
out.final_state=state; out.log=log;
end
