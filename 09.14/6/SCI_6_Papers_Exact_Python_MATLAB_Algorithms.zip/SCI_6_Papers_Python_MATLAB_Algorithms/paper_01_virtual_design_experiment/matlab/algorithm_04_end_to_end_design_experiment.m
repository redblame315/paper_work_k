function out = algorithm_04_end_to_end_design_experiment(scenarios,stateProvider,bounds,simulatorFactory,objectives,constraints,budget)
best=[]; bestScore=inf; trace=cell(numel(scenarios),1);
for s=1:numel(scenarios)
  state=stateProvider(scenarios{s}); simulator=simulatorFactory(scenarios{s},state);
  r=algorithm_01_virtual_design_optimization(bounds,simulator,objectives,constraints,budget,20,s);
  trace{s}=r; if ~isempty(r.selected) && r.best_score<bestScore, best=r.selected; bestScore=r.best_score; end
end
out.accepted_design=best; out.best_score=bestScore; out.trace=trace;
end
