disp('MATLAB algorithm files present:');
d=dir('algorithm_*.m'); disp(numel(d));
