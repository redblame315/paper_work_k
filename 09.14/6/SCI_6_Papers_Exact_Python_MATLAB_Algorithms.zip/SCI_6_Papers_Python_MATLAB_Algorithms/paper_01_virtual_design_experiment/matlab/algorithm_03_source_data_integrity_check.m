function out = algorithm_03_source_data_integrity_check(sourceValues)
if any(~isfinite(sourceValues(:))), error('Source contains non-finite values; do not silently impute'); end
out.shape=size(sourceValues); out.descriptive_only=true; out.min=min(sourceValues(:)); out.max=max(sourceValues(:));
end
