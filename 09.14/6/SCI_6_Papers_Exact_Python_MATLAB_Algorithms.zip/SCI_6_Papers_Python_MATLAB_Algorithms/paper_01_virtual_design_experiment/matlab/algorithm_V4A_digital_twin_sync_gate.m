function out = algorithm_V4A_digital_twin_sync_gate(y_p,x_d,modelOutput,tau)
pred=modelOutput(x_d); r=y_p(:)-pred(:); valid=all(abs(r)<=tau(:)); out.state=x_d; out.residual=r; out.valid=valid; if valid, out.action='synchronized'; else, out.action='calibration_required'; end
end
