function out = algorithm_V4B_multiobjective_design_search(bounds,simulator,objectives,constraints,budget,population,seed)
out=algorithm_01_virtual_design_optimization(bounds,simulator,objectives,constraints,budget,population,seed);
end
