function log = algorithm_V4C_pedagogical_virtual_experiment(modelStep,initialState,actions,safetyRule,feedbackFn)
state=initialState; log=cell(numel(actions),1);
for k=1:numel(actions)
 [ok,reason]=safetyRule(state,actions{k}); if ~ok, log{k}=struct('blocked',true,'feedback',reason); continue; end
 [state,obs]=modelStep(state,actions{k}); fb=feedbackFn(state,obs); log{k}=struct('blocked',false,'observables',obs,'feedback',fb);
end
end
