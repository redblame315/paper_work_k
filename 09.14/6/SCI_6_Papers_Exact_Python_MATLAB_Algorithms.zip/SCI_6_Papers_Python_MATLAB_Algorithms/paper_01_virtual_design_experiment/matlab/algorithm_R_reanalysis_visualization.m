function out = algorithm_R_reanalysis_visualization(D0)
if any(~isfinite(D0(:))), error('Invalid source data'); end
out.n=numel(D0); out.mean=mean(D0(:)); out.sd=std(D0(:)); out.descriptive_only=true;
end
