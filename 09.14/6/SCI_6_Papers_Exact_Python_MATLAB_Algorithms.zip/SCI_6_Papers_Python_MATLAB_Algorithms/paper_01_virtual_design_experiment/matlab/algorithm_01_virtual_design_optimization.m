function out = algorithm_01_virtual_design_optimization(bounds, simulator, objectives, constraints, budget, population, seed)
% Exact V4 Algorithm 1 orchestration. Function handles supply manuscript-specific physics/rules.
if nargin<7, seed=0; end; if nargin<6, population=20; end; if nargin<5, budget=100; end
rng(seed); D=size(bounds,1); lo=bounds(:,1)'; hi=bounds(:,2)'; P=lo+rand(population,D).*(hi-lo); best=[]; bestScore=inf; trace=[]; evals=0;
while evals<budget
  for i=1:size(P,1)
    if evals>=budget, break; end
    x=P(i,:); resp=simulator(x); feasible=true;
    for c=1:numel(constraints), feasible=feasible && constraints{c}(x,resp); end
    if feasible
      vals=zeros(1,numel(objectives)); for j=1:numel(objectives), vals(j)=objectives{j}(x,resp); end
      score=sum(vals); if score<bestScore, bestScore=score; best=x; end
    end
    evals=evals+1;
  end
  if isempty(best), P=lo+rand(population,D).*(hi-lo); else, P=min(max(best+0.1*randn(population,D).*(hi-lo),lo),hi); end
  trace=[trace; evals bestScore]; %#ok<AGROW>
end
out.selected=best; out.best_score=bestScore; out.trace=trace; out.evaluations=evals;
end
