# Source limitations / author-verification points

The manuscript defines the orchestration/search logic but does not provide a single universal heat-exchanger/physics simulator callable for every design scenario, a unique expert-rule knowledge base, or a unique scalarization rule for all objectives. Therefore the exact implementation accepts `simulator`, `constraints`, objective functions, and expert/human callbacks as arguments. The demo simulator is illustrative and is not claimed as a source experiment.
