"""Neuro-Fuzzy PI Control for Vacuum Concentration
V4B: Single-neuron adaptive correction
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import bounded_neuron_update

__all__ = ["bounded_neuron_update"]
