"""Neuro-Fuzzy PI Control for Vacuum Concentration
V4C: Industrial control cycle with saturation and anti-windup
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import industrial_control_cycle

__all__ = ["industrial_control_cycle"]
