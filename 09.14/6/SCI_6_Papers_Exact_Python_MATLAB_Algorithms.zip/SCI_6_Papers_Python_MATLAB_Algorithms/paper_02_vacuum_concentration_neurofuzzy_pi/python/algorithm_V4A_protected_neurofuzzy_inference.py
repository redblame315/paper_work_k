"""Neuro-Fuzzy PI Control for Vacuum Concentration
V4A: Neuro-fuzzy PI inference with protected normalization
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import protected_neurofuzzy_inference

__all__ = ["protected_neurofuzzy_inference"]
