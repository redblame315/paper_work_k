"""Neuro-Fuzzy PI Control for Vacuum Concentration
04: Reproducible source-data evaluation and integrity check
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import source_production_analysis

__all__ = ["source_production_analysis"]
