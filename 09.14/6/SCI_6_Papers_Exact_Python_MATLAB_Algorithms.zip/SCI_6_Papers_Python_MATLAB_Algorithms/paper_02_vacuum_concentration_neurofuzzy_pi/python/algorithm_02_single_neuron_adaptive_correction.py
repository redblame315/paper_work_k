"""Neuro-Fuzzy PI Control for Vacuum Concentration
02: Single-neuron adaptive correction
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import single_neuron_adaptive_correction

__all__ = ["single_neuron_adaptive_correction"]
