
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence
import numpy as np

EPS = 1e-12

def clip(x, lo, hi):
    return np.minimum(np.maximum(x, lo), hi)

def as1d(x):
    return np.asarray(x, dtype=float).reshape(-1)

def finite_or_penalty(v, penalty=1e12):
    v=float(v)
    return v if math.isfinite(v) else float(penalty)

def metrics(y, yhat):
    y=as1d(y); yhat=as1d(yhat)
    if len(y)!=len(yhat): raise ValueError('length mismatch')
    e=y-yhat
    mae=float(np.mean(np.abs(e)))
    rmse=float(np.sqrt(np.mean(e*e)))
    denom=np.maximum(np.abs(y), EPS)
    mape=float(np.mean(np.abs(e)/denom)*100.0)
    ss_res=float(np.sum(e*e)); ss_tot=float(np.sum((y-np.mean(y))**2))
    r2=float(1-ss_res/ss_tot) if ss_tot>EPS else float('nan')
    corr=float(np.corrcoef(y,yhat)[0,1]) if len(y)>1 else float('nan')
    return {'n':len(y),'MAE':mae,'RMSE':rmse,'MAPE_percent':mape,'R2':r2,'Pearson_r':corr}

def source_hash(obj: Any) -> str:
    b=json.dumps(obj,sort_keys=True,default=lambda z: np.asarray(z).tolist()).encode('utf-8')
    return hashlib.sha256(b).hexdigest()

def pareto_mask(Y):
    Y=np.asarray(Y,float)
    n=len(Y); keep=np.ones(n,dtype=bool)
    for i in range(n):
        if not keep[i]: continue
        dominated=np.all(Y<=Y[i],axis=1)&np.any(Y<Y[i],axis=1)
        if np.any(dominated): keep[i]=False
    return keep

def normalized_weighted_score(Y, weights=None):
    Y=np.asarray(Y,float)
    lo=np.nanmin(Y,axis=0); hi=np.nanmax(Y,axis=0)
    Yn=(Y-lo)/np.maximum(hi-lo,EPS)
    w=np.ones(Y.shape[1])/Y.shape[1] if weights is None else as1d(weights)/np.sum(weights)
    return Yn@w

SOURCE_PRODUCTION_BEFORE=np.array([5.6,5.7,5.5,6.0,5.8,5.5,5.6,5.3,6.2,6.0,5.5,5.3,5.4,5.3,5.3,5.4,5.8,5.4,5.6,5.3])
SOURCE_PRODUCTION_AFTER =np.array([4.2,4.3,4.3,4.2,4.4,4.6,4.1,4.3,4.2,4.6,4.1,4.1,4.3,4.2,4.3,4.2,4.3,4.4,4.1,4.3])

def triangular_mu(x,a,b,c):
    if not (a<=b<=c): raise ValueError('triangular set requires a<=b<=c')
    if x<=a or x>=c: return float(x==b and a==b==c)
    if x==b: return 1.0
    return (x-a)/(b-a+EPS) if x<b else (c-x)/(c-b+EPS)

def fuzzify(x, partitions):
    # partitions: list of (a,b,c)
    return np.array([triangular_mu(float(x),*p) for p in partitions],float)

def fuzzy_pi_incremental_inference(r,y,e_prev,Ke,Kde,Ku,e_partitions,de_partitions,rule_outputs,universe=(-1,1)):
    e=float(r-y); de=float(e-e_prev)
    E=float(np.clip(Ke*e,*universe)); DE=float(np.clip(Kde*de,*universe))
    me=fuzzify(E,e_partitions); md=fuzzify(DE,de_partitions)
    R=np.asarray(rule_outputs,float)
    if R.shape!=(len(me),len(md)): raise ValueError('rule_outputs shape must match fuzzy partitions')
    W=np.minimum(me[:,None],md[None,:]); s=float(W.sum())
    du_f=0.0 if s<EPS else float(np.sum(W*R)/s)
    return {'du_pi':float(Ku*du_f),'e':e,'de':de,'E':E,'DE':DE,'activation':W,'du_fuzzy':du_f}

def single_neuron_adaptive_correction(x,w,eta,adaptation_signal,e,deadband=0.0,wmin=-np.inf,wmax=np.inf,update=True):
    x=as1d(x); w=as1d(w)
    if len(x)!=len(w): raise ValueError('x and w length mismatch')
    du=float(w@x); new=w.copy()
    if update and abs(e)>deadband:
        new=np.clip(w+eta*float(adaptation_signal)*x,wmin,wmax)
    return du,new

def industrial_control_cycle(du_fuzzy,du_n,u_prev,umin,umax,integral_state=None,adapt_state=None):
    u_star=float(u_prev+du_fuzzy+du_n); u=float(np.clip(u_star,umin,umax)); sat=(u!=u_star)
    return {'u':u,'u_star':u_star,'saturated':sat,'anti_windup_hold':sat}

def realtime_neurofuzzy_pi_loop(references, measurements, cfg, neuron_weights):
    refs=as1d(references); ys=as1d(measurements)
    if len(refs)!=len(ys): raise ValueError('length mismatch')
    w=as1d(neuron_weights); eprev=0.0; u=float(cfg.get('u0',0.0)); log=[]
    for k,(r,y) in enumerate(zip(refs,ys)):
        f=fuzzy_pi_incremental_inference(r,y,eprev,cfg['Ke'],cfg['Kde'],cfg['Ku'],cfg['e_partitions'],cfg['de_partitions'],cfg['rule_outputs'],cfg.get('universe',(-1,1)))
        z=np.array([f['e'],f['de']] + ([sum(v['e'] for v in log)] if cfg.get('include_integral_feature') else []),float)
        if len(z)!=len(w): z=np.resize(z,len(w))
        adapt=-f['e']
        du_n,w=single_neuron_adaptive_correction(z,w,cfg['eta'],adapt,f['e'],cfg.get('deadband',0),cfg.get('wmin',-10),cfg.get('wmax',10),update=not bool(cfg.get('freeze_adaptation',False)))
        c=industrial_control_cycle(f['du_pi'],du_n,u,cfg['umin'],cfg['umax']); u=c['u']
        log.append({'k':k,'r':r,'y':y,'e':f['e'],'de':f['de'],'u':u,'du_pi':f['du_pi'],'du_n':du_n,'saturated':c['saturated'],'weights':w.copy()})
        eprev=f['e']
    return log

def source_production_analysis(before=SOURCE_PRODUCTION_BEFORE,after=SOURCE_PRODUCTION_AFTER):
    from scipy import stats
    b=as1d(before); a=as1d(after)
    if len(b)!=20 or len(a)!=20: raise ValueError('V4 source-analysis algorithm expects n=20 in each historical period')
    mb=float(np.mean(b)); ma=float(np.mean(a)); sb=float(np.std(b,ddof=1)); sa=float(np.std(a,ddof=1))
    diff=mb-ma; rel=100*diff/mb
    # Welch CI for difference
    se=math.sqrt(sb*sb/len(b)+sa*sa/len(a))
    df=(sb*sb/len(b)+sa*sa/len(a))**2/((sb*sb/len(b))**2/(len(b)-1)+(sa*sa/len(a))**2/(len(a)-1))
    tcrit=float(stats.t.ppf(0.975,df)); ci=(diff-tcrit*se,diff+tcrit*se)
    t,p=stats.ttest_ind(b,a,equal_var=False)
    return {'n_before':len(b),'n_after':len(a),'mean_before':mb,'mean_after':ma,'sd_before':sb,'sd_after':sa,
            'mean_difference_hours':diff,'relative_reduction_percent':rel,'welch_95CI_difference':ci,'welch_t':float(t),'posthoc_p':float(p),
            'causal_warning':'historical before/after comparison; not randomized causal evidence'}

def bounded_neurofuzzy_pi_control(references, measurement_fn, apply_fn, cfg, neuron_weights, n_steps):
    w=as1d(neuron_weights); eprev=0.0; I=0.0; u=float(cfg.get('u0',0)); log=[]
    for k in range(n_steps):
        r=float(references(k) if callable(references) else references[k]); y=float(measurement_fn(k))
        if not np.isfinite(y): apply_fn(u); log.append({'k':k,'fault':'invalid_sensor','u':u}); continue
        f=fuzzy_pi_incremental_inference(r,y,eprev,cfg['Ke'],cfg['Kde'],1.0,cfg['e_partitions'],cfg['de_partitions'],cfg['rule_outputs'])
        # manuscript allows fuzzy corrections to Kp/Ki; rule_outputs may encode baseline incremental action.
        I_candidate=I+f['e']*cfg.get('Ts',0.1)
        z=np.resize(np.array([f['e'],f['de'],I_candidate,u]),len(w))
        du_n=float(w@z); u_star=u+cfg['Ku']*f['du_fuzzy']+du_n
        u_new=float(np.clip(u_star,cfg['umin'],cfg['umax']))
        saturated=(u_new!=u_star)
        if not saturated: I=I_candidate
        if abs(f['e'])>cfg.get('deadband',0) and not saturated:
            grad_signal=f['e']
            w=np.clip(w-cfg['eta']*grad_signal*z,cfg.get('wmin',-10),cfg.get('wmax',10))
        apply_fn(u_new); u=u_new
        log.append({'k':k,'r':r,'y':y,'e':f['e'],'de':f['de'],'u':u,'I':I,'weights':w.copy(),'saturated':saturated})
        eprev=f['e']
    return log,w

def protected_neurofuzzy_inference(*args, fallback_pi=None, **kwargs):
    out=fuzzy_pi_incremental_inference(*args,**kwargs)
    total=float(np.sum(out['activation']))
    if total<EPS and fallback_pi is not None: out['du_pi']=float(fallback_pi(out['e'],out['de'])); out['fallback']=True
    else: out['fallback']=False
    return out

def bounded_neuron_update(e,de,w,eta,wmin,wmax,deadband=0.0,saturated=False,history_terms=()):
    z=np.array([e,de,*history_terms],float); z=np.resize(z,len(as1d(w)))
    return single_neuron_adaptive_correction(z,w,eta,-e,e,deadband,wmin,wmax,update=not saturated)

def reanalysis_visualization(D0=None, target=None, predictions=None):
    out={'source_hash':source_hash(D0 if D0 is not None else {'before':SOURCE_PRODUCTION_BEFORE.tolist(),'after':SOURCE_PRODUCTION_AFTER.tolist()}),'descriptive_only':True}
    if target is not None and predictions: out['metrics']={k:metrics(target,v) for k,v in predictions.items()}
    return out
