"""Neuro-Fuzzy PI Control for Vacuum Concentration
05: Neuro-fuzzy PI control with bounded online adaptation
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import bounded_neurofuzzy_pi_control

__all__ = ["bounded_neurofuzzy_pi_control"]
