"""Neuro-Fuzzy PI Control for Vacuum Concentration
03: Real-time neuro-fuzzy PI control loop
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import realtime_neurofuzzy_pi_loop

__all__ = ["realtime_neurofuzzy_pi_loop"]
