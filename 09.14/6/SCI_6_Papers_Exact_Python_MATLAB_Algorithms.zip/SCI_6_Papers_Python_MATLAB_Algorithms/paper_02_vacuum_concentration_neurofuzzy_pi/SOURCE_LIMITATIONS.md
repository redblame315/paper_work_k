# Source limitations / author-verification points

The source specifies fuzzy inference, center-average defuzzification, single-neuron direct learning, and a 0.1 s sampling period, but the V4 paper does not uniquely reproduce every original membership breakpoint, complete rule-output table, learning-signal equation, or production plant transfer function in machine-readable form. These are required configuration inputs. The historical before/after production-time data are included exactly as reported in the source table.
