function out=algorithm_V4B_bounded_neuron_update(e,de,w,eta,wmin,wmax,deadband,saturated)
z=[e;de]; z=repmat(z,ceil(numel(w)/2),1); z=z(1:numel(w)); out=algorithm_02_single_neuron_adaptive_correction(z,w,eta,-e,e,deadband,wmin,wmax,~saturated);
end
