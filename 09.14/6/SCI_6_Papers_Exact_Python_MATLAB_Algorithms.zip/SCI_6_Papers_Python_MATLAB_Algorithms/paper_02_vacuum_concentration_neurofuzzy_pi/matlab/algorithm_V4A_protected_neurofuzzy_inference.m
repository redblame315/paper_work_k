function out=algorithm_V4A_protected_neurofuzzy_inference(r,y,ePrev,Ke,Kde,Ku,eParts,deParts,ruleOutputs)
out=algorithm_01_fuzzy_pi_incremental_inference(r,y,ePrev,Ke,Kde,Ku,eParts,deParts,ruleOutputs); out.fallback=(sum(out.activation,'all')<eps);
end
