function out = algorithm_04_source_production_analysis()
b=[5.6 5.7 5.5 6.0 5.8 5.5 5.6 5.3 6.2 6.0 5.5 5.3 5.4 5.3 5.3 5.4 5.8 5.4 5.6 5.3];
a=[4.2 4.3 4.3 4.2 4.4 4.6 4.1 4.3 4.2 4.6 4.1 4.1 4.3 4.2 4.3 4.2 4.3 4.4 4.1 4.3];
out.n_before=numel(b); out.n_after=numel(a); out.mean_before=mean(b); out.mean_after=mean(a); out.sd_before=std(b); out.sd_after=std(a); out.mean_difference=mean(b)-mean(a); out.relative_reduction_percent=100*out.mean_difference/mean(b); out.causal_warning='historical before/after comparison; not randomized causal evidence';
end
