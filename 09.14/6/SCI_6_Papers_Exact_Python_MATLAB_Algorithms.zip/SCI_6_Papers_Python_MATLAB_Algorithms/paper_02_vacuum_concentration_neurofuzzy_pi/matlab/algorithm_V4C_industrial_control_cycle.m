function out=algorithm_V4C_industrial_control_cycle(duFuzzy,duN,uPrev,umin,umax)
uStar=uPrev+duFuzzy+duN; u=min(max(uStar,umin),umax); out.u=u; out.u_star=uStar; out.saturated=(u~=uStar); out.anti_windup_hold=out.saturated;
end
