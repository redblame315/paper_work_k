function out = algorithm_01_fuzzy_pi_incremental_inference(r,y,ePrev,Ke,Kde,Ku,eParts,deParts,ruleOutputs)
e=r-y; de=e-ePrev; E=min(max(Ke*e,-1),1); DE=min(max(Kde*de,-1),1);
me=local_fuzzify(E,eParts); md=local_fuzzify(DE,deParts); W=min(me(:),md(:)'); s=sum(W,'all'); if s<eps, duF=0; else, duF=sum(W.*ruleOutputs,'all')/s; end
out=struct('du_pi',Ku*duF,'e',e,'de',de,'E',E,'DE',DE,'activation',W,'du_fuzzy',duF);
end
function mu=local_fuzzify(x,P)
mu=zeros(size(P,1),1); for i=1:size(P,1), a=P(i,1); b=P(i,2); c=P(i,3); if x<=a || x>=c, mu(i)=double(x==b && a==b && b==c); elseif x==b, mu(i)=1; elseif x<b, mu(i)=(x-a)/max(b-a,eps); else, mu(i)=(c-x)/max(c-b,eps); end, end
end
