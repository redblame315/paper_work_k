function out = algorithm_02_single_neuron_adaptive_correction(x,w,eta,adaptSignal,e,deadband,wmin,wmax,doUpdate)
x=x(:); w=w(:); du=w'*x; wn=w; if doUpdate && abs(e)>deadband, wn=min(max(w+eta*adaptSignal*x,wmin),wmax); end; out.du_n=du; out.w_new=wn;
end
