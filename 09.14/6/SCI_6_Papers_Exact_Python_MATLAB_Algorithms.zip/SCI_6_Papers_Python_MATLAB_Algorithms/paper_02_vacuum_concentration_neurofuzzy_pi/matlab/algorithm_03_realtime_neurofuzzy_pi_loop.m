function log = algorithm_03_realtime_neurofuzzy_pi_loop(refs,ys,cfg,w)
ePrev=0; u=cfg.u0; log=cell(numel(refs),1);
for k=1:numel(refs)
 f=algorithm_01_fuzzy_pi_incremental_inference(refs(k),ys(k),ePrev,cfg.Ke,cfg.Kde,cfg.Ku,cfg.e_parts,cfg.de_parts,cfg.rule_outputs);
 z=[f.e;f.de]; z=repmat(z,ceil(numel(w)/2),1); z=z(1:numel(w)); n=algorithm_02_single_neuron_adaptive_correction(z,w,cfg.eta,-f.e,f.e,cfg.deadband,cfg.wmin,cfg.wmax,true); w=n.w_new;
 uStar=u+f.du_pi+n.du_n; u=min(max(uStar,cfg.umin),cfg.umax); log{k}=struct('e',f.e,'de',f.de,'u',u,'weights',w); ePrev=f.e;
end
end
