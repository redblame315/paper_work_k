function out=algorithm_V4C_recursion_depth_selection(errors,epsilon,K)
if nargin<1 || isempty(errors), errors=[-10 12.5 -4.4 1.25 -.16 -.16 -.16 .02 -.06 -.02]; end; if nargin<2, epsilon=.1; end; if nargin<3, K=2; end
con=0; chosen=numel(errors); prev=[]; for r=1:numel(errors), e=abs(errors(r)); if ~isempty(prev) && abs(prev-e)<epsilon, con=con+1; else, con=0; end; if con>=K, chosen=r-K+1; break; end; prev=e; end; out.chosen_depth=chosen; out.errors=errors;
end
