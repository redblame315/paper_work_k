function log=algorithm_05_recursive_fuzzy_control_cycle(varargin)
log=algorithm_03_online_furnace_control(varargin{:});
end
