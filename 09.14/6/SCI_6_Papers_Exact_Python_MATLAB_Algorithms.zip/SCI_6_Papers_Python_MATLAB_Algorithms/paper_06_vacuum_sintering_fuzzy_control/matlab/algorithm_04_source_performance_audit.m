function out=algorithm_04_source_performance_audit()
out.step.PID=[52.3 0 22.34 22.8]; out.step.GenericFuzzy=[60.1 NaN NaN 22.2]; out.step.RecursiveFuzzy=[27 .03 23 15.6]; out.tracking_variance=[.71995 2.7748 .49973]; out.disturbance_variance=[30.0035 33.3794 27.5194]; out.recursion_error=[-10 12.5 -4.4 1.25 -.16 -.16 -.16 .02 -.06 -.02]; out.recursive_vs_pid_overshoot_reduction_percent=100*(52.3-27)/52.3; out.descriptive_only=true;
end
