function out=algorithm_01_initial_factor_gain_selection(eRange,deRange,uUniverse,actLimits,deadzone)
emax=max(abs(eRange)); demax=max(abs(deRange)); out.Ke=2/max(emax,eps); out.Kde=2/max(demax,eps); umax=max(abs(uUniverse)); out.Ku=(actLimits(2)-actLimits(1))/(2*max(umax,eps)); out.deadzone=deadzone;
end
