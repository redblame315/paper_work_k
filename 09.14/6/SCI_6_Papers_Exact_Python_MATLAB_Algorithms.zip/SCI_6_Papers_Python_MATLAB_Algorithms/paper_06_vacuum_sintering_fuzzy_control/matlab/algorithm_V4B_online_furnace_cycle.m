function log=algorithm_V4B_online_furnace_cycle(varargin)
log=algorithm_03_online_furnace_control(varargin{:});
end
