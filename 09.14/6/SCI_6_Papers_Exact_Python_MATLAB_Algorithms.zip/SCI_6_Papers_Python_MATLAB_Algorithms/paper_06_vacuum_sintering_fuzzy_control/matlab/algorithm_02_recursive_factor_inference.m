function out=algorithm_02_recursive_factor_inference(E,DE,T,R,lambda,deadzone)
if nargin<3 || isempty(T), T=[2 2 1 1 0;2 1 1 0 -1;1 1 0 -1 -1;1 0 -1 -1 -2;0 -1 -1 -2 -2]; end
res=E; du=0; scale=1; trace=zeros(R,4); used=0; for j=1:R, ei=min(max(round(res*scale),-2),2)+3; di=min(max(round(DE*scale),-2),2)+3; q=T(di,ei); inc=q/scale; du=du+inc; res=res-inc; used=j; trace(j,:)=[j q inc res]; if abs(res)<deadzone, break; end; scale=scale*lambda; end; out.du=du; out.trace=trace(1:used,:); out.depth=used;
end
