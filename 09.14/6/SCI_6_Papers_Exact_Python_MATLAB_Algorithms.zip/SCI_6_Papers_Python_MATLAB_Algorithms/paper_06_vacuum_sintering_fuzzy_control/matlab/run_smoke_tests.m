disp('MATLAB algorithm files present:');
d=dir('algorithm_*.m'); disp(numel(d));
disp(algorithm_04_source_performance_audit());
