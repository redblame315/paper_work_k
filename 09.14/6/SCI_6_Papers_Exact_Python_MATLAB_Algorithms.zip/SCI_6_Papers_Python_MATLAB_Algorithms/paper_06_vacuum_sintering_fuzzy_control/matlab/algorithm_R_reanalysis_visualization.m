function out=algorithm_R_reanalysis_visualization()
out=algorithm_04_source_performance_audit();
end
