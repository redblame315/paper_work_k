function out=algorithm_V4A_recursive_fuzzy_refinement(e,de,T,R,Ke,Kde,Ku,lambda,epsilon)
a=algorithm_02_recursive_factor_inference(Ke*e,Kde*de,T,R,lambda,epsilon); out.du=Ku*a.du; out.depth=a.depth; out.trace=a.trace;
end
