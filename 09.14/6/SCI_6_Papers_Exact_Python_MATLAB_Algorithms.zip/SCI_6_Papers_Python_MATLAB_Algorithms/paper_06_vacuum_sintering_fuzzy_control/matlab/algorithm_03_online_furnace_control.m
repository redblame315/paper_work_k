function log=algorithm_03_online_furnace_control(setpoints,measurements,Ke,Kde,Ku,R,T,u0,limits,deadzone)
ePrev=0; u=u0; log=cell(numel(setpoints),1); for k=1:numel(setpoints), e=setpoints(k)-measurements(k); de=e-ePrev; a=algorithm_02_recursive_factor_inference(Ke*e,Kde*de,T,R,2,deadzone); u=min(max(u+Ku*a.du,limits(1)),limits(2)); log{k}=struct('e',e,'de',de,'u',u,'depth',a.depth); ePrev=e; end
end
