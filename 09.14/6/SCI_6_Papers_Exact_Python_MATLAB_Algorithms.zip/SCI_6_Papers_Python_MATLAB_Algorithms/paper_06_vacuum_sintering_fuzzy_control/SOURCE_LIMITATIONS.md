# Source limitations / author-verification points

The source provides the 5x5 linguistic/control lookup table, recursion-depth results, and controller-comparison metrics, but does not provide a universal furnace plant model in executable form. The exact controller logic therefore accepts the plant/sensor/actuator interfaces as callbacks. The control table and source benchmark metrics are encoded in the paper core.
