"""Recursive-Factor Fuzzy Control for Vacuum Sintering
02: Recursive-factor fuzzy inference
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import recursive_factor_inference

__all__ = ["recursive_factor_inference"]
