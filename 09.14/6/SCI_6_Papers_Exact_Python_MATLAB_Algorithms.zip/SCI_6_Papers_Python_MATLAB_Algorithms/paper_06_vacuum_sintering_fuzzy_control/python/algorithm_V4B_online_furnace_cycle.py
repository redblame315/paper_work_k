"""Recursive-Factor Fuzzy Control for Vacuum Sintering
V4B: Online furnace temperature-control cycle
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import online_furnace_cycle

__all__ = ["online_furnace_cycle"]
