"""Recursive-Factor Fuzzy Control for Vacuum Sintering
V4C: Recursion-depth selection and validation
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import recursion_depth_selection

__all__ = ["recursion_depth_selection"]
