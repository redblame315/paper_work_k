"""Recursive-Factor Fuzzy Control for Vacuum Sintering
V4A: Recursive-factor fuzzy refinement
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import recursive_fuzzy_refinement

__all__ = ["recursive_fuzzy_refinement"]
