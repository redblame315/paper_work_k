"""Recursive-Factor Fuzzy Control for Vacuum Sintering
05: Recursive-factor fuzzy temperature-control cycle
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import recursive_fuzzy_control_cycle

__all__ = ["recursive_fuzzy_control_cycle"]
