"""Recursive-Factor Fuzzy Control for Vacuum Sintering
01: Initial factor and gain selection
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import initial_factor_gain_selection

__all__ = ["initial_factor_gain_selection"]
