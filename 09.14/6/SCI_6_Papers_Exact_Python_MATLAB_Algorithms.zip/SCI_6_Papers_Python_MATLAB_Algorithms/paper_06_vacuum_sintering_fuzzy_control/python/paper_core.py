
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence
import numpy as np

EPS = 1e-12

def clip(x, lo, hi):
    return np.minimum(np.maximum(x, lo), hi)

def as1d(x):
    return np.asarray(x, dtype=float).reshape(-1)

def finite_or_penalty(v, penalty=1e12):
    v=float(v)
    return v if math.isfinite(v) else float(penalty)

def metrics(y, yhat):
    y=as1d(y); yhat=as1d(yhat)
    if len(y)!=len(yhat): raise ValueError('length mismatch')
    e=y-yhat
    mae=float(np.mean(np.abs(e)))
    rmse=float(np.sqrt(np.mean(e*e)))
    denom=np.maximum(np.abs(y), EPS)
    mape=float(np.mean(np.abs(e)/denom)*100.0)
    ss_res=float(np.sum(e*e)); ss_tot=float(np.sum((y-np.mean(y))**2))
    r2=float(1-ss_res/ss_tot) if ss_tot>EPS else float('nan')
    corr=float(np.corrcoef(y,yhat)[0,1]) if len(y)>1 else float('nan')
    return {'n':len(y),'MAE':mae,'RMSE':rmse,'MAPE_percent':mape,'R2':r2,'Pearson_r':corr}

def source_hash(obj: Any) -> str:
    b=json.dumps(obj,sort_keys=True,default=lambda z: np.asarray(z).tolist()).encode('utf-8')
    return hashlib.sha256(b).hexdigest()

def pareto_mask(Y):
    Y=np.asarray(Y,float)
    n=len(Y); keep=np.ones(n,dtype=bool)
    for i in range(n):
        if not keep[i]: continue
        dominated=np.all(Y<=Y[i],axis=1)&np.any(Y<Y[i],axis=1)
        if np.any(dominated): keep[i]=False
    return keep

def normalized_weighted_score(Y, weights=None):
    Y=np.asarray(Y,float)
    lo=np.nanmin(Y,axis=0); hi=np.nanmax(Y,axis=0)
    Yn=(Y-lo)/np.maximum(hi-lo,EPS)
    w=np.ones(Y.shape[1])/Y.shape[1] if weights is None else as1d(weights)/np.sum(weights)
    return Yn@w

# Source 5x5 control retrieval table, linguistic indices [-2,-1,0,1,2] for E and EC.
SOURCE_CONTROL_TABLE=np.array([[2,2,1,1,0],[2,1,1,0,-1],[1,1,0,-1,-1],[1,0,-1,-1,-2],[0,-1,-1,-2,-2]],float)
SOURCE_RECURSION_ERROR={1:-10.0,2:12.5,3:-4.4,4:1.25,5:-0.16,6:-0.16,7:-0.16,8:0.02,9:-0.06,10:-0.02}
SOURCE_STEP={'PID':{'overshoot_percent':52.3,'steady_state_error':0.0,'transition_time_s':22.34,'error_variance':22.8},'GenericFuzzy':{'overshoot_percent':60.1,'steady_state_error':float('nan'),'transition_time_s':float('nan'),'error_variance':22.2},'RecursiveFuzzy':{'overshoot_percent':27.0,'steady_state_error':0.03,'transition_time_s':23.0,'error_variance':15.6}}
SOURCE_TRACKING_VARIANCE={'PID':0.71995,'GenericFuzzy':2.7748,'RecursiveFuzzy':0.49973}
SOURCE_DISTURBANCE_VARIANCE={'PID':30.0035,'GenericFuzzy':33.3794,'RecursiveFuzzy':27.5194}

def initial_factor_gain_selection(e_range,de_range,u_universe=(-2,2),actuator_limits=(0,100),deadzone=0.5):
    emax=max(abs(e_range[0]),abs(e_range[1]),EPS); demax=max(abs(de_range[0]),abs(de_range[1]),EPS)
    Ke=2.0/emax; Kde=2.0/demax; umax=max(abs(u_universe[0]),abs(u_universe[1]),EPS); Ku=(actuator_limits[1]-actuator_limits[0])/(2*umax)
    return {'Ke':Ke,'Kde':Kde,'Ku':Ku,'deadzone':deadzone}

def table_lookup(E,DE,table=SOURCE_CONTROL_TABLE):
    # nearest linguistic index in {-2,-1,0,1,2}; rows=EC, cols=E as in source retrieval table.
    ei=int(np.clip(np.rint(E),-2,2))+2; di=int(np.clip(np.rint(DE),-2,2))+2
    return float(np.asarray(table,float)[di,ei]),(di,ei)

def recursive_factor_inference(E,DE,table=SOURCE_CONTROL_TABLE,R=5,lam=2.0,deadzone=0.5):
    residual=float(E); total=0.0; scale=1.0; trace=[]
    for j in range(1,R+1):
        q,idx=table_lookup(residual*scale,DE*scale,table); du=q/scale; total+=du
        residual-=du
        trace.append({'depth':j,'q':q,'du':du,'residual':residual,'index':idx})
        if abs(residual)<deadzone: break
        scale*=lam
    return total,trace

def online_furnace_control(setpoints,measurements,Ke,Kde,Ku,R=5,table=SOURCE_CONTROL_TABLE,u0=0,limits=(0,100),deadzone=0.5):
    r=as1d(setpoints); y=as1d(measurements); eprev=0.0; u=float(u0); log=[]
    for k,(sp,pv) in enumerate(zip(r,y)):
        e=float(sp-pv); de=e-eprev; E=Ke*e; DE=Kde*de; dun,rt=recursive_factor_inference(E,DE,table,R,deadzone=deadzone)
        u=float(np.clip(u+Ku*dun,*limits)); log.append({'k':k,'setpoint':sp,'temperature':pv,'e':e,'de':de,'u':u,'depth':len(rt),'trace':rt}); eprev=e
    return log

def source_performance_audit():
    step=SOURCE_STEP; out={'step':step,'tracking_variance':SOURCE_TRACKING_VARIANCE,'disturbance_variance':SOURCE_DISTURBANCE_VARIANCE,'recursion_error':SOURCE_RECURSION_ERROR,'descriptive_only':True}
    out['recursive_vs_pid_overshoot_reduction_percent']=100*(step['PID']['overshoot_percent']-step['RecursiveFuzzy']['overshoot_percent'])/step['PID']['overshoot_percent']
    return out

def recursive_fuzzy_control_cycle(setpoint_fn,measure_fn,apply_fn,steps,Ke,Kde,Ku,Rmax=5,table=SOURCE_CONTROL_TABLE,u0=0,limits=(0,100),deadzone=0.5,eps=1e-3,lam=2.0):
    eprev=0.0; u=float(u0); log=[]
    for k in range(steps):
        sp=float(setpoint_fn(k)); y=float(measure_fn(k))
        if not np.isfinite(y): apply_fn(u); log.append({'k':k,'fault':'invalid_sensor','u':u}); continue
        e=sp-y; de=e-eprev; dun,rt=recursive_factor_inference(Ke*e,Kde*de,table,Rmax,lam,deadzone)
        ustar=u+Ku*dun; unew=float(np.clip(ustar,*limits)); apply_fn(unew); u=unew
        log.append({'k':k,'sp':sp,'y':y,'e':e,'de':de,'u':u,'saturated':u!=ustar,'depth':len(rt)}); eprev=e
    return log

def recursive_fuzzy_refinement(e,de,table=SOURCE_CONTROL_TABLE,R=5,Ke=1,Kde=1,Ku=1,lam=2,epsilon=0.5):
    du,tr=recursive_factor_inference(Ke*e,Kde*de,table,R,lam,epsilon); return Ku*du,len(tr),tr

def online_furnace_cycle(*args,**kwargs): return recursive_fuzzy_control_cycle(*args,**kwargs)

def recursion_depth_selection(results=None,epsilon=0.1,K=2,Rmax=10):
    results=SOURCE_RECURSION_ERROR if results is None else results
    consecutive=0; chosen=Rmax
    prev=None
    for R in range(1,Rmax+1):
        err=abs(float(results[R]))
        if prev is not None and abs(prev-err)<epsilon: consecutive+=1
        else: consecutive=0
        if consecutive>=K: chosen=R-K+1; break
        prev=err
    return {'chosen_depth':chosen,'errors':dict(results)}

def reanalysis_visualization(D0=None,target=None,predictions=None): return {'source_hash':source_hash(D0 if D0 is not None else source_performance_audit()),'descriptive_only':True}
