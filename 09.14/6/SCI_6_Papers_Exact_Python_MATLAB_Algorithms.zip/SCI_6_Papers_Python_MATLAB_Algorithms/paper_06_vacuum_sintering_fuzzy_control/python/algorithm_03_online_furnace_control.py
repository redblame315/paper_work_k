"""Recursive-Factor Fuzzy Control for Vacuum Sintering
03: Online vacuum-furnace temperature control
Dedicated wrapper around the verified V4 implementation in paper_core.py.
"""
from paper_core import online_furnace_control

__all__ = ["online_furnace_control"]
