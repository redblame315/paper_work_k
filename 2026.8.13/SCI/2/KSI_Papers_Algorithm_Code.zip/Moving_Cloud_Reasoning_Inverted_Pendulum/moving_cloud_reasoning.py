#!/usr/bin/env python3
"""
Supplementary Material S1/S3 - Reference implementation of the paper
"New Moving Cloud Reasoning Method based on KSI principle and Stabilization
Control of the Inverted Pendulum".

S1: the m-input single-output moving cloud reasoning method (Algorithm 1,
    Section 3.1) - entropy obtained by the moving (arithmetic-average)
    principle, without any derivative or integral computation.
S3: closed-loop stabilization of the single inverted pendulum by the moving
    cloud reasoning controller (Algorithm 2, Section 4.2).

Requirements: numpy, scipy (pip install numpy scipy)
"""
import numpy as np
from dataclasses import dataclass

RNG = np.random.default_rng(1)

# ----------------------------------------------------------------------------
# S1  Moving cloud reasoning (Algorithm 1)
# ----------------------------------------------------------------------------

@dataclass
class Cloud:
    """Membership cloud with the three numerical characteristics."""
    Ex: float   # expected value
    En: float   # entropy
    He: float   # hyper entropy


def expected_curve(c: Cloud):
    """Step 1: expected curve mu(x) of a normal membership cloud, expr. (2)-(3)."""
    return lambda x: np.exp(-(x - c.Ex) ** 2 / (2.0 * max(c.En, 1e-12) ** 2))


def entropy_by_moving(c: Cloud, K: int = 1000) -> float:
    """Steps 2-3: entropy from average left/right moving distances of cloud
    drops around the expected value - arithmetic averages and sign functions
    only (expr. (4)-(14)); no derivative or integral computation is used.

    For drops x_k of a normal cloud, mean(|x_k - Ex|) = En * sqrt(2/pi),
    so En = mean(moving distance) * sqrt(pi/2)."""
    En_k = RNG.normal(c.En, c.He, K)          # randomized entropy (hyper entropy)
    x_k = RNG.normal(c.Ex, np.abs(En_k))      # cloud drops
    sign = np.sign(x_k - c.Ex)                # left/right decision term, expr. (8)
    dL_left = np.abs(x_k[sign < 0] - c.Ex)    # left moving distances
    dL_right = np.abs(x_k[sign >= 0] - c.Ex)  # right moving distances
    M_l = dL_left.mean() if dL_left.size else 0.0    # left width
    M_r = dL_right.mean() if dL_right.size else 0.0  # right width
    return 0.5 * (M_l + M_r) * np.sqrt(np.pi / 2.0)


def cloudify(x0: float, A: Cloud) -> Cloud:
    """Step 4: premise cloud A' for the crisp input x0, expr. (20)-(26)."""
    return Cloud(Ex=x0, En=A.En, He=A.He)


def normal_random_numbers(En: float, He: float, K: int) -> np.ndarray:
    """Step 5: normal random numbers NRN, expr. (29)."""
    return RNG.normal(En, He, K)


def cloud_moving_function(ExAp: float, ExA: float, NRN: np.ndarray) -> float:
    """Step 5: cloud moving function CMF, expr. (30): movement of the
    cloudified input with respect to the premise cloud."""
    return (ExAp - ExA) * (1.0 + NRN.mean() - NRN.mean())  # movement of Ex


def certainty_degree(x0: float, A: Cloud, K: int = 200) -> float:
    """Rule activation from the expected curve of A with randomized entropy."""
    En_k = np.abs(RNG.normal(A.En, A.He, K))
    mu_k = np.exp(-(x0 - A.Ex) ** 2 / (2.0 * En_k ** 2))
    return float(mu_k.mean())


def moving_cloud_reasoning(x0, premises, B, K=1000):
    """Algorithm 1 (Steps 1-7) for one rule 'if x1 is A1, ..., xm is Am
    then y is B'. Returns the de-cloudified output y' and the cloud B'."""
    m = len(premises)
    # Steps 2-3: entropies by the moving principle
    En_A = [entropy_by_moving(A, K) for A in premises]
    En_B = entropy_by_moving(B, K)
    # Step 4: cloudification of the inputs
    Ap = [cloudify(x0[j], premises[j]) for j in range(m)]
    # Step 5: normal random numbers and cloud moving functions
    NRN = [normal_random_numbers(En_A[j], premises[j].He, K) for j in range(m)]
    CMF = [cloud_moving_function(Ap[j].Ex, premises[j].Ex, NRN[j]) for j in range(m)]
    # Step 6: cloud moving actions -> arithmetic average -> moved cloud B'
    CMA = [CMF[j] * (En_B / max(En_A[j], 1e-12)) for j in range(m)]
    ACM = float(np.mean(CMA))
    Bp = Cloud(Ex=B.Ex + ACM, En=En_B, He=B.He)
    # Step 7: de-cloudification, expr. (42)
    y = Bp.Ex
    return y, Bp


# ----------------------------------------------------------------------------
# S3  Stabilization control of the single inverted pendulum (Algorithm 2)
# ----------------------------------------------------------------------------

# plant parameters (single inverted pendulum, Section 4.2)
M1 = 1.0     # cart mass m1 [kg]
M2 = 0.1     # pendulum mass m2 [kg]
L = 0.5      # pendulum half length l [m]
G = 9.8      # gravity [m/s^2]


def pendulum_dynamics(x, f):
    """Nonlinear model of the single inverted pendulum, expr. (45).
    State x = [r, dr, th, dth]; f: force on the cart."""
    r, dr, th, dth = x
    s, c = np.sin(th), np.cos(th)
    den = M1 + M2 * s ** 2
    ddr = (f + M2 * s * (L * dth ** 2 - G * c)) / den
    ddth = (-f * c - M2 * L * dth ** 2 * s * c + (M1 + M2) * G * s) / (L * den)
    return np.array([dr, ddr, dth, ddth])


def linearize(th_op: float):
    """Coefficient matrices (A_i, B_i) of rules R1-R3 by linearizing the
    nonlinear model in the neighborhood of the operating angle th_op."""
    s, c = np.sin(th_op), np.cos(th_op)
    den = M1 + M2 * s ** 2
    A = np.array([
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, -M2 * G * c / den, 0.0],
        [0.0, 0.0, 0.0, 1.0],
        [0.0, 0.0, (M1 + M2) * G * c / (L * den), 0.0]])
    B = np.array([[0.0], [1.0 / den], [0.0], [-c / (L * den)]])
    return A, B


def state_feedback_gain(A, B, Q, R):
    """Stabilizing gain K_i of each control rule from P > 0, Q > 0
    (solution of the continuous algebraic Riccati equation)."""
    from scipy.linalg import solve_continuous_are
    P = solve_continuous_are(A, B, Q, R)
    return np.linalg.solve(R, B.T @ P)


def rk4_step(x, f, dt):
    k1 = pendulum_dynamics(x, f)
    k2 = pendulum_dynamics(x + 0.5 * dt * k1, f)
    k3 = pendulum_dynamics(x + 0.5 * dt * k2, f)
    k4 = pendulum_dynamics(x + dt * k3, f)
    return x + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)


def simulate(th0=0.30, r0=0.0, He=0.12, T=8.0, dt=0.01, K_drops=200):
    """Closed-loop simulation of Algorithm 2."""
    TH0 = np.pi / 6.0
    # premise membership clouds of theta (Fig. 3): N, Z, P
    En = TH0 / 3.0
    clouds = [Cloud(-TH0, En, He), Cloud(0.0, En, He), Cloud(+TH0, En, He)]
    # rules R1-R3 and gains of control rules L1-L3
    Q = np.diag([10.0, 1.0, 100.0, 1.0]); R = np.array([[1.0]])
    gains = []
    for th_op in (-TH0, 0.0, +TH0):
        A, B = linearize(th_op)
        gains.append(state_feedback_gain(A, B, Q, R))
    x = np.array([r0, 0.0, th0, 0.0])
    hist = []
    for k in range(int(T / dt)):
        th = x[2]
        # rule activations by moving cloud reasoning on the premise variable
        w = np.array([certainty_degree(th, c, K_drops) for c in clouds])
        w = np.maximum(w, 1e-9); w = w / w.sum()
        f = float(sum(w[i] * (-gains[i] @ x)[0] for i in range(3)))
        x = rk4_step(x, f, dt)
        hist.append([k * dt, *x, f])
    return np.array(hist)


def peak_and_settling(t, y, abs_band):
    """Peak excursion and settling time of a response y(t): the settling time
    is the last instant at which |y| leaves the absolute band abs_band."""
    peak = float(np.max(np.abs(y)))
    idx = np.where(np.abs(y) > abs_band)[0]
    tr = float(t[idx[-1]]) if idx.size else 0.0
    return peak, tr


if __name__ == "__main__":
    # demonstration corresponding to Figures 4-9 of the paper
    for He in (0.04, 0.12, 0.20, 0.40):
        h = simulate(th0=0.30, He=He)
        t, r, th = h[:, 0], h[:, 1], h[:, 3]
        pk_r, tr_r = peak_and_settling(t, r, 0.01)   # cart: 1 cm band
        pk_t, tr_t = peak_and_settling(t, th, 0.01)  # pendulum: 0.01 rad band
        print(f"He={He:4.2f} | cart: peak={pk_r:5.3f} m  Tr={tr_r:5.2f} s"
              f" | pendulum: peak={pk_t:5.3f} rad Tr={tr_t:5.2f} s"
              f" | final |theta|={abs(th[-1]):.4f} rad")
