%% Supplementary Material S2/S4 - MATLAB reference implementation of
%% "New Moving Cloud Reasoning Method based on KSI principle and
%%  Stabilization Control of the Inverted Pendulum".
%%
%% S2: m-input single-output moving cloud reasoning (Algorithm 1, Sec. 3.1)
%% S4: closed-loop stabilization of the single inverted pendulum by the
%%     moving cloud reasoning controller (Algorithm 2, Sec. 4.2)
%%
%% Self-contained: no toolboxes required (the Riccati equation is solved by
%% the Hamiltonian eigenvector method). Run:  moving_cloud_reasoning

function moving_cloud_reasoning()
    rng(1);                                  % reproducible random numbers
    for He = [0.04 0.12 0.20 0.40]
        h = simulate_pendulum(0.30, 0.0, He, 8.0, 0.01, 200);
        t = h(:,1); r = h(:,2); th = h(:,4);
        [pk_r, tr_r] = peak_and_settling(t, r, 0.01);
        [pk_t, tr_t] = peak_and_settling(t, th, 0.01);
        fprintf(['He=%4.2f | cart: peak=%5.3f m  Tr=%5.2f s | ' ...
                 'pendulum: peak=%5.3f rad Tr=%5.2f s | final |theta|=%.4f rad\n'], ...
                 He, pk_r, tr_r, pk_t, tr_t, abs(th(end)));
    end
end

%% ------------------------- S2: Algorithm 1 ------------------------------

function En = entropy_by_moving(Ex, En0, He, K)
    % Steps 2-3: entropy from average left/right moving distances of cloud
    % drops (arithmetic averages and sign functions only; expr. (4)-(14)).
    En_k = En0 + He .* randn(K, 1);          % randomized entropy
    x_k  = Ex + abs(En_k) .* randn(K, 1);    % cloud drops
    s    = sign(x_k - Ex);                   % left/right decision, expr. (8)
    dLl  = abs(x_k(s < 0) - Ex);             % left moving distances
    dLr  = abs(x_k(s >= 0) - Ex);            % right moving distances
    Ml = 0; Mr = 0;
    if ~isempty(dLl), Ml = mean(dLl); end
    if ~isempty(dLr), Mr = mean(dLr); end
    En = 0.5 * (Ml + Mr) * sqrt(pi / 2);
end

function [y, ExBp, EnBp] = moving_cloud_reasoning_rule(x0, ExA, EnA, HeA, ExB, EnB, HeB, K)
    % Algorithm 1 (Steps 1-7) for the rule
    % 'if x1 is A1, ..., xm is Am then y is B'.
    m = numel(x0);
    EnAm = zeros(1, m);
    for j = 1:m                                    % Steps 2-3
        EnAm(j) = entropy_by_moving(ExA(j), EnA(j), HeA(j), K);
    end
    EnBp = entropy_by_moving(ExB, EnB, HeB, K);
    CMA = zeros(1, m);
    for j = 1:m
        ExAp = x0(j);                              % Step 4: cloudification
        CMF  = ExAp - ExA(j);                      % Step 5: moving function
        CMA(j) = CMF * (EnBp / max(EnAm(j), 1e-12)); % Step 6: moving action
    end
    ACM  = mean(CMA);                              % arithmetic average
    ExBp = ExB + ACM;                              % moved conclusion cloud B'
    y    = ExBp;                                   % Step 7: de-cloudification
end

function mu = certainty_degree(x0, Ex, En, He, K)
    % rule activation from the expected curve with randomized entropy
    En_k = abs(En + He .* randn(K, 1));
    mu = mean(exp(-(x0 - Ex).^2 ./ (2 .* En_k.^2)));
end

%% ------------------------- S4: Algorithm 2 ------------------------------

function dx = pendulum_dynamics(x, f)
    % Nonlinear model of the single inverted pendulum, expr. (45).
    m1 = 1.0; m2 = 0.1; l = 0.5; g = 9.8;
    th = x(3); dth = x(4);
    s = sin(th); c = cos(th);
    den  = m1 + m2 * s^2;
    ddr  = (f + m2 * s * (l * dth^2 - g * c)) / den;
    ddth = (-f * c - m2 * l * dth^2 * s * c + (m1 + m2) * g * s) / (l * den);
    dx = [x(2); ddr; dth; ddth];
end

function [A, B] = linearize_pendulum(th_op)
    % Coefficient matrices (A_i, B_i) of rules R1-R3.
    m1 = 1.0; m2 = 0.1; l = 0.5; g = 9.8;
    s = sin(th_op); c = cos(th_op);
    den = m1 + m2 * s^2;
    A = [0 1 0 0;
         0 0 -m2*g*c/den 0;
         0 0 0 1;
         0 0 (m1+m2)*g*c/(l*den) 0];
    B = [0; 1/den; 0; -c/(l*den)];
end

function K = state_feedback_gain(A, B, Q, R)
    % Gains K_i from P > 0, Q > 0 via the continuous algebraic Riccati
    % equation, solved by the Hamiltonian eigenvector method (toolbox-free).
    n = size(A, 1);
    H = [A, -B*(R\B'); -Q, -A'];
    [V, D] = eig(H);
    idx = find(real(diag(D)) < 0);
    X1 = V(1:n, idx); X2 = V(n+1:2*n, idx);
    P = real(X2 / X1);
    K = R \ (B' * P);
end

function x1 = rk4_step(x, f, dt)
    k1 = pendulum_dynamics(x, f);
    k2 = pendulum_dynamics(x + 0.5*dt*k1, f);
    k3 = pendulum_dynamics(x + 0.5*dt*k2, f);
    k4 = pendulum_dynamics(x + dt*k3, f);
    x1 = x + dt/6 * (k1 + 2*k2 + 2*k3 + k4);
end

function hist = simulate_pendulum(th0, r0, He, T, dt, Kdrops)
    TH0 = pi/6; En = TH0/3;
    ExC = [-TH0, 0.0, +TH0];                  % clouds N, Z, P (Fig. 3)
    Q = diag([10 1 100 1]); R = 1;
    K = zeros(3, 4);
    ops = [-TH0, 0.0, +TH0];
    for i = 1:3
        [A, B] = linearize_pendulum(ops(i));
        K(i, :) = state_feedback_gain(A, B, Q, R);
    end
    x = [r0; 0; th0; 0];
    N = round(T/dt); hist = zeros(N, 6);
    for k = 1:N
        th = x(3);
        w = zeros(1, 3);
        for i = 1:3
            w(i) = certainty_degree(th, ExC(i), En, He, Kdrops);
        end
        w = max(w, 1e-9); w = w / sum(w);
        f = 0;
        for i = 1:3, f = f - w(i) * (K(i, :) * x); end
        x = rk4_step(x, f, dt);
        hist(k, :) = [k*dt, x', f];
    end
end

function [peak, tr] = peak_and_settling(t, y, band)
    peak = max(abs(y));
    idx = find(abs(y) > band);
    if isempty(idx), tr = 0; else, tr = t(idx(end)); end
end
