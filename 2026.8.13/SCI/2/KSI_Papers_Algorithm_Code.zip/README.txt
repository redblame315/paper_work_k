Algorithm code for the two KSI-principle papers
================================================

Moving_Cloud_Reasoning_Inverted_Pendulum/
  moving_cloud_reasoning.py  - Algorithm 1 (seven-step moving cloud reasoning, Sec. 3.1)
                               + Algorithm 2 (pendulum stabilization controller, Sec. 4.2).
                               Run:  python moving_cloud_reasoning.py   (needs numpy, scipy)
  moving_cloud_reasoning.m   - Same algorithms in MATLAB, toolbox-free.
                               Run:  moving_cloud_reasoning

Temperature_Prediction_KSI/
  ksi_ts_modeling.py         - Algorithm 1 (moving-rate T-S modeling: moving rates (1)-(3),
                               activations (4)-(5), corrected recursive LS (12)-(14))
                               + Algorithm 2 (Stage 1-3 workflow, Sec. 4) on a synthetic demo.
                               Run:  python ksi_ts_modeling.py   (needs numpy)
  ksi_ts_modeling.m          - Same algorithms in MATLAB, toolbox-free.
                               Run:  ksi_ts_modeling

The listings are identical to Sections S1-S4 of each paper's Supplementary Materials.
