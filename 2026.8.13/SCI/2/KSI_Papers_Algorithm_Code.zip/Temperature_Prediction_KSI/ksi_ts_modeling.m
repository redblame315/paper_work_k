%% Supplementary Material S2/S4 - MATLAB reference implementation of
%% "Real-Time Temperature Prediction Technique of Aluminium Electrolysis
%%  Furnace Based on the KSI Principle".
%%
%% S2: moving-rate fuzzy T-S modeling (Algorithm 1, Section 3/3.1):
%%     moving rates (1)-(3), rule activations (4)-(5), recursive matrix
%%     (7)/(11)/(15), corrected recursive least squares (12)-(14).
%% S4: stagewise workflow (Algorithm 2, Section 4) demonstrated on a
%%     synthetic furnace-like data set.
%%
%% Self-contained (no toolboxes). Run:  ksi_ts_modeling

function ksi_ts_modeling()
    rng(7);
    % ---------------- Stage 1: database construction ----------------
    N = 2500;
    [T, U, I] = synthetic_furnace(N);
    X = [T(1:end-1)', U(2:end)', I(2:end)'];   % regressor x0(k)
    Y = T(2:end)';                             % target T(k+1)
    n_train = 2000;
    % ---------------- Stage 2: model construction -------------------
    MFs = build_membership_functions(945, 965, 5);
    n = numel(MFs); m = size(X, 2);
    dim = n * (m + 1);
    theta = zeros(dim, 1);
    S = eye(dim) * 1e4;                        % S_0 = alpha * E
    for k = 1:n_train
        w = rule_activations(X(k, :), MFs);            % formulas (1)-(5)
        H = data_vector(w, X(k, :));                   % formulas (11), (15)
        [theta, S] = recursive_ls(theta, S, H, Y(k));  % corrected (12)-(14)
    end
    % ---------------- Stage 3: verification --------------------------
    idx = (n_train + 1):(N - 1);
    e = zeros(numel(idx), 1);
    for q = 1:numel(idx)
        k = idx(q);
        e(q) = ts_output(X(k, :), MFs, theta) - Y(k);
    end
    dev = abs(e);
    mape = mean(dev ./ abs(Y(idx))) * 100;
    fprintf('rules: %d | parameters: %d\n', n, dim);
    fprintf('max deviation : %7.3f degC\n', max(dev));
    fprintf('min deviation : %7.3f degC\n', min(dev));
    fprintf('mean deviation: %7.3f degC\n', mean(dev));
    fprintf('model accuracy: %7.3f %%\n', 100 - mape);
end

%% ---------------------- S2: Algorithm 1 ---------------------------------

function d = moving_rate(x0, mf)
    % Moving rate d_ij of one membership function, formulas (1)-(3).
    switch mf.kind
        case 's'                                % formula (1)
            if x0 < mf.a, d = 1;
            elseif x0 >= mf.c, d = 0;
            else, d = (mf.c - x0) / (mf.c - mf.a); end
        case 'z'                                % formula (2)
            if x0 <= mf.a, d = 0;
            elseif x0 > mf.c, d = 1;
            else, d = (x0 - mf.a) / (mf.c - mf.a); end
        otherwise                               % trapezoidal, formula (3)
            if x0 < mf.x1 || x0 >= mf.x4, d = 1;
            elseif x0 <= mf.x2, d = (mf.x2 - x0) / (mf.x2 - mf.x1);
            elseif x0 <= mf.x3, d = 0;
            else, d = (x0 - mf.x3) / (mf.x4 - mf.x3); end
    end
end

function w = rule_activations(x0, MFs)
    % Stages 2-3: d_i = 1 - min_j d_ij, then normalization; (4)-(5).
    n = numel(MFs);
    d = zeros(1, n);
    for i = 1:n
        dmin = 1;
        for j = 1:numel(x0)
            dmin = min(dmin, moving_rate(x0(j), MFs{i}{j}));
        end
        d(i) = 1 - dmin;
    end
    s = sum(d);
    if s <= 1e-12, w = ones(1, n) / n; else, w = d / s; end
end

function H = data_vector(w, x0)
    % Stage 4: row H_k of the recursive matrix Z; (7), (11), (15).
    n = numel(w); m = numel(x0);
    H = zeros(1, n * (m + 1)); p = 1;
    for i = 1:n
        H(p) = w(i); p = p + 1;
        for j = 1:m
            H(p) = w(i) * x0(j); p = p + 1;
        end
    end
end

function [theta, S] = recursive_ls(theta, S, H, y)
    % Corrected recursive estimation, formulas (12)-(14). H: row vector.
    F = (S * H') / (1 + H * S * H');           % formula (13)
    theta = theta + F * (y - H * theta);       % formula (12)
    S = S - F * H * S;                         % formula (14)
end

function y0 = ts_output(x0, MFs, theta)
    % Fuzzy model output, formula (6).
    w = rule_activations(x0, MFs);
    y0 = data_vector(w, x0) * theta;
end

%% ---------------------- S4: Algorithm 2 helpers -------------------------

function [T, U, I] = synthetic_furnace(N)
    % Synthetic bath-temperature dynamics driven by voltage and current.
    T = zeros(1, N); U = zeros(1, N); I = zeros(1, N);
    T(1) = 955; u = 4.10; i = 500;
    for k = 1:N
        u = min(max(u + 0.004 * randn, 3.90), 4.30);
        i = min(max(i + 0.8 * randn, 480), 520);
        U(k) = u; I(k) = i;
        if k < N
            drift = -(T(k) - 955) * 0.05;
            heat = 4.0 * (u - 4.10) * (i / 500) + 1.5 * tanh((i - 500) / 50);
            T(k + 1) = T(k) + drift + 0.05 * heat + 0.03 * randn;
        end
    end
end

function MFs = build_membership_functions(T_lo, T_hi, n_rules)
    % Stage 2: s-, trapezoidal, and z-type membership functions of the
    % temperature regressor (only breakpoints are needed).
    edges = linspace(T_lo, T_hi, n_rules + 1);
    MFs = cell(1, n_rules);
    for i = 1:n_rules
        lo = edges(i); hi = edges(i + 1); w = hi - lo;
        if i == 1
            mfT = struct('kind', 's', 'a', lo, 'c', hi + 0.5 * w);
        elseif i == n_rules
            mfT = struct('kind', 'z', 'a', lo - 0.5 * w, 'c', hi);
        else
            mfT = struct('kind', 'trap', 'x1', lo - 0.75 * w, 'x2', lo - 0.25 * w, ...
                         'x3', hi + 0.25 * w, 'x4', hi + 0.75 * w);
        end
        mfU = struct('kind', 'trap', 'x1', 3.80, 'x2', 3.85, 'x3', 4.35, 'x4', 4.40);
        mfI = struct('kind', 'trap', 'x1', 470, 'x2', 475, 'x3', 525, 'x4', 530);
        MFs{i} = {mfT, mfU, mfI};
    end
end
