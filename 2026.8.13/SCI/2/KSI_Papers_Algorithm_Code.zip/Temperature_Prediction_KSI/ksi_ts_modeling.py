#!/usr/bin/env python3
"""
Supplementary Material S1/S3 - Reference implementation of the paper
"Real-Time Temperature Prediction Technique of Aluminium Electrolysis
Furnace Based on the KSI Principle".

S1: moving-rate fuzzy T-S modeling (Algorithm 1, Section 3/3.1):
    moving rates (1)-(3), rule activations (4)-(5), recursive matrix
    (7)/(11)/(15), corrected recursive least squares (12)-(14).
S3: stagewise workflow (Algorithm 2, Section 4) demonstrated on a
    synthetic furnace-like data set (real potline data are proprietary).

Requirements: numpy (pip install numpy)
"""
import numpy as np
from dataclasses import dataclass

RNG = np.random.default_rng(7)

# ----------------------------------------------------------------------------
# S1  Moving-rate T-S modeling (Algorithm 1)
# ----------------------------------------------------------------------------

@dataclass
class MF:
    """Membership function described only by its breakpoints."""
    kind: str            # "s" | "z" | "trap"
    a: float = 0.0       # x_a (s/z type)
    c: float = 0.0       # x_c (s/z type)
    x1: float = 0.0      # trapezoid breakpoints x1 < x2 < x3 < x4
    x2: float = 0.0
    x3: float = 0.0
    x4: float = 0.0


def moving_rate(x0: float, mf: MF) -> float:
    """Moving rate d_ij of input x0 for one membership function,
    formulas (1)-(3) of the paper."""
    if mf.kind == "s":                       # formula (1)
        if x0 < mf.a:
            return 1.0
        if x0 >= mf.c:
            return 0.0
        return (mf.c - x0) / (mf.c - mf.a)
    if mf.kind == "z":                       # formula (2)
        if x0 <= mf.a:
            return 0.0
        if x0 > mf.c:
            return 1.0
        return (x0 - mf.a) / (mf.c - mf.a)
    # trapezoidal, formula (3)
    if x0 < mf.x1 or x0 >= mf.x4:
        return 1.0
    if mf.x1 <= x0 <= mf.x2:
        return (mf.x2 - x0) / (mf.x2 - mf.x1)
    if mf.x2 <= x0 <= mf.x3:
        return 0.0
    return (x0 - mf.x3) / (mf.x4 - mf.x3)


def rule_activations(x0, MFs) -> np.ndarray:
    """Stages 2-3: product terms d_i = 1 - min_j d_ij and the normalized
    rates, formulas (4)-(5)."""
    n = len(MFs)
    d = np.empty(n)
    for i in range(n):
        d[i] = 1.0 - min(moving_rate(x0[j], MFs[i][j]) for j in range(len(x0)))
    s = d.sum()
    if s <= 1e-12:
        return np.full(n, 1.0 / n)
    return d / s


def data_vector(w, x0) -> np.ndarray:
    """Stage 4: row H_k of the recursive matrix Z, formulas (7), (11), (15):
    z_0^i = w_i, z_j^i = w_i * x_j."""
    H = []
    for i in range(len(w)):
        H.append(w[i])
        H.extend(w[i] * x for x in x0)
    return np.array(H)


def recursive_ls(theta, S, H, y):
    """Corrected recursive estimation, formulas (12)-(14). H: row vector."""
    H = H.reshape(1, -1)
    denom = 1.0 + float((H @ S @ H.T).item())
    F = (S @ H.T) / denom                    # formula (13)
    theta = theta + F.ravel() * (y - float((H @ theta).item()))  # formula (12)
    S = S - F @ H @ S                        # formula (14)
    return theta, S


def ts_output(x0, MFs, theta) -> float:
    """Fuzzy model output y0, formula (6)."""
    w = rule_activations(x0, MFs)
    return float(data_vector(w, x0) @ theta)


# ----------------------------------------------------------------------------
# S3  Stagewise workflow (Algorithm 2) on a synthetic furnace-like data set
# ----------------------------------------------------------------------------

def synthetic_furnace(N: int):
    """Synthetic bath-temperature dynamics driven by voltage and current
    (used only to demonstrate the identification workflow; real potline
    records are proprietary)."""
    T = np.empty(N); U = np.empty(N); I = np.empty(N)
    T[0], u, i = 955.0, 4.10, 500.0
    for k in range(N):
        u = np.clip(u + 0.004 * RNG.standard_normal(), 3.90, 4.30)
        i = np.clip(i + 0.8 * RNG.standard_normal(), 480.0, 520.0)
        U[k], I[k] = u, i
        if k + 1 < N:
            drift = -(T[k] - 955.0) * 0.05
            heat = 4.0 * (u - 4.10) * (i / 500.0) + 1.5 * np.tanh((i - 500.0) / 50.0)
            T[k + 1] = T[k] + drift + 0.05 * heat + 0.03 * RNG.standard_normal()
    return T, U, I


def build_membership_functions(T_lo=945.0, T_hi=965.0, n_rules=5):
    """Stage 2: fix s-, trapezoidal, and z-type membership functions of the
    temperature regressor on its operating range (only breakpoints needed)."""
    edges = np.linspace(T_lo, T_hi, n_rules + 1)
    MFs = []
    for i in range(n_rules):
        lo, hi = edges[i], edges[i + 1]
        w = hi - lo
        if i == 0:
            mf_T = MF("s", a=lo, c=hi + 0.5 * w)
        elif i == n_rules - 1:
            mf_T = MF("z", a=lo - 0.5 * w, c=hi)
        else:
            mf_T = MF("trap", x1=lo - 0.75 * w, x2=lo - 0.25 * w,
                      x3=hi + 0.25 * w, x4=hi + 0.75 * w)
        # voltage and current: whole-range trapezoids (always active)
        mf_U = MF("trap", x1=3.80, x2=3.85, x3=4.35, x4=4.40)
        mf_I = MF("trap", x1=470.0, x2=475.0, x3=525.0, x4=530.0)
        MFs.append([mf_T, mf_U, mf_I])
    return MFs


def main():
    # ---------------- Stage 1: database construction ----------------
    N = 2500
    T, U, I = synthetic_furnace(N)
    X = np.column_stack([T[:-1], U[1:], I[1:]])   # regressor x0(k)
    Y = T[1:]                                     # target T(k+1)
    n_train = 2000
    # ---------------- Stage 2: model construction -------------------
    MFs = build_membership_functions()
    n, m = len(MFs), X.shape[1]
    dim = n * (m + 1)
    theta = np.zeros(dim)
    S = np.eye(dim) * 1e4                          # S_0 = alpha * E
    for k in range(n_train):
        w = rule_activations(X[k], MFs)            # formulas (1)-(5)
        H = data_vector(w, X[k])                   # formulas (11), (15)
        theta, S = recursive_ls(theta, S, H, Y[k]) # corrected (12)-(14)
    # ---------------- Stage 3: verification --------------------------
    e = np.array([ts_output(X[k], MFs, theta) - Y[k] for k in range(n_train, N - 1)])
    dev = np.abs(e)
    mape = float(np.mean(dev / np.abs(Y[n_train:])) * 100.0)
    print(f"rules: {n} | parameters: {dim}")
    print(f"max deviation : {dev.max():7.3f} degC")
    print(f"min deviation : {dev.min():7.3f} degC")
    print(f"mean deviation: {dev.mean():7.3f} degC")
    print(f"model accuracy: {100.0 - mape:7.3f} %")


if __name__ == "__main__":
    main()
