# T-SFSSO Python Algorithms

Runnable Python implementations of the four numbered algorithms in the manuscript
"A New Prediction Algorithm Based on the Takagi-Sugeno Fuzzy Model and an
Improved Shark Smell Optimization Technique and Its Application."

## Included

- Algorithm 1: recursive least-squares (RLS) identification.
- Algorithm 2: conventional shark smell optimization (SSO).
- Algorithm 3: improved fuzzy shark smell optimization (FSSO), including all
  four modifications in Equations (26)-(32).
- Algorithm 4: the full T-SFSSO regression and time-series prediction pipeline.
- All benchmark functions used in Tables 1 and 4.
- The cleaned Python reference listing from Appendix A.
- Reproducible examples and unit tests.

The implementation uses minimization throughout. This is equivalent to the
paper's maximization notation after setting `OF = -f`.

## Requirements

- Python 3.10 or later
- NumPy 1.24 or later

## Install

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
python -m pip install -e .
```

## Run the examples

```bash
python examples/benchmark_demo.py
python examples/compare_sso_fsso.py
python examples/time_series_demo.py
```

## Run the tests

```bash
python -m unittest discover -s tests -v
```

## Small FSSO example

```python
from tsfsso.benchmarks import weighted_sum_f1
from tsfsso.optimizers import FSSOConfig, fsso

result = fsso(
    weighted_sum_f1,
    dimensions=30,
    lower=-5.0,
    upper=30.0,
    config=FSSOConfig(population_size=10, iterations=200),
    seed=7,
)
print(result.best_value)
```

## Small T-SFSSO time-series example

```python
import numpy as np
from tsfsso.forecasting import TSFSSORegressor, make_lagged_supervised
from tsfsso.optimizers import FSSOConfig

t = np.arange(160, dtype=float)
series = 20 + 0.08 * t + 3 * np.sin(t / 8)
X, y = make_lagged_supervised(series, lags=4)

model = TSFSSORegressor(
    n_rules=5,
    optimizer_config=FSSOConfig(population_size=8, iterations=30),
    seed=7,
)
model.fit(X, y)
prediction = model.predict(X)
```

## Reproducibility notes

The manuscript fully specifies Algorithms 1-4 and the benchmark functions, so
those are implemented here. It reports results for CSSO, NSSO, PSO, GA, DE,
FACS, and ISOA, but does not give enough update equations or hyperparameters to
reconstruct those external methods exactly. They are therefore not presented
as paper-faithful implementations. See `PAPER_ALGORITHM_MAP.md` for equation-to-code
traceability and implementation decisions.

