import unittest

import numpy as np

from tsfsso.benchmarks import matyas, matyas_gradient
from tsfsso.optimizers import FSSOConfig, SSOConfig, fsso, sso


class OptimizerTests(unittest.TestCase):
    def test_history_is_best_so_far(self):
        result = fsso(
            matyas,
            2,
            -10,
            10,
            config=FSSOConfig(population_size=6, iterations=20, rotations=3),
            gradient=matyas_gradient,
            seed=4,
        )
        self.assertTrue(np.all(np.diff(result.history) <= 1e-15))
        self.assertAlmostEqual(result.history[-1], result.best_value)
        self.assertLess(result.best_value, 0.05)

    def test_conventional_sso_runs(self):
        result = sso(
            matyas,
            2,
            -10,
            10,
            config=SSOConfig(population_size=4, iterations=5, rotations=2),
            gradient=matyas_gradient,
            seed=2,
        )
        self.assertEqual(result.history.size, 6)
        self.assertTrue(np.isfinite(result.best_value))


if __name__ == "__main__":
    unittest.main()

