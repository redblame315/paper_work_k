import unittest

import numpy as np

from tsfsso.benchmarks import (
    ackley,
    matyas,
    rastrigin,
    step,
    weighted_sum_f1,
    weighted_sum_f1_gradient,
    weighted_sum_f1_optimum,
    zakharov,
)
from tsfsso.gradients import central_difference


class BenchmarkTests(unittest.TestCase):
    def test_zero_minima(self):
        self.assertEqual(matyas(np.zeros(2)), 0.0)
        for function in (step, rastrigin, ackley, zakharov):
            self.assertAlmostEqual(function(np.zeros(5)), 0.0, places=12)

    def test_weighted_sum_closed_form(self):
        position, value = weighted_sum_f1_optimum(30)
        self.assertAlmostEqual(weighted_sum_f1(position), value, places=12)
        self.assertLess(value, -0.249)

    def test_numeric_gradient_matches_analytic(self):
        x = np.array([0.2, -0.4, 0.7])
        numeric = central_difference(weighted_sum_f1, x, -5.0, 30.0)
        np.testing.assert_allclose(numeric, weighted_sum_f1_gradient(x), rtol=1e-7, atol=1e-7)


if __name__ == "__main__":
    unittest.main()

