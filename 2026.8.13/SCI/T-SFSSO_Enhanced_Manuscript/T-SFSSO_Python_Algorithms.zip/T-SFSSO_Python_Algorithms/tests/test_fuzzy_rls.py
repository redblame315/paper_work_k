import unittest

import numpy as np

from tsfsso.fuzzy import TakagiSugenoModel, TriangularRuleBase
from tsfsso.rls import recursive_least_squares


class FuzzyAndRLSTests(unittest.TestCase):
    def test_normalized_strengths_sum_to_one(self):
        X = np.linspace(-2, 2, 25).reshape(-1, 1)
        rules = TriangularRuleBase.from_data(X, n_rules=5)
        weights = rules.normalized_strengths(X)
        np.testing.assert_allclose(weights.sum(axis=1), 1.0)
        self.assertTrue(np.all(weights >= 0))

    def test_rls_identifies_linear_one_rule_model(self):
        X = np.linspace(-1, 1, 80).reshape(-1, 1)
        y = 2.5 + 1.75 * X[:, 0]
        rules = TriangularRuleBase.from_data(X, n_rules=1)
        result = recursive_least_squares(rules.design_matrix(X), y, alpha=1e8)
        model = TakagiSugenoModel(rules, result.parameters.reshape(1, 2))
        np.testing.assert_allclose(model.predict(X), y, atol=2e-7)


if __name__ == "__main__":
    unittest.main()

