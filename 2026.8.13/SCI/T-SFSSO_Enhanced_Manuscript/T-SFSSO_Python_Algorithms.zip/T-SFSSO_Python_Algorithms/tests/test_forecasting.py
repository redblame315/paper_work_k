import unittest

import numpy as np

from tsfsso.forecasting import TSFSSORegressor, make_lagged_supervised
from tsfsso.optimizers import FSSOConfig


class ForecastingTests(unittest.TestCase):
    def test_lag_order(self):
        X, y = make_lagged_supervised(np.arange(8.0), lags=3)
        np.testing.assert_array_equal(X[0], [2.0, 1.0, 0.0])
        self.assertEqual(y[0], 3.0)

    def test_fsso_never_loses_rls_elite(self):
        t = np.arange(60.0)
        series = 10 + 0.2 * t + np.sin(t / 5)
        X, y = make_lagged_supervised(series, lags=2)
        model = TSFSSORegressor(
            n_rules=3,
            optimizer_config=FSSOConfig(population_size=3, iterations=3, rotations=1),
            seed=3,
        ).fit(X, y)
        summary = model.fit_summary_
        self.assertIsNotNone(summary)
        assert summary is not None
        self.assertLessEqual(summary.optimized_rmse, summary.rls_rmse + 1e-12)
        self.assertEqual(model.predict(X[:4]).shape, (4,))


if __name__ == "__main__":
    unittest.main()

