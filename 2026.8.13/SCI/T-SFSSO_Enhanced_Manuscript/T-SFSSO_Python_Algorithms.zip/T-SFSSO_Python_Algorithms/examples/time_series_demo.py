"""End-to-end synthetic time-series demonstration of Algorithm 4."""

import numpy as np

from tsfsso.forecasting import TSFSSORegressor, make_lagged_supervised
from tsfsso.metrics import mape, rmse, smape
from tsfsso.optimizers import FSSOConfig


def main() -> None:
    rng = np.random.default_rng(7)
    t = np.arange(220, dtype=float)
    series = 100 + 0.15 * t + 10 * np.sin(t / 10) + rng.normal(0, 0.8, t.size)
    X, y = make_lagged_supervised(series, lags=4)
    split = int(0.8 * y.size)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    predictor = TSFSSORegressor(
        n_rules=5,
        optimizer_config=FSSOConfig(population_size=5, iterations=25, rotations=3),
        coefficient_search_radius=1.0,
        seed=7,
    ).fit(X_train, y_train)
    prediction = predictor.predict(X_test)
    summary = predictor.fit_summary_
    assert summary is not None
    print(f"RLS training RMSE:   {summary.rls_rmse:.4f}")
    print(f"FSSO training RMSE:  {summary.optimized_rmse:.4f}")
    print(f"Test RMSE:           {rmse(y_test, prediction):.4f}")
    print(f"Test MAPE:           {mape(y_test, prediction):.3f}%")
    print(f"Test SMAPE:          {smape(y_test, prediction):.3f}%")


if __name__ == "__main__":
    main()

