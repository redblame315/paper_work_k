"""Run FSSO on every benchmark function defined in the manuscript."""

from tsfsso.benchmarks import (
    TABLE_1_BENCHMARKS,
    TABLE_4_BENCHMARKS,
    weighted_sum_f1_optimum,
)
from tsfsso.optimizers import FSSOConfig, fsso


def main() -> None:
    problems = [
        (TABLE_1_BENCHMARKS["weighted_sum_f1"], 30),
        (TABLE_1_BENCHMARKS["matyas"], 2),
        *[(problem, 30) for problem in TABLE_4_BENCHMARKS.values()],
    ]
    config = FSSOConfig(population_size=10, iterations=50, rotations=5)
    for index, (problem, dimensions) in enumerate(problems):
        result = fsso(
            problem.function,
            dimensions,
            problem.lower,
            problem.upper,
            config=config,
            gradient=problem.gradient,
            seed=7 + index,
        )
        print(
            f"{problem.name:16s} best={result.best_value: .8g} "
            f"evaluations={result.evaluations}"
        )

    _, analytic = weighted_sum_f1_optimum(30)
    print(f"Analytic weighted-sum minimum (n=30): {analytic:.9f}")


if __name__ == "__main__":
    main()

