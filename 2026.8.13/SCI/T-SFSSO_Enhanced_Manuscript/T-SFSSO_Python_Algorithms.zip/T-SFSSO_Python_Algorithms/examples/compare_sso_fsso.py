"""Deterministic side-by-side demonstration of Algorithms 2 and 3."""

from tsfsso.benchmarks import weighted_sum_f1, weighted_sum_f1_gradient
from tsfsso.optimizers import FSSOConfig, SSOConfig, fsso, sso


def main() -> None:
    common = dict(population_size=10, iterations=100, rotations=5)
    conventional = sso(
        weighted_sum_f1,
        30,
        -5.0,
        30.0,
        config=SSOConfig(**common),
        gradient=weighted_sum_f1_gradient,
        seed=7,
    )
    improved = fsso(
        weighted_sum_f1,
        30,
        -5.0,
        30.0,
        config=FSSOConfig(**common),
        gradient=weighted_sum_f1_gradient,
        seed=7,
    )
    print(f"SSO  best: {conventional.best_value:.9f}")
    print(f"FSSO best: {improved.best_value:.9f}")


if __name__ == "__main__":
    main()

