# Paper-to-code map

| Manuscript item | Equations | Python implementation |
| --- | --- | --- |
| Algorithm 1: RLS identification | (11)-(14) | `src/tsfsso/rls.py` |
| Dynamic T-S inference | (1)-(10) | `src/tsfsso/fuzzy.py` |
| Algorithm 2: conventional SSO | (15)-(25) | `tsfsso.optimizers.sso` |
| Algorithm 3: proposed FSSO | (26)-(32) | `tsfsso.optimizers.fsso` |
| T-S stability/bounded inference | (37)-(38) | normalized firing strengths and bounded partitions in `fuzzy.py` |
| Algorithm 4: T-SFSSO pipeline | (40)-(42) | `tsfsso.forecasting.TSFSSORegressor` |
| Table 1 benchmarks | (43) and Matyas definition | `src/tsfsso/benchmarks.py` |
| Table 4 benchmarks | Step, Rastrigin, Ackley, Zakharov | `src/tsfsso/benchmarks.py` |
| Appendix A listing | Appendix A | `appendix_a_reference.py` |

## Implementation decisions

1. Both optimizers expose a minimization API. Moving in `-grad(f)` is equivalent
   to maximizing the paper's `OF = -f`.
2. When an analytic gradient is not supplied, a bound-aware central difference
   implements the numerical-gradient assumption used in Equation (39).
3. Conventional SSO uses unit forward time, `gamma ~ U(0,1)`, and
   `R3 ~ U(0,1)`, matching Algorithm 2 and its surrounding discussion.
4. FSSO uses the adaptive probabilistic time interval, periodic near-zero-gradient
   jump, `gamma ~ U(0,2)`, and sign-reversing `R3 ~ U(-1.3,1.3)` exactly as
   specified in Equations (26)-(32).
5. The T-S model uses aligned triangular rules. `TriangularRuleBase.from_data`
   places rule centers at feature quantiles and constructs overlapping shoulder
   triangles, giving full data-range coverage without an exponential rule grid.
6. Algorithm 4 can refine consequent parameters only (default), or antecedent
   centers and consequent parameters together (`optimize_antecedents=True`).
   When antecedents are optimized, centers are sorted per feature before the
   triangular rule base is rebuilt, ensuring a valid ordered partition.
7. FSSO initialization accepts an elite RLS vector and samples the rest of the
   colony in its neighborhood, matching the manuscript's stated initialization
   around `theta_RLS`.

