"""Cleaned transcription of Appendix A from the supplied manuscript.

This file intentionally stays close to the compact paper listing. The package
under ``src/tsfsso`` adds validation, structured results, Algorithm 1, Algorithm
2, Algorithm 4, examples, and tests.
"""

from __future__ import annotations

import numpy as np


def f1_table1(x: np.ndarray) -> float:
    i = np.arange(1, x.size + 1, dtype=float)
    s = np.sum(0.5 * i * x)
    return float(np.sum(x * x) + s * s + s)


def f2_matyas(x: np.ndarray) -> float:
    return float(0.26 * (x[0] ** 2 + x[1] ** 2) - 0.48 * x[0] * x[1])


def F1_step(x: np.ndarray) -> float:
    return float(np.sum(np.floor(x + 0.5) ** 2))


def F2_rastrigin(x: np.ndarray) -> float:
    return float(np.sum(x * x - 10 * np.cos(2 * np.pi * x) + 10))


def F3_ackley(x: np.ndarray) -> float:
    n = x.size
    return float(
        -20 * np.exp(-0.2 * np.sqrt(np.sum(x * x) / n))
        - np.exp(np.sum(np.cos(2 * np.pi * x)) / n)
        + 20
        + np.e
    )


def F4_zakharov(x: np.ndarray) -> float:
    i = np.arange(1, x.size + 1, dtype=float)
    s = np.sum(0.5 * i * x)
    return float(np.sum(x * x) + s * s + s**4)


def central_gradient(f, x: np.ndarray, lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
    """Bound-aware central-difference gradient."""
    scale = np.maximum(1.0, np.abs(x))
    h = 1e-6 * scale
    grad = np.zeros_like(x, dtype=float)
    for j in range(x.size):
        xp = x.copy()
        xm = x.copy()
        xp[j] = min(hi[j], x[j] + h[j])
        xm[j] = max(lo[j], x[j] - h[j])
        width = xp[j] - xm[j]
        grad[j] = 0.0 if width == 0 else (f(xp) - f(xm)) / width
    return grad


def fsso(
    f,
    nd: int,
    lo,
    hi,
    *,
    NP: int = 10,
    M: int = 50,
    L: int = 5,
    mu: float = 0.9,
    alpha: float = 0.5,
    Cg: float = 1.0,
    Ct: float = 2.0,
    Q: float = 0.7,
    epsJ: float = 1e-6,
    Tjump: int = 10,
    seed: int | None = None,
):
    """Minimize ``f`` with the four FSSO improvements from Algorithm 3."""
    rng = np.random.default_rng(seed)
    lo = np.broadcast_to(np.asarray(lo, dtype=float), (nd,)).copy()
    hi = np.broadcast_to(np.asarray(hi, dtype=float), (nd,)).copy()
    if np.any(hi <= lo):
        raise ValueError("Every upper bound must exceed its lower bound.")

    X = lo + (hi - lo) * rng.random((NP, nd))
    V = 0.1 * (hi - lo) * (2 * rng.random((NP, nd)) - 1)
    vmax = 0.5 * (hi - lo)
    fx = np.array([f(x) for x in X], dtype=float)
    best_index = int(np.argmin(fx))
    best_x = X[best_index].copy()
    best_f = float(fx[best_index])
    history = np.empty(M + 1, dtype=float)
    history[0] = best_f

    for stage in range(1, M + 1):
        gamma = rng.uniform(0.0, 2.0)
        for p in range(NP):
            g = central_gradient(f, X[p], lo, hi)
            G = float(np.linalg.norm(g))
            trial_velocity = -mu * rng.random(nd) * g + alpha * rng.random(nd) * V[p]
            former = np.maximum(np.abs(V[p]), 1e-12)
            V[p] = np.sign(trial_velocity) * np.minimum(
                np.abs(trial_velocity), gamma * former
            )
            V[p] = np.clip(V[p], -vmax, vmax)

            if G < Cg or rng.random() < Q:
                dt = 1.0
            else:
                dt = (G / Cg) * Ct * rng.random()
            z = np.clip(X[p] + V[p] * dt, lo, hi)
            if stage % Tjump == 0 and G < epsJ:
                z = lo + (hi - lo) * rng.random(nd)

            candidates = [z]
            for _ in range(L):
                R3 = rng.uniform(-1.3, 1.3, size=nd)
                candidates.append(np.clip(z + R3 * z, lo, hi))
            candidate_values = np.array([f(c) for c in candidates], dtype=float)
            winner = int(np.argmin(candidate_values))
            if candidate_values[winner] <= fx[p]:
                X[p] = candidates[winner]
                fx[p] = candidate_values[winner]
            if fx[p] < best_f:
                best_f = float(fx[p])
                best_x = X[p].copy()
        history[stage] = best_f
    return best_x, best_f, history


if __name__ == "__main__":
    nd = 30
    xb, fb, hist = fsso(f1_table1, nd, -5.0, 30.0, M=200, seed=7)
    w = np.sum((0.5 * np.arange(1, nd + 1)) ** 2)
    print(f"FSSO best f1 = {fb:.6f}; analytic minimum = {-w / (4 * (w + 1)):.6f}")

    suite = [
        ("Step", F1_step, -100.0, 100.0),
        ("Rastrigin", F2_rastrigin, -5.12, 5.12),
        ("Ackley", F3_ackley, -32.0, 32.0),
        ("Zakharov", F4_zakharov, -100.0, 100.0),
    ]
    for name, function, lower, upper in suite:
        _, value, _ = fsso(function, nd, lower, upper, M=50, seed=1)
        print(f"FSSO on {name:10s}: best = {value:.4g}")

