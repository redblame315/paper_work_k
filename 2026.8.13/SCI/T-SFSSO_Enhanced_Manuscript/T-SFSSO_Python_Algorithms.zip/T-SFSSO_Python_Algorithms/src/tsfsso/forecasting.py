"""Complete T-SFSSO prediction procedure (Algorithm 4)."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .fuzzy import TakagiSugenoModel, TriangularRuleBase
from .metrics import rmse
from .optimizers import FSSOConfig, OptimizationResult, fsso
from .rls import RLSResult, recursive_least_squares

Array = np.ndarray


def make_lagged_supervised(
    series: Array, *, lags: int = 3, horizon: int = 1
) -> tuple[Array, Array]:
    """Build [y(k-1), ..., y(k-lags)] regressors for a forecast horizon."""
    values = np.asarray(series, dtype=float).reshape(-1)
    if lags < 1 or horizon < 1:
        raise ValueError("lags and horizon must be positive")
    samples = values.size - lags - horizon + 1
    if samples < 1:
        raise ValueError("series is too short for the requested lags and horizon")
    X = np.empty((samples, lags), dtype=float)
    y = np.empty(samples, dtype=float)
    for row, anchor in enumerate(range(lags, lags + samples)):
        X[row] = values[anchor - np.arange(1, lags + 1)]
        y[row] = values[anchor + horizon - 1]
    return X, y


@dataclass(frozen=True)
class TSFSSOFitSummary:
    rls_result: RLSResult
    optimization_result: OptimizationResult
    rls_rmse: float
    optimized_rmse: float


class TSFSSORegressor:
    """T-S model initialized by RLS and refined by FSSO.

    By default FSSO refines the consequent parameters. Set
    ``optimize_antecedents=True`` to jointly refine triangular centers and
    consequent parameters as described in Section 4.
    """

    def __init__(
        self,
        *,
        n_rules: int = 5,
        rls_alpha: float = 1e5,
        optimizer_config: FSSOConfig | None = None,
        coefficient_search_radius: float = 2.0,
        optimize_antecedents: bool = False,
        seed: int | None = None,
    ) -> None:
        if n_rules < 1 or rls_alpha <= 0 or coefficient_search_radius <= 0:
            raise ValueError("n_rules, rls_alpha, and search radius must be positive")
        self.n_rules = n_rules
        self.rls_alpha = rls_alpha
        self.optimizer_config = optimizer_config or FSSOConfig(
            population_size=5, iterations=50
        )
        self.coefficient_search_radius = coefficient_search_radius
        self.optimize_antecedents = optimize_antecedents
        self.seed = seed
        self.model_: TakagiSugenoModel | None = None
        self.fit_summary_: TSFSSOFitSummary | None = None

    def _decode(
        self,
        vector: Array,
        base_rule: TriangularRuleBase,
    ) -> TakagiSugenoModel:
        n_coefficients = self.n_rules * (base_rule.n_features + 1)
        coefficients = vector[-n_coefficients:].reshape(
            self.n_rules, base_rule.n_features + 1
        )
        if not self.optimize_antecedents:
            return TakagiSugenoModel(base_rule, coefficients)
        centers = vector[:-n_coefficients].reshape(self.n_rules, base_rule.n_features)
        return TakagiSugenoModel(TriangularRuleBase.from_centers(centers), coefficients)

    def fit(self, X: Array, y: Array) -> "TSFSSORegressor":
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float).reshape(-1)
        if X.ndim != 2 or X.shape[0] != y.size or X.shape[0] < 2:
            raise ValueError("X and y have incompatible shapes")
        if not np.all(np.isfinite(X)) or not np.all(np.isfinite(y)):
            raise ValueError("X and y must be finite")

        base_rule = TriangularRuleBase.from_data(X, self.n_rules)
        design = base_rule.design_matrix(X)
        rls_result = recursive_least_squares(design, y, alpha=self.rls_alpha)
        coefficients = rls_result.parameters.reshape(self.n_rules, X.shape[1] + 1)
        rls_model = TakagiSugenoModel(base_rule, coefficients)
        rls_error = rmse(y, rls_model.predict(X))

        y_scale = max(float(np.std(y)), 1.0)
        feature_scale = np.maximum(np.std(X, axis=0), 1e-9)
        one_rule_scale = np.concatenate([[y_scale], y_scale / feature_scale])
        coefficient_scale = np.tile(one_rule_scale, self.n_rules)
        coefficient_scale = np.maximum(coefficient_scale, np.abs(rls_result.parameters))
        coefficient_lo = rls_result.parameters - self.coefficient_search_radius * coefficient_scale
        coefficient_hi = rls_result.parameters + self.coefficient_search_radius * coefficient_scale

        center_vector = base_rule.center.reshape(-1)
        if self.optimize_antecedents:
            data_lo = np.min(X, axis=0)
            data_hi = np.max(X, axis=0)
            equal = data_hi <= data_lo
            data_lo[equal] -= 0.5
            data_hi[equal] += 0.5
            center_lo = np.tile(data_lo, self.n_rules)
            center_hi = np.tile(data_hi, self.n_rules)
            initial = np.concatenate([center_vector, rls_result.parameters])
            lower = np.concatenate([center_lo, coefficient_lo])
            upper = np.concatenate([center_hi, coefficient_hi])
        else:
            initial = rls_result.parameters.copy()
            lower = coefficient_lo
            upper = coefficient_hi

        def objective(vector: Array) -> float:
            model = self._decode(vector, base_rule)
            return rmse(y, model.predict(X))

        optimization = fsso(
            objective,
            dimensions=initial.size,
            lower=lower,
            upper=upper,
            config=self.optimizer_config,
            seed=self.seed,
            initial_center=initial,
            initial_spread=0.05,
        )
        self.model_ = self._decode(optimization.best_position, base_rule)
        optimized_error = rmse(y, self.model_.predict(X))
        self.fit_summary_ = TSFSSOFitSummary(
            rls_result=rls_result,
            optimization_result=optimization,
            rls_rmse=rls_error,
            optimized_rmse=optimized_error,
        )
        return self

    def predict(self, X: Array) -> Array:
        if self.model_ is None:
            raise RuntimeError("fit must be called before predict")
        return self.model_.predict(X)

