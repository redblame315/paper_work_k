"""Algorithms from the T-SFSSO manuscript."""

from .benchmarks import (
    ackley,
    matyas,
    rastrigin,
    step,
    weighted_sum_f1,
    weighted_sum_f1_optimum,
    zakharov,
)
from .forecasting import TSFSSORegressor, make_lagged_supervised
from .fuzzy import TakagiSugenoModel, TriangularRuleBase
from .metrics import mape, rmse, smape
from .optimizers import FSSOConfig, SSOConfig, OptimizationResult, fsso, sso
from .rls import RLSResult, recursive_least_squares

__all__ = [
    "FSSOConfig",
    "OptimizationResult",
    "RLSResult",
    "SSOConfig",
    "TSFSSORegressor",
    "TakagiSugenoModel",
    "TriangularRuleBase",
    "ackley",
    "fsso",
    "make_lagged_supervised",
    "mape",
    "matyas",
    "rastrigin",
    "recursive_least_squares",
    "rmse",
    "smape",
    "sso",
    "step",
    "weighted_sum_f1",
    "weighted_sum_f1_optimum",
    "zakharov",
]

