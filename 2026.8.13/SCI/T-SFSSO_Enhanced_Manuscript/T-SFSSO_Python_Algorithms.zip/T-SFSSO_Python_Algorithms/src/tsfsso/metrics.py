"""Prediction metrics from Equations (5), (41), and (42)."""

from __future__ import annotations

import numpy as np

Array = np.ndarray


def _pair(actual: Array, predicted: Array) -> tuple[Array, Array]:
    actual = np.asarray(actual, dtype=float).reshape(-1)
    predicted = np.asarray(predicted, dtype=float).reshape(-1)
    if actual.size == 0 or actual.shape != predicted.shape:
        raise ValueError("actual and predicted must be equal-length non-empty vectors")
    return actual, predicted


def rmse(actual: Array, predicted: Array) -> float:
    actual, predicted = _pair(actual, predicted)
    return float(np.sqrt(np.mean((actual - predicted) ** 2)))


def mape(actual: Array, predicted: Array, *, epsilon: float = 1e-12) -> float:
    actual, predicted = _pair(actual, predicted)
    denominator = np.maximum(np.abs(actual), epsilon)
    return float(100.0 * np.mean(np.abs(actual - predicted) / denominator))


def smape(actual: Array, predicted: Array, *, epsilon: float = 1e-12) -> float:
    actual, predicted = _pair(actual, predicted)
    denominator = np.maximum((np.abs(actual) + np.abs(predicted)) / 2.0, epsilon)
    return float(100.0 * np.mean(np.abs(actual - predicted) / denominator))

