"""Benchmark functions from Tables 1 and 4 of the manuscript."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

Array = np.ndarray


def _vector(x: Array) -> Array:
    value = np.asarray(x, dtype=float)
    if value.ndim != 1 or value.size == 0:
        raise ValueError("x must be a non-empty one-dimensional vector")
    return value


def weighted_sum_f1(x: Array) -> float:
    """Table 1 Function-1: ||x||^2 + (c^T x)^2 + c^T x."""
    x = _vector(x)
    c = 0.5 * np.arange(1, x.size + 1, dtype=float)
    projection = float(c @ x)
    return float(x @ x + projection * projection + projection)


def weighted_sum_f1_gradient(x: Array) -> Array:
    x = _vector(x)
    c = 0.5 * np.arange(1, x.size + 1, dtype=float)
    return 2.0 * x + (2.0 * float(c @ x) + 1.0) * c


def weighted_sum_f1_optimum(dimensions: int) -> tuple[Array, float]:
    """Closed-form solution from Proposition 1 / Equation (43)."""
    if dimensions < 1:
        raise ValueError("dimensions must be positive")
    c = 0.5 * np.arange(1, dimensions + 1, dtype=float)
    w = float(c @ c)
    position = -c / (2.0 * (w + 1.0))
    value = -w / (4.0 * (w + 1.0))
    return position, float(value)


def matyas(x: Array) -> float:
    x = _vector(x)
    if x.size != 2:
        raise ValueError("Matyas is two-dimensional")
    return float(0.26 * (x[0] ** 2 + x[1] ** 2) - 0.48 * x[0] * x[1])


def matyas_gradient(x: Array) -> Array:
    x = _vector(x)
    if x.size != 2:
        raise ValueError("Matyas is two-dimensional")
    return np.array([0.52 * x[0] - 0.48 * x[1], 0.52 * x[1] - 0.48 * x[0]])


def step(x: Array) -> float:
    x = _vector(x)
    return float(np.sum(np.floor(x + 0.5) ** 2))


def rastrigin(x: Array) -> float:
    x = _vector(x)
    return float(np.sum(x * x - 10.0 * np.cos(2.0 * np.pi * x) + 10.0))


def rastrigin_gradient(x: Array) -> Array:
    x = _vector(x)
    return 2.0 * x + 20.0 * np.pi * np.sin(2.0 * np.pi * x)


def ackley(x: Array) -> float:
    x = _vector(x)
    n = x.size
    return float(
        -20.0 * np.exp(-0.2 * np.sqrt(np.sum(x * x) / n))
        - np.exp(np.sum(np.cos(2.0 * np.pi * x)) / n)
        + 20.0
        + np.e
    )


def ackley_gradient(x: Array) -> Array:
    x = _vector(x)
    n = x.size
    mean_square = float(np.sum(x * x) / n)
    radius = np.sqrt(mean_square)
    first = np.zeros_like(x)
    if radius > np.finfo(float).eps:
        first = 4.0 * np.exp(-0.2 * radius) * x / (n * radius)
    mean_cos = float(np.sum(np.cos(2.0 * np.pi * x)) / n)
    second = (2.0 * np.pi / n) * np.exp(mean_cos) * np.sin(2.0 * np.pi * x)
    return first + second


def zakharov(x: Array) -> float:
    x = _vector(x)
    c = 0.5 * np.arange(1, x.size + 1, dtype=float)
    projection = float(c @ x)
    return float(x @ x + projection**2 + projection**4)


def zakharov_gradient(x: Array) -> Array:
    x = _vector(x)
    c = 0.5 * np.arange(1, x.size + 1, dtype=float)
    projection = float(c @ x)
    return 2.0 * x + (2.0 * projection + 4.0 * projection**3) * c


@dataclass(frozen=True)
class Benchmark:
    name: str
    function: Callable[[Array], float]
    lower: float
    upper: float
    gradient: Callable[[Array], Array] | None = None


TABLE_1_BENCHMARKS = {
    "weighted_sum_f1": Benchmark(
        "Weighted-sum f1", weighted_sum_f1, -5.0, 30.0, weighted_sum_f1_gradient
    ),
    "matyas": Benchmark("Matyas", matyas, -10.0, 10.0, matyas_gradient),
}

TABLE_4_BENCHMARKS = {
    "step": Benchmark("Step", step, -100.0, 100.0),
    "rastrigin": Benchmark("Rastrigin", rastrigin, -5.12, 5.12, rastrigin_gradient),
    "ackley": Benchmark("Ackley", ackley, -32.0, 32.0, ackley_gradient),
    "zakharov": Benchmark("Zakharov", zakharov, -100.0, 100.0, zakharov_gradient),
}

