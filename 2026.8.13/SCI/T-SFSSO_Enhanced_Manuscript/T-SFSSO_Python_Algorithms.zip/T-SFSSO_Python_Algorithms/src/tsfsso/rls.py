"""Recursive least-squares identification (Algorithm 1)."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

Array = np.ndarray


@dataclass(frozen=True)
class RLSResult:
    parameters: Array
    covariance: Array
    prediction_history: Array
    residual_history: Array


def recursive_least_squares(
    design_matrix: Array,
    targets: Array,
    *,
    alpha: float = 1e5,
    forgetting_factor: float = 1.0,
    initial_parameters: Array | None = None,
) -> RLSResult:
    """Apply Equations (12)-(14) to a precomputed T-S design matrix."""
    H = np.asarray(design_matrix, dtype=float)
    y = np.asarray(targets, dtype=float).reshape(-1)
    if H.ndim != 2 or H.shape[0] != y.size or H.shape[1] == 0:
        raise ValueError("design_matrix and targets have incompatible shapes")
    if alpha <= 0 or not 0 < forgetting_factor <= 1:
        raise ValueError("alpha must be positive and forgetting_factor in (0,1]")

    parameters = (
        np.zeros(H.shape[1], dtype=float)
        if initial_parameters is None
        else np.asarray(initial_parameters, dtype=float).copy()
    )
    if parameters.shape != (H.shape[1],):
        raise ValueError("initial_parameters has the wrong shape")
    covariance = alpha * np.eye(H.shape[1], dtype=float)
    predictions = np.empty(y.size, dtype=float)
    residuals = np.empty(y.size, dtype=float)

    for sample, (row, target) in enumerate(zip(H, y)):
        prediction = float(row @ parameters)
        residual = float(target - prediction)
        denominator = forgetting_factor + float(row @ covariance @ row)
        gain = covariance @ row / denominator
        parameters = parameters + gain * residual
        covariance = (covariance - np.outer(gain, row) @ covariance) / forgetting_factor
        # Preserve numerical symmetry after repeated floating-point updates.
        covariance = 0.5 * (covariance + covariance.T)
        predictions[sample] = prediction
        residuals[sample] = residual

    return RLSResult(parameters, covariance, predictions, residuals)

