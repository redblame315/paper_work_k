"""Conventional SSO (Algorithm 2) and improved FSSO (Algorithm 3)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from .gradients import central_difference

Array = np.ndarray
Objective = Callable[[Array], float]
Gradient = Callable[[Array], Array]


@dataclass(frozen=True)
class SSOConfig:
    population_size: int = 10
    iterations: int = 50
    rotations: int = 5
    mu: float = 0.9
    alpha: float = 0.5
    velocity_fraction: float = 0.5
    relative_gradient_step: float = 1e-6


@dataclass(frozen=True)
class FSSOConfig(SSOConfig):
    gradient_threshold: float = 1.0  # C_g
    time_scale: float = 2.0  # C_t
    unit_step_probability: float = 0.7  # Q
    jump_gradient_threshold: float = 1e-6  # epsilon_J
    jump_period: int = 10  # T_jump


@dataclass(frozen=True)
class OptimizationResult:
    best_position: Array
    best_value: float
    history: Array
    evaluations: int
    iterations: int
    seed: int | None

    def __iter__(self):
        """Permit `x, value, history = result` as in the paper appendix."""
        yield self.best_position
        yield self.best_value
        yield self.history


def _validate_common(config: SSOConfig) -> None:
    if config.population_size < 1 or config.iterations < 1:
        raise ValueError("population_size and iterations must be positive")
    if config.rotations < 0:
        raise ValueError("rotations cannot be negative")
    if config.mu < 0 or not 0 <= config.alpha < 2:
        raise ValueError("mu must be nonnegative and alpha must be in [0,2)")
    if not 0 < config.velocity_fraction <= 1:
        raise ValueError("velocity_fraction must be in (0,1]")


def _bounds(dimensions: int, lower, upper) -> tuple[Array, Array]:
    if dimensions < 1:
        raise ValueError("dimensions must be positive")
    lo = np.broadcast_to(np.asarray(lower, dtype=float), (dimensions,)).copy()
    hi = np.broadcast_to(np.asarray(upper, dtype=float), (dimensions,)).copy()
    if not np.all(np.isfinite(lo)) or not np.all(np.isfinite(hi)):
        raise ValueError("bounds must be finite")
    if np.any(hi <= lo):
        raise ValueError("every upper bound must exceed its lower bound")
    return lo, hi


def _initialize(
    rng: np.random.Generator,
    population_size: int,
    lo: Array,
    hi: Array,
    initial_center: Array | None,
    initial_spread: float,
) -> tuple[Array, Array]:
    dimensions = lo.size
    if initial_center is None:
        positions = lo + (hi - lo) * rng.random((population_size, dimensions))
    else:
        center = np.asarray(initial_center, dtype=float)
        if center.shape != (dimensions,):
            raise ValueError("initial_center has the wrong dimension")
        center = np.clip(center, lo, hi)
        if initial_spread < 0:
            raise ValueError("initial_spread cannot be negative")
        offsets = initial_spread * (hi - lo) * rng.normal(size=(population_size, dimensions))
        positions = np.clip(center + offsets, lo, hi)
        positions[0] = center  # Preserve the RLS elite used by Algorithm 4.
    velocities = 0.1 * (hi - lo) * (2.0 * rng.random(positions.shape) - 1.0)
    return positions, velocities


def _run(
    objective: Objective,
    dimensions: int,
    lower,
    upper,
    config: SSOConfig,
    *,
    improved: bool,
    gradient: Gradient | None,
    seed: int | None,
    initial_center: Array | None,
    initial_spread: float,
) -> OptimizationResult:
    _validate_common(config)
    if improved:
        assert isinstance(config, FSSOConfig)
        if config.gradient_threshold <= 0 or config.time_scale < 0:
            raise ValueError("gradient_threshold must be positive; time_scale nonnegative")
        if not 0 <= config.unit_step_probability <= 1:
            raise ValueError("unit_step_probability must be in [0,1]")
        if config.jump_gradient_threshold < 0 or config.jump_period < 1:
            raise ValueError("jump threshold must be nonnegative and jump_period positive")

    lo, hi = _bounds(dimensions, lower, upper)
    rng = np.random.default_rng(seed)
    positions, velocities = _initialize(
        rng, config.population_size, lo, hi, initial_center, initial_spread
    )
    velocity_max = config.velocity_fraction * (hi - lo)
    evaluations = 0

    def counted(x: Array) -> float:
        nonlocal evaluations
        value = float(objective(np.asarray(x, dtype=float)))
        evaluations += 1
        if not np.isfinite(value):
            return float("inf")
        return value

    values = np.array([counted(x) for x in positions], dtype=float)
    winner = int(np.argmin(values))
    best_position = positions[winner].copy()
    best_value = float(values[winner])
    history = np.empty(config.iterations + 1, dtype=float)
    history[0] = best_value

    for stage in range(1, config.iterations + 1):
        gamma = rng.uniform(0.0, 2.0 if improved else 1.0)
        for shark in range(config.population_size):
            if gradient is None:
                g = central_difference(
                    counted,
                    positions[shark],
                    lo,
                    hi,
                    relative_step=config.relative_gradient_step,
                )
            else:
                g = np.asarray(gradient(positions[shark]), dtype=float)
                if g.shape != (dimensions,):
                    raise ValueError("gradient returned the wrong shape")
            magnitude = float(np.linalg.norm(g))

            trial_velocity = (
                -config.mu * rng.random(dimensions) * g
                + config.alpha * rng.random(dimensions) * velocities[shark]
            )
            former_speed = np.maximum(np.abs(velocities[shark]), 1e-12)
            velocities[shark] = np.sign(trial_velocity) * np.minimum(
                np.abs(trial_velocity), gamma * former_speed
            )
            velocities[shark] = np.clip(velocities[shark], -velocity_max, velocity_max)

            delta_t = 1.0
            if improved:
                fsso_config = config
                if (
                    magnitude >= fsso_config.gradient_threshold
                    and rng.random() >= fsso_config.unit_step_probability
                ):
                    delta_t = (
                        magnitude
                        / fsso_config.gradient_threshold
                        * fsso_config.time_scale
                        * rng.random()
                    )

            forward = np.clip(
                positions[shark] + velocities[shark] * delta_t, lo, hi
            )
            if improved:
                fsso_config = config
                if (
                    stage % fsso_config.jump_period == 0
                    and magnitude < fsso_config.jump_gradient_threshold
                ):
                    forward = lo + (hi - lo) * rng.random(dimensions)

            candidates = [forward]
            rotation_low, rotation_high = (-1.3, 1.3) if improved else (0.0, 1.0)
            for _ in range(config.rotations):
                rotation = rng.uniform(rotation_low, rotation_high, size=dimensions)
                candidates.append(np.clip(forward + rotation * forward, lo, hi))

            candidate_values = np.array([counted(candidate) for candidate in candidates])
            candidate_winner = int(np.argmin(candidate_values))
            if candidate_values[candidate_winner] <= values[shark]:
                positions[shark] = candidates[candidate_winner]
                values[shark] = candidate_values[candidate_winner]

            if values[shark] < best_value:
                best_value = float(values[shark])
                best_position = positions[shark].copy()
        history[stage] = best_value

    return OptimizationResult(
        best_position=best_position,
        best_value=best_value,
        history=history,
        evaluations=evaluations,
        iterations=config.iterations,
        seed=seed,
    )


def sso(
    objective: Objective,
    dimensions: int,
    lower,
    upper,
    *,
    config: SSOConfig | None = None,
    gradient: Gradient | None = None,
    seed: int | None = None,
    initial_center: Array | None = None,
    initial_spread: float = 0.1,
) -> OptimizationResult:
    """Conventional SSO from Algorithm 2 / Equations (15)-(25)."""
    return _run(
        objective,
        dimensions,
        lower,
        upper,
        config or SSOConfig(),
        improved=False,
        gradient=gradient,
        seed=seed,
        initial_center=initial_center,
        initial_spread=initial_spread,
    )


def fsso(
    objective: Objective,
    dimensions: int,
    lower,
    upper,
    *,
    config: FSSOConfig | None = None,
    gradient: Gradient | None = None,
    seed: int | None = None,
    initial_center: Array | None = None,
    initial_spread: float = 0.1,
) -> OptimizationResult:
    """Improved FSSO from Algorithm 3 / Equations (26)-(32)."""
    return _run(
        objective,
        dimensions,
        lower,
        upper,
        config or FSSOConfig(),
        improved=True,
        gradient=gradient,
        seed=seed,
        initial_center=initial_center,
        initial_spread=initial_spread,
    )

