"""Dynamic Takagi-Sugeno fuzzy model from Equations (1)-(11)."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

Array = np.ndarray


def _matrix(X: Array) -> Array:
    value = np.asarray(X, dtype=float)
    if value.ndim == 1:
        value = value.reshape(1, -1)
    if value.ndim != 2 or value.shape[1] == 0:
        raise ValueError("X must be a two-dimensional non-empty matrix")
    return value


def triangular_membership(x: Array, left: Array, center: Array, right: Array) -> Array:
    """Evaluate triangular memberships, including left/right shoulder triangles."""
    x, left, center, right = np.broadcast_arrays(
        np.asarray(x, dtype=float),
        np.asarray(left, dtype=float),
        np.asarray(center, dtype=float),
        np.asarray(right, dtype=float),
    )
    if np.any(left > center) or np.any(center > right):
        raise ValueError("triangle parameters must satisfy left <= center <= right")

    result = np.zeros_like(x, dtype=float)
    point = (left == center) & (center == right)
    result[point] = 1.0

    left_shoulder = (left == center) & (center < right)
    result[left_shoulder & (x <= center)] = 1.0
    mask = left_shoulder & (x > center) & (x < right)
    result[mask] = (right[mask] - x[mask]) / (right[mask] - center[mask])

    right_shoulder = (left < center) & (center == right)
    result[right_shoulder & (x >= center)] = 1.0
    mask = right_shoulder & (x > left) & (x < center)
    result[mask] = (x[mask] - left[mask]) / (center[mask] - left[mask])

    regular = (left < center) & (center < right)
    rising = regular & (x > left) & (x <= center)
    falling = regular & (x > center) & (x < right)
    result[rising] = (x[rising] - left[rising]) / (center[rising] - left[rising])
    result[falling] = (right[falling] - x[falling]) / (right[falling] - center[falling])
    return np.clip(result, 0.0, 1.0)


@dataclass(frozen=True)
class TriangularRuleBase:
    """One triangular antecedent per feature in every aligned T-S rule."""

    left: Array
    center: Array
    right: Array

    def __post_init__(self) -> None:
        left = np.asarray(self.left, dtype=float)
        center = np.asarray(self.center, dtype=float)
        right = np.asarray(self.right, dtype=float)
        if left.ndim != 2 or left.shape != center.shape or left.shape != right.shape:
            raise ValueError("left, center, and right must share shape (rules, features)")
        if left.shape[0] < 1 or left.shape[1] < 1:
            raise ValueError("the rule base cannot be empty")
        if np.any(left > center) or np.any(center > right):
            raise ValueError("triangle parameters must satisfy left <= center <= right")
        object.__setattr__(self, "left", left.copy())
        object.__setattr__(self, "center", center.copy())
        object.__setattr__(self, "right", right.copy())

    @property
    def n_rules(self) -> int:
        return int(self.center.shape[0])

    @property
    def n_features(self) -> int:
        return int(self.center.shape[1])

    @classmethod
    def from_data(cls, X: Array, n_rules: int = 5) -> "TriangularRuleBase":
        X = _matrix(X)
        if n_rules < 1:
            raise ValueError("n_rules must be positive")
        quantiles = np.linspace(0.0, 1.0, n_rules)
        centers = np.quantile(X, quantiles, axis=0)
        # Avoid zero-width internal intervals when a feature contains ties.
        for feature in range(X.shape[1]):
            minimum = float(np.min(X[:, feature]))
            maximum = float(np.max(X[:, feature]))
            if maximum == minimum:
                centers[:, feature] = minimum
            else:
                centers[:, feature] = np.maximum.accumulate(centers[:, feature])
                epsilon = np.finfo(float).eps * max(1.0, abs(minimum), abs(maximum))
                for rule in range(1, n_rules):
                    centers[rule, feature] = max(
                        centers[rule, feature], centers[rule - 1, feature] + epsilon
                    )
                centers[:, feature] = np.clip(centers[:, feature], minimum, maximum)
                if np.any(np.diff(centers[:, feature]) <= 0.0):
                    # Quantile ties can create invalid internal shoulder sets.
                    centers[:, feature] = np.linspace(minimum, maximum, n_rules)
        return cls.from_centers(centers)

    @classmethod
    def from_centers(cls, centers: Array) -> "TriangularRuleBase":
        centers = np.asarray(centers, dtype=float)
        if centers.ndim != 2 or centers.shape[0] < 1 or centers.shape[1] < 1:
            raise ValueError("centers must have shape (rules, features)")
        centers = np.sort(centers, axis=0)
        left = centers.copy()
        right = centers.copy()
        if centers.shape[0] > 1:
            left[1:] = centers[:-1]
            right[:-1] = centers[1:]
        return cls(left=left, center=centers, right=right)

    def membership(self, X: Array) -> Array:
        X = _matrix(X)
        if X.shape[1] != self.n_features:
            raise ValueError("X has the wrong number of features")
        return triangular_membership(
            X[:, None, :],
            self.left[None, :, :],
            self.center[None, :, :],
            self.right[None, :, :],
        )

    def firing_strengths(self, X: Array) -> Array:
        """Equation (7): product of the antecedent memberships."""
        return np.prod(self.membership(X), axis=2)

    def normalized_strengths(self, X: Array) -> Array:
        """Equation (11), with nearest-rule fallback for underflow/gaps."""
        X = _matrix(X)
        strengths = self.firing_strengths(X)
        totals = strengths.sum(axis=1, keepdims=True)
        missing = totals[:, 0] <= np.finfo(float).tiny
        if np.any(missing):
            distances = np.sum((X[missing, None, :] - self.center[None, :, :]) ** 2, axis=2)
            strengths[missing] = 0.0
            strengths[np.flatnonzero(missing), np.argmin(distances, axis=1)] = 1.0
            totals = strengths.sum(axis=1, keepdims=True)
        return strengths / totals

    def design_matrix(self, X: Array) -> Array:
        """Equations (8) and (11), ordered rule-by-rule."""
        X = _matrix(X)
        weights = self.normalized_strengths(X)
        augmented = np.concatenate([np.ones((X.shape[0], 1)), X], axis=1)
        return (weights[:, :, None] * augmented[:, None, :]).reshape(X.shape[0], -1)


@dataclass(frozen=True)
class TakagiSugenoModel:
    rule_base: TriangularRuleBase
    coefficients: Array

    def __post_init__(self) -> None:
        coefficients = np.asarray(self.coefficients, dtype=float)
        expected = (self.rule_base.n_rules, self.rule_base.n_features + 1)
        if coefficients.shape != expected:
            raise ValueError(f"coefficients must have shape {expected}")
        object.__setattr__(self, "coefficients", coefficients.copy())

    def predict(self, X: Array) -> Array:
        """Equation (6): normalized weighted average of linear consequents."""
        X = _matrix(X)
        if X.shape[1] != self.rule_base.n_features:
            raise ValueError("X has the wrong number of features")
        weights = self.rule_base.normalized_strengths(X)
        augmented = np.concatenate([np.ones((X.shape[0], 1)), X], axis=1)
        rule_outputs = augmented @ self.coefficients.T
        return np.sum(weights * rule_outputs, axis=1)
