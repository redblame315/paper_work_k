"""Gradient utilities used by SSO and FSSO."""

from __future__ import annotations

from typing import Callable

import numpy as np

Array = np.ndarray


def central_difference(
    objective: Callable[[Array], float],
    x: Array,
    lower: Array,
    upper: Array,
    relative_step: float = 1e-6,
) -> Array:
    """Bound-aware central difference with one-sided behavior at a boundary."""
    x = np.asarray(x, dtype=float)
    lower = np.broadcast_to(np.asarray(lower, dtype=float), x.shape)
    upper = np.broadcast_to(np.asarray(upper, dtype=float), x.shape)
    if relative_step <= 0:
        raise ValueError("relative_step must be positive")

    steps = relative_step * np.maximum(1.0, np.abs(x))
    gradient = np.zeros_like(x)
    for j in range(x.size):
        plus = x.copy()
        minus = x.copy()
        plus[j] = min(upper[j], x[j] + steps[j])
        minus[j] = max(lower[j], x[j] - steps[j])
        width = plus[j] - minus[j]
        if width > 0.0:
            gradient[j] = (objective(plus) - objective(minus)) / width
    return gradient

